#include "vex.h"

// vex::distance Front(PORT9);
// vex::distance Back(PORT2);

/**
 * 
 * Drives the robot a given distance towards the largest object of a specific color
 * as determined by the AI Vision sensor. It tries to align the robot with the
 * center of the largest object. 
 * 
 * @param distance desired distance sensor measurement inches
 * 
 * @param drive_min_voltage minimum voltage output of the forward and backward movement (out of 12)
 * @param drive_max_voltage maximum voltage output of the forward and backward movement (out of 12)
 * @param vision_min_voltage minimum voltage output of the heading movement determined by the AI Vision sensor reading (out of 12)
 * @param vision_max_voltage maximum voltage output of the heading movement determined by the AI Vision sensor reading (out of 12)
 * 
 * @param drive_settle_error desired error in which the robot is still considered settled (in inches)
 * @param drive_settle_time minimum time the robot must be settled for before the movement finishes (in ms)
 * @param drive_timeout maximum time the motion is ran before the robot moves on to the next movement (in ms)
 * 
 */

void Drive::drive_with_front_distance(float distance, float heading, float drive_min_voltage, float drive_max_voltage, float heading_min_voltage, float heading_max_voltage, float drive_settle_error, float drive_settle_time, float drive_timeout) {

  PID drivePID(Front.objectDistance(inches) - distance, drive_kp, drive_ki, drive_kd, drive_starti, drive_settle_error, drive_settle_time, drive_timeout);
  PID headingPID(reduce_negative_180_to_180(heading - get_absolute_heading()), heading_kp, heading_ki, heading_kd, heading_starti);

  while(drivePID.is_settled() == false){

    float drive_error = Front.objectDistance(inches) - distance;
    float heading_error = reduce_negative_180_to_180(heading - get_absolute_heading());
    float drive_output = drivePID.compute(drive_error);
    float heading_output = headingPID.compute(heading_error);

    drive_output = clamp(drive_output, -drive_max_voltage, drive_max_voltage);
    heading_output = clamp(heading_output, -heading_max_voltage, heading_max_voltage);
    drive_output = clamp_min_voltage(drive_output, drive_min_voltage);
    heading_output = clamp_min_voltage(heading_output, heading_min_voltage);

    drive_with_voltage(drive_output+heading_output, drive_output-heading_output);
    task::sleep(10);
  }
}

void Drive::drive_with_front_distance(float distance, float heading, float drive_min_voltage, float drive_max_voltage, float heading_min_voltage, float heading_max_voltage) {
  drive_with_front_distance(distance, heading, drive_min_voltage, drive_max_voltage, heading_min_voltage, heading_max_voltage, drive_settle_error, drive_settle_time, drive_timeout);
}

void Drive::drive_with_front_distance(float distance, float heading) {
  drive_with_front_distance(distance, heading, drive_min_voltage, drive_max_voltage, heading_min_voltage, heading_max_voltage, drive_settle_error, drive_settle_time, drive_timeout);
}

void Drive::drive_with_front_distance(float distance) {
  drive_with_front_distance(distance, get_absolute_heading(), drive_min_voltage, drive_max_voltage, heading_min_voltage, heading_max_voltage, drive_settle_error, drive_settle_time, drive_timeout);
}




// Doesn't work

void Drive::drive_with_back_distance(float distance, float heading, float drive_min_voltage, float drive_max_voltage, float heading_min_voltage, float heading_max_voltage, float drive_settle_error, float drive_settle_time, float drive_timeout) {

  PID drivePID(Back.objectDistance(inches) - distance, drive_kp, drive_ki, drive_kd, drive_starti, drive_settle_error, drive_settle_time, drive_timeout);
  PID headingPID(reduce_negative_180_to_180(heading - get_absolute_heading()), heading_kp, heading_ki, heading_kd, heading_starti);

  while(drivePID.is_settled() == false){

    float drive_error = Back.objectDistance(inches) - distance;
    float heading_error = reduce_negative_180_to_180(heading - get_absolute_heading());
    float drive_output = drivePID.compute(drive_error);
    float heading_output = headingPID.compute(heading_error);

    drive_output = clamp(drive_output, -drive_max_voltage, drive_max_voltage);
    heading_output = clamp(heading_output, -heading_max_voltage, heading_max_voltage);
    drive_output = clamp_min_voltage(drive_output, drive_min_voltage);
    heading_output = clamp_min_voltage(heading_output, heading_min_voltage);

    drive_with_voltage(-drive_output+heading_output, -drive_output-heading_output);
    task::sleep(10);
  }
}

void Drive::drive_with_back_distance(float distance, float heading, float drive_min_voltage, float drive_max_voltage, float heading_min_voltage, float heading_max_voltage) {
  drive_with_back_distance(distance, heading, drive_min_voltage, drive_max_voltage, heading_min_voltage, heading_max_voltage, drive_settle_error, drive_settle_time, drive_timeout);
}

void Drive::drive_with_back_distance(float distance, float heading) {
  drive_with_back_distance(distance, heading, drive_min_voltage, drive_max_voltage, heading_min_voltage, heading_max_voltage, drive_settle_error, drive_settle_time, drive_timeout);
}

void Drive::drive_with_back_distance(float distance) {
  drive_with_back_distance(distance, get_absolute_heading(), drive_min_voltage, drive_max_voltage, heading_min_voltage, heading_max_voltage, drive_settle_error, drive_settle_time, drive_timeout);
}

