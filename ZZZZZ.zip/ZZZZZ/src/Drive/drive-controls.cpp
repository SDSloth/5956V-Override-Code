#include "vex.h"


/**
 * Controls a chassis with left stick left drive and right stick right drive.
 * Default deadband is 5.
 * 
 * @param percent is the maximum speed of the robot as a percentage of maximum voltage
 */

void Drive::control_tank (float percent) {
  float leftthrottle = deadband(controller(primary).Axis3.value(), 5) * (percent / 100);
  float rightthrottle = deadband(controller(primary).Axis2.value(), 5) * (percent / 100);
  DriveL.spin(fwd, to_volt(leftthrottle), volt);
  DriveR.spin(fwd, to_volt(rightthrottle), volt);
}

// the function is overloaded running at 100 percent speed
void Drive::control_tank () {
  control_tank(100);
}



/**
 * Controls a chassis with left stick throttle and right stick turning.
 * Default deadband is 5.
 * 
 * @param drive_percent is the maximum speed of the forward and backward movement as a percentage of maximum voltage
 * @param turn_percent is the maximum speed of the turning movement as a percentage of maximum voltage
 */

void Drive::control_arcade (float drive_percent, float turn_percent) {
  float throttle = deadband(controller(primary).Axis3.value(), 5) * (drive_percent / 100);
  float turn = deadband(controller(primary).Axis1.value(), 5) * (turn_percent / 100);
  DriveL.spin(fwd, to_volt(throttle+turn), volt);
  DriveR.spin(fwd, to_volt(throttle-turn), volt);
}

// the function is overloaded with one percentage and running at 100 percent speed
void Drive::control_arcade(float percent) {
  control_arcade(percent, percent);
}

void Drive::control_arcade () {
  control_arcade(100, 100);
}


void Drive::control_exponential (float percent, float power, float slew_rate) {

  // Throttle is converted to exponential growth
  float throttle = deadband(controller(primary).Axis3.value(), 5);
  throttle = copysign(pow(fabs(throttle / 100), power) * 100, throttle);


  // Turn is converted to exponential growth
  float turn = deadband(controller(primary).Axis1.value(), 5);
  turn = copysign(pow(fabs(turn / 100), power) * 100, turn);

  // The variables for the left and right in arcade drive are initialized
  float left  = throttle + turn;
  float right = throttle - turn;

  // Both sides of the drivebase are scaled to be inside the range [-100, 100]
  float maximum = std::max(fabs(left), fabs(right));
  if (maximum > 100) {
    left  = left  / maximum * 100;
    right = right / maximum * 100;
  }

  // Acceleration is limited by slew at a rate of slew_rate
  static float lastLeft = 0;
  static float lastRight = 0;

  left  = slew(left,  lastLeft,  slew_rate);
  right = slew(right, lastRight, slew_rate);

  lastLeft = left;
  lastRight = right;

  // The final values are output to the motors
  DriveL.spin(fwd, to_volt(left)  * percent / 100, volt);
  DriveR.spin(fwd, to_volt(right) * percent / 100, volt);
}
