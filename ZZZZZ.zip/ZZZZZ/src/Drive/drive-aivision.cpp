#include "vex.h"


// initializes color descriptions with values for game objects
aivision::colordesc AIVision__Orange(1, 133, 50, 6, 30, 0.68);


aivision::colordesc AIVision__Red(2, 170, 20, 68, 30, 0.43);
aivision::colordesc AIVision__Blue(3, 41, 88, 127, 16, 0.6);

// instantiates and initializes an AI Vision sensor with specified color descriptions
vex::aivision AIVision(PORT8, AIVision__Orange, AIVision__Red, AIVision__Blue);


#define color AIVision__Orange

/**
 * 
 * Drives the robot a given distance towards the largest object of a specific color
 * as determined by the AI Vision sensor. It tries to align the robot with the
 * center of the largest object. 
 * 
 * @param distance desired distance in inches
 * 
 * @param drive_min_voltage minimum voltage output of the forward and backward movement (out of 12)
 * @param drive_max_voltage maximum voltage output of the forward and backward movement (out of 12)
 * @param vision_min_voltage minimum voltage output of the heading movement determined by the AI Vision sensor reading (out of 12)
 * @param vision_max_voltage maximum voltage output of the heading movement determined by the AI Vision sensor reading (out of 12)
 * 
 * @param drive_settle_error desired error in which the robot is still considered settled (in inches)
 * @param drive_settle_time minimum time the robot must be settled for before the movement finishes (in ms)
 * @param drive_timeout maximum time the motion is ran before the robot moves on to the next movement (in ms)
 * 
 */

void Drive::drive_with_vision(float distance, float drive_min_voltage, float drive_max_voltage, float vision_min_voltage, float vision_max_voltage, float drive_settle_error, float drive_settle_time, float drive_timeout) {
  
	// takes a snapshot with the AI Vision sensor; objects are ordered largest to smallest in an array
  AIVision.takeSnapshot(color);

  // instantiates and initializes a PID object for the forward and backward movements of the robot
	// settle error, settle time, and timeout are all initialized in this object; distance driven determines error
  PID drivePID(distance, drive_kp, drive_ki, drive_kd, drive_starti, drive_settle_error, drive_settle_time, drive_timeout);
 
	// instantiates and initializes a PID object for the heading movements based on the AI Vision sensor
	// the error is the difference in pixels between the center of the largest object and the center of the sensor
	// the sensor captures an image 320 pixels wide, so the center of the image is at 160 pixels
	// new PID values are initialized as the error for the vision sensor is based off of the pixel difference
  PID visionPID(AIVision.objects[0].centerX - 160, vision_kp, vision_ki,vision_kd, vision_starti);

	// the average position is taken from both sides of the drivebase to ensure accuracy
  float start_average_position = (get_left_position_in() + get_right_position_in()) / 2.0;
  float average_position = start_average_position;

	// this loop is ran until the drive PID is settled
  while (drivePID.is_settled() == false) {

		// the vision sensor takes another snapshot to see where the object is now
		AIVision.takeSnapshot(color);

		// new output values are recalculated as the robot moves and error changes
    average_position = (get_left_position_in() + get_right_position_in()) / 2.0;
    float drive_error = distance + start_average_position - average_position;
    float vision_error = AIVision.objects[0].centerX - 160;
    float drive_output = drivePID.compute(drive_error);
    float vision_output = visionPID.compute(vision_error);

		// depending on minimum and maximum voltages set, the output changes to fit in the range
    drive_output = clamp(drive_output, -drive_max_voltage, drive_max_voltage);
    drive_output = clamp_min_voltage(drive_output, drive_min_voltage);
    vision_output = clamp(vision_output, -vision_max_voltage, vision_max_voltage);
    vision_output = clamp_min_voltage(vision_output, vision_min_voltage);

		// the robot is driven with the voltage outputs determined from the PID objects, and the loop is ran again
    drive_with_voltage(drive_output + vision_output, drive_output - vision_output);
    task::sleep(10);
  
	}
}



// the function is overloaded, so different amounts of parameters can be passed into it
// this allows for definitions without specifying settle information or voltage bounds

void Drive::drive_with_vision (float distance, float drive_min_voltage, float drive_max_voltage, float vision_min_voltage, float vision_max_voltage) {
	drive_with_vision(distance, drive_min_voltage, drive_max_voltage, vision_min_voltage, vision_max_voltage, drive_settle_error, drive_settle_time, drive_timeout);
}

void Drive::drive_with_vision (float distance) {
	drive_with_vision(distance, drive_min_voltage, drive_max_voltage, vision_min_voltage, vision_max_voltage, drive_settle_error, drive_settle_time, drive_timeout);
}



void AWB() {
  AIVision.startAwb();
  wait(20,msec);
}