#include "vex.h"

/**
 * Resets default turn constants.
 * Turning includes turn_to_angle() and turn_to_point().
 * 
 * @param turn_min_voltage Min voltage out of 12
 * @param turn_max_voltage Max voltage out of 12
 * @param turn_kp Proportional constant
 * @param turn_ki Integral constant
 * @param turn_kd Derivative constant
 * @param turn_starti Minimum angle in degrees for integral to begin
 */

void Drive::set_turn_constants(float turn_min_voltage, float turn_max_voltage, float turn_kp, float turn_ki, float turn_kd, float turn_starti){
  this->turn_min_voltage = turn_min_voltage;
  this->turn_max_voltage = turn_max_voltage;
  this->turn_kp = turn_kp;
  this->turn_ki = turn_ki;
  this->turn_kd = turn_kd;
  this->turn_starti = turn_starti;
} 

/**
 * Resets default drive constants.
 * Driving includes drive_distance(), drive_to_point(), and
 * holonomic_drive_to_point().
 * 
 * @param drive_min_voltage Min voltage out of 12
 * @param drive_max_voltage Max voltage out of 12
 * @param drive_kp Proportional constant
 * @param drive_ki Integral constant
 * @param drive_kd Derivative constant
 * @param drive_starti Minimum distance in inches for integral to begin
 */

void Drive::set_drive_constants(float drive_min_voltage, float drive_max_voltage, float drive_kp, float drive_ki, float drive_kd, float drive_starti){
  this->drive_min_voltage = drive_min_voltage;
  this->drive_max_voltage = drive_max_voltage;
  this->drive_kp = drive_kp;
  this->drive_ki = drive_ki;
  this->drive_kd = drive_kd;
  this->drive_starti = drive_starti;
} 

/**
 * Resets default heading constants.
 * Heading control keeps the robot facing the right direction
 * and is part of drive_distance(), drive_to_point(), and
 * holonomic_drive_to_point.
 * 
 * @param heading_min_voltage Min voltage out of 12
 * @param heading_max_voltage Max voltage out of 12
 * @param heading_kp Proportional constant
 * @param heading_ki Integral constant
 * @param heading_kd Derivative constant
 * @param heading_starti Minimum angle in degrees for integral to begin
 */

void Drive::set_heading_constants(float heading_min_voltage, float heading_max_voltage, float heading_kp, float heading_ki, float heading_kd, float heading_starti){
  this->heading_min_voltage = heading_min_voltage;
  this->heading_max_voltage = heading_max_voltage;
  this->heading_kp = heading_kp;
  this->heading_ki = heading_ki;
  this->heading_kd = heading_kd;
  this->heading_starti = heading_starti;
}

/**
 * Resets default swing constants.
 * Swing control holds one side of the drive still and turns with the other.
 * Only left_swing_to_angle() and right_swing_to_angle() use these constants.
 * 
 * @param swing_min_voltage Min voltage out of 12
 * @param swing_max_voltage Max voltage out of 12
 * @param swing_kp Proportional constant
 * @param swing_ki Integral constant
 * @param swing_kd Derivative constant
 * @param swing_starti Minimum angle in degrees for integral to begin
 */

void Drive::set_swing_constants(float swing_min_voltage, float swing_max_voltage, float swing_kp, float swing_ki, float swing_kd, float swing_starti){
  this->swing_min_voltage = swing_min_voltage;
  this->swing_max_voltage = swing_max_voltage;
  this->swing_kp = swing_kp;
  this->swing_ki = swing_ki;
  this->swing_kd = swing_kd;
  this->swing_starti = swing_starti;
} 

/**
 * Resets default vision constants.
 * Vision is included in drive_with_vision. 
 * 
 * @param vision_min_voltage Min voltage out of 12
 * @param vision_max_voltage Max voltage out of 12
 * @param vision_kp Proportional constant
 * @param vision_ki Integral constant
 * @param vision_kd Derivative constant
 * @param vision_starti Minimum turn difference between object center and robot heading in pixels for the integral to begin
 * 
 */

void Drive::set_vision_constants(float vision_min_voltage, float vision_max_voltage, float vision_kp, float vision_ki, float vision_kd, float vision_starti){
  this->vision_min_voltage = vision_min_voltage;
  this->vision_max_voltage = vision_max_voltage;
  this->vision_kp = vision_kp;
  this->vision_ki = vision_ki;
  this->vision_kd = vision_kd;
  this->vision_starti = vision_starti;
}

/**
 * Resets default turn exit conditions.
 * The robot exits when error is less than settle_error for a duration of settle_time, 
 * or if the function has gone on for longer than timeout.
 * 
 * @param turn_settle_error Error to be considered settled in degrees.
 * @param turn_settle_time Time to be considered settled in milliseconds.
 * @param turn_timeout Time before quitting and move on in milliseconds.
 */

void Drive::set_turn_exit_conditions(float turn_settle_error, float turn_settle_time, float turn_timeout){
  this->turn_settle_error = turn_settle_error;
  this->turn_settle_time = turn_settle_time;
  this->turn_timeout = turn_timeout;
}

/**
 * Resets default drive exit conditions.
 * The robot exits when error is less than settle_error for a duration of settle_time, 
 * or if the function has gone on for longer than timeout.
 * 
 * @param drive_settle_error Error to be considered settled in inches.
 * @param drive_settle_time Time to be considered settled in milliseconds.
 * @param drive_timeout Time before quitting and move on in milliseconds.
 */

void Drive::set_drive_exit_conditions(float drive_settle_error, float drive_settle_time, float drive_timeout){
  this->drive_settle_error = drive_settle_error;
  this->drive_settle_time = drive_settle_time;
  this->drive_timeout = drive_timeout;
}

/**
 * Resets default swing exit conditions.
 * The robot exits when error is less than settle_error for a duration of settle_time, 
 * or if the function has gone on for longer than timeout.
 * 
 * @param swing_settle_error Error to be considered settled in degrees.
 * @param swing_settle_time Time to be considered settled in milliseconds.
 * @param swing_timeout Time before quitting and move on in milliseconds.
 */

void Drive::set_swing_exit_conditions(float swing_settle_error, float swing_settle_time, float swing_timeout){
  this->swing_settle_error = swing_settle_error;
  this->swing_settle_time = swing_settle_time;
  this->swing_timeout = swing_timeout;
}
