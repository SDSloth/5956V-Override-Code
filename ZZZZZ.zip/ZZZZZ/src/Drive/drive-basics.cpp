#include "vex.h"

/**
 * Turns the robot to a field-centric angle.
 * Optimizes direction, so it turns whichever way is closer to the 
 * current heading of the robot.
 * 
 * @param angle Desired angle in degrees.
 */

void Drive::turn_to_angle(float angle){
  turn_to_angle(angle, turn_min_voltage, turn_max_voltage, turn_settle_error, turn_settle_time, turn_timeout);
}

void Drive::turn_to_angle(float angle, float turn_min_voltage, float turn_max_voltage){
  turn_to_angle(angle, turn_min_voltage, turn_max_voltage, turn_settle_error, turn_settle_time, turn_timeout);
}

void Drive::turn_to_angle(float angle, float turn_min_voltage, float turn_max_voltage, float turn_settle_error, float turn_settle_time, float turn_timeout){
  PID turnPID(reduce_negative_180_to_180(angle - get_absolute_heading()), turn_kp, turn_ki, turn_kd, turn_starti, turn_settle_error, turn_settle_time, turn_timeout);
  while( !turnPID.is_settled() ){
    float error = reduce_negative_180_to_180(angle - get_absolute_heading());
    float output = turnPID.compute(error);
    output = clamp(output, -turn_max_voltage, turn_max_voltage);
    output = clamp_min_voltage(output, turn_min_voltage);
    drive_with_voltage(output, -output);
    task::sleep(10);
  }
}

/**
 * Drives the robot a given distance with a given heading.
 * Drive distance does not optimize for direction, so it won't try
 * to drive at the opposite heading from the one given to get there faster.
 * You can control the heading, but if you choose not to, it will drive with the
 * heading it's currently facing. It uses the average of the left and right
 * motor groups to calculate distance driven.
 * 
 * @param distance Desired distance in inches.
 * @param heading Desired heading in degrees.
 */

void Drive::drive_distance(float distance){
  drive_distance(distance, get_absolute_heading(), drive_min_voltage, drive_max_voltage, heading_min_voltage, heading_max_voltage, drive_settle_error, drive_settle_time, drive_timeout);
}

void Drive::drive_distance(float distance, float heading){
  drive_distance(distance, heading, drive_min_voltage, drive_max_voltage, heading_min_voltage, heading_max_voltage, drive_settle_error, drive_settle_time, drive_timeout);
}

void Drive::drive_distance(float distance, float heading, float drive_min_voltage, float drive_max_voltage, float heading_min_voltage, float heading_max_voltage){
  drive_distance(distance, heading, drive_min_voltage, drive_max_voltage, heading_min_voltage, heading_max_voltage, drive_settle_error, drive_settle_time, drive_timeout);
}

void Drive::drive_distance(float distance, float heading, float drive_min_voltage, float drive_max_voltage, float heading_min_voltage, float heading_max_voltage, float drive_settle_error, float drive_settle_time, float drive_timeout){
  PID drivePID(distance, drive_kp, drive_ki, drive_kd, drive_starti, drive_settle_error, drive_settle_time, drive_timeout);
  PID headingPID(reduce_negative_180_to_180(heading - get_absolute_heading()), heading_kp, heading_ki, heading_kd, heading_starti);
  float start_average_position = (get_left_position_in()+get_right_position_in())/2.0;
  float average_position = start_average_position;
  while(drivePID.is_settled() == false){
    average_position = (get_left_position_in()+get_right_position_in())/2.0;
    float drive_error = distance+start_average_position-average_position;
    float heading_error = reduce_negative_180_to_180(heading - get_absolute_heading());
    float drive_output = drivePID.compute(drive_error);
    float heading_output = headingPID.compute(heading_error);

    drive_output = clamp(drive_output, -drive_max_voltage, drive_max_voltage);
    heading_output = clamp(heading_output, -heading_max_voltage, heading_max_voltage);
    drive_output = clamp_min_voltage(drive_output, drive_min_voltage);
    heading_output = clamp_min_voltage(heading_output, heading_min_voltage);

    drive_with_voltage(drive_output+heading_output, drive_output-heading_output);
    task::sleep(10);
  }
}

/**
 * Turns to a given angle with only one side of the drivetrain.
 * Like turn_to_angle(), is optimized for turning the shorter
 * direction.
 * 
 * @param angle Desired angle in degrees.
 */

void Drive::left_swing_to_angle(float angle){
  left_swing_to_angle(angle, swing_min_voltage, swing_max_voltage, swing_settle_error, swing_settle_time, swing_timeout);
}

void Drive::left_swing_to_angle(float angle, float swing_min_voltage, float swing_max_voltage) {
  left_swing_to_angle(angle, swing_min_voltage, swing_max_voltage, swing_settle_error, swing_settle_time, swing_timeout);
}

void Drive::left_swing_to_angle(float angle, float swing_min_voltage, float swing_max_voltage, float swing_settle_error, float swing_settle_time, float swing_timeout){
  PID swingPID(reduce_negative_180_to_180(angle - get_absolute_heading()), swing_kp, swing_ki, swing_kd, swing_starti, swing_settle_error, swing_settle_time, swing_timeout);
  while(swingPID.is_settled() == false){
    float error = reduce_negative_180_to_180(angle - get_absolute_heading());
    float output = swingPID.compute(error);
    output = clamp(output, -swing_max_voltage, swing_max_voltage);
    output = clamp_min_voltage(output, swing_min_voltage);
    DriveL.spin(fwd, output, volt);
    DriveR.stop(hold);
    task::sleep(10);
  }
}

void Drive::right_swing_to_angle(float angle){
  right_swing_to_angle(angle, swing_min_voltage, swing_max_voltage, swing_settle_error, swing_settle_time, swing_timeout);
}

void Drive::right_swing_to_angle(float angle, float swing_min_voltage, float swing_max_voltage) {
  right_swing_to_angle(angle, swing_min_voltage, swing_max_voltage, swing_settle_error, swing_settle_time, swing_timeout);
}

void Drive::right_swing_to_angle(float angle, float swing_min_voltage, float swing_max_voltage, float swing_settle_error, float swing_settle_time, float swing_timeout){
  PID swingPID(reduce_negative_180_to_180(angle - get_absolute_heading()), swing_kp, swing_ki, swing_kd, swing_starti, swing_settle_error, swing_settle_time, swing_timeout);
  while(swingPID.is_settled() == false){
    float error = reduce_negative_180_to_180(angle - get_absolute_heading());
    float output = swingPID.compute(error);
    output = clamp(output, -swing_max_voltage, swing_max_voltage);
    output = clamp_min_voltage(output, swing_min_voltage);
    DriveR.spin(reverse, output, volt);
    DriveL.stop(hold);
    task::sleep(10);
  }
}
