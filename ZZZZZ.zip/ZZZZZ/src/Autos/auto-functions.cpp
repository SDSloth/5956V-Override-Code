#include "vex.h"

void clearLoader(float time, float heading) {

    chassis.set_heading(chassis.get_absolute_heading());

    // gets bot ready to reach loader
    Tongue.open();
    Intake.spin(forward, 100, pct);
    chassis.drive_stop(hold);
    wait(0.2,sec);

    // moves to loader
    chassis.drive_with_front_distance(7.9, heading, 5, 6, chassis.heading_min_voltage, chassis.heading_max_voltage, 1, 0, 1200);
    wait(time,sec);
    chassis.drive_stop(coast);
    Intake.stop();

}

void scoreLongGoal(float time) {

    // starts the intake
    Intake.spin(forward, 100, pct);
    Outtake.spin(forward, 100, pct);
    wait(0.15,sec);

    // opens the hood and waits until the bot is done scoring
    Hood.open();
    wait(time,sec);

    // stops the intake and closes the hood
    Outtake.stop();
    Intake.stop();
    Hood.close();

}