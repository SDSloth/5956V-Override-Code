#include "vex.h"

void skills() {

    
    AWB();
    chassis.set_heading(65);
    

    // pick up first blocks
    Wing.open();
    chassis.drive_distance(19.5, 65, 3, 10, 0, 10);
    // Intake.spin(fwd, 100, pct);
    // Tongue.open();
    chassis.drive_distance(21, 65, 3, 5, 0, 10);
    // Tongue.close();
    // Intake.stop();
    chassis.left_swing_to_angle(315);
    //Intake.spin(reverse, 100, pct);
    chassis.drive_distance(-13, 315, 3, 6, 0, 6);
    // Intake.spin(fwd,90,pct);
    // Outtake.spin(reverse,85,pct);
    wait(0.2,sec);
    Intake.stop();
    Outtake.stop();

    chassis.drive_distance(52, 319, 3, 10, 0, 10);
    chassis.turn_to_angle(270);

    // gets first loader

    clearLoader(2, 270);
    
    // moves to next goal
    chassis.drive_distance(-50, 237.5, 10, 10, 0, 10, 10, 0, 2000);
    Tongue.close();
    chassis.drive_distance(-20, 270, 10, 10, 0, 10, 10, 0, 2000);
    chassis.drive_distance(-44, 270, 4, 10, 0, 10);
    chassis.right_swing_to_angle(0);
    chassis.right_swing_to_angle(90);
    //chassis.drive_distance(-16, 90, 10, 10, 10, 1, 0, 800);
    chassis.drive_with_vision(-16, 0, 6, 0, 10, 1, 0, 600);

    // scores next goal
    scoreLongGoal(3);

    // gets second loader
    clearLoader(2, 90);


    // chassis.drive_distance(-37, 90, 10, 10, 10, 1, 0, 1000);
    chassis.drive_with_vision(-37, 0, 6, 0, 10, 1, 0, 1200);
    Tongue.close();

    // scores again
    scoreLongGoal(3.25);
    
    
    
    // **SECOND STAGE**
    
    // chassis.set_heading(90);

    // goes over parking zone
    Intake.spin(fwd, 100, pct);
    chassis.drive_with_front_distance(5.8, 130, 0, 5, 0, 10, 1, 0, 1400);
    chassis.left_swing_to_angle(177);
    chassis.drive_distance(50, 179, 10, 10, 0, 10);
    chassis.drive_with_front_distance(42, 182, 10, 10, 0, 10, 1, 0, 2000);
    chassis.turn_to_angle(20);
    chassis.drive_distance(-20, 20, 10, 10, 0, 10);

    //wait(1000,sec);


    // moves to goal
    chassis.turn_to_angle(90);
    //chassis.drive_distance(-37, 90, 10, 10, 10, 1, 0, 1000);
    chassis.drive_with_vision(-37, 0, 6, 0, 10, 1, 0, 1200);

    //wait(1000,sec);

    // scores middle goal
    scoreLongGoal(3);


    // gets next loader
    clearLoader(2, 92);

    // moves to next goal
    chassis.drive_distance(-50, 57.5, 10, 10, 0, 10, 10, 0, 1200);
    Tongue.close();
    chassis.drive_distance(-20, 90, 10, 10, 0, 10, 10, 0, 1200);
    chassis.drive_distance(-44, 90, 4, 10, 0, 10);
    chassis.right_swing_to_angle(180);
    chassis.right_swing_to_angle(270);
    //chassis.drive_distance(-16, 270, 10, 10, 10, 1, 0, 1000);
    chassis.drive_with_vision(-16, 0, 6, 0, 10, 1, 0, 600);

    // scores next goal
    scoreLongGoal(3);

    // gets last loader
    clearLoader(2, 272);

    //chassis.drive_distance(-37, 270, 10, 10, 10, 1, 0, 1000);
    chassis.drive_with_vision(-37, 0, 6, 0, 10, 1, 0, 1200);
    Tongue.close();

    // scores again
    scoreLongGoal(3.25);
    
    // final parking zone
    Intake.spin(fwd, 100, pct);
    chassis.drive_with_front_distance(5.8, 310, 0, 5, 0, 10, 1, 0, 1400);
    chassis.left_swing_to_angle(357);
    chassis.drive_distance(29.5, 359, 10, 10, 0, 10, 10, 0, 1200);
    Intake.stop();

    
}