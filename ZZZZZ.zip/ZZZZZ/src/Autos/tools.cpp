#include "vex.h"

/**
 * Resets the constants for auton movement.
 * Modify these to change the default behavior of functions like
 * drive_distance(). For explanations of the difference between
 * drive, heading, turning, and swinging, as well as the PID and
 * exit conditions, check the docs.
 */

void default_constants(){
  // Each constant set is in the form of (minVoltage, maxVoltage, kP, kI, kD, startI).
  chassis.set_drive_constants(0, 10, 1, 0, 10, 0);
  chassis.set_heading_constants(0, 10, .4, 0, 2, 0); //8, .4, 0, 3, 0
  chassis.set_turn_constants(0, 10, .4, .03, 3, 15);
  chassis.set_swing_constants(0, 11, .3, .001, 2, 15);
  chassis.set_vision_constants(0, 10, 0.07, 0.003, 0.8, 0);

  // Each exit condition set is in the form of (settle_error, settle_time, timeout).
  chassis.set_drive_exit_conditions(1, 100, 2000);
  chassis.set_turn_exit_conditions(0.5, 100, 2000);
  chassis.set_swing_exit_conditions(2, 0, 2000);
}



void setup() {

  IMU.calibrate();
  
  while (IMU.isCalibrating()) {
    wait(20, msec);
  }

  chassis.set_heading(0);

  if (Controller.ButtonLeft.pressing()) {

    chassis.turn_max_voltage = 5;
    chassis.turn_settle_time = 500000;
    chassis.turn_timeout = 500000;
    chassis.turn_to_angle(65);  

  } else if (Controller.ButtonRight.pressing()) {
    chassis.turn_max_voltage = 5;
    chassis.turn_settle_time = 500000;
    chassis.turn_timeout = 500000;
    chassis.turn_to_angle(115);
  }

  chassis.control_arcade(30);

}