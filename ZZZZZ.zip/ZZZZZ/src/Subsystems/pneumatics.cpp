#include "vex.h"




int tongueToggle() {
  while(1) {
    if(controller((primary)).ButtonY.pressing()) {
      if (Tongue.value() == 1) {
        Tongue.close();
      }
      else {
        Tongue.open();
      }

      waitUntil(!controller(primary).ButtonY.pressing());
  }

}

  return 0;
}



int wingToggle() {
  while(1) {
    if(controller(primary).ButtonB.pressing()) {
      if (Wing.value() == 1) {
        Wing.close();
      } else {
        Wing.open();
      }

      waitUntil(!controller(primary).ButtonB.pressing());
  }

}

  return 0;
}


int hoodToggle() {
  while(1) {
    if(controller(primary).ButtonA.pressing()) {
      if (Hood.value() == 1) {
        Hood.close();
      } else {
        Hood.open();
      }

      waitUntil(!controller(primary).ButtonA.pressing());
  }

}

  return 0;
}

int middleGoalToggle() {
  while(1) {
    if(controller(primary).ButtonX.pressing()) {
      if (MiddleGoal.value() == 1) {
        MiddleGoal.close();
      } else {
        MiddleGoal.open();
      }

      waitUntil(!controller(primary).ButtonX.pressing());
  }

}

  return 0;
}