#include "vex.h"


int intakeBlock() {
  while(1) {
      if (controller(primary).ButtonR1.pressing()) {
        if (Hood.value() == 0) {
          if (MiddleGoal.value() == 1) {
            Intake.spin(reverse, 100, pct);
            Outtake.spin(reverse,100,pct);
            wait(0.05,sec);
            while (ScoreDistance.objectDistance(inches) < 4) {
            Intake.spin(reverse, 100, pct);
            Outtake.spin(reverse,100,pct);
          }
          MiddleGoal.close();
        }
          Intake.spin(forward, 100, pct);
          Outtake.stop();
        } else {
          if (MiddleGoal.value() == 1) {
            Intake.spin(reverse, 100, pct);
            Outtake.spin(reverse,100,pct);
            wait(0.05,sec);
            while (ScoreDistance.objectDistance(inches) < 4) {
            Intake.spin(reverse, 100, pct);
            Outtake.spin(reverse,100,pct);
          }
          MiddleGoal.close();
        }
          Intake.spin(forward, 100, pct);
          Outtake.spin(forward, 100, pct);
        }
      }
      else if (controller(primary).ButtonR2.pressing()) {

        // Outtake when R2
        Intake.spin(reverse, 100, pct);
        Outtake.spin(reverse, 100, pct);

      }
      else if (controller(primary).ButtonL1.pressing()) {

        // Middle goal scoring when L1
        Outtake.spin(reverse, 100, pct);
        Intake.spin(reverse, 80, pct);
        wait(0.05, sec);

        // If a block is in the way it outtakes it until it isn't
        if (MiddleGoal.value() == 0 && ScoreDistance.objectDistance(inches) < 4) {
          while (ScoreDistance.objectDistance(inches) < 4) {
            Intake.spin(reverse, 80, pct);
          }
          MiddleGoal.open();
        } else if (MiddleGoal.value() == 0) {
          MiddleGoal.open();
        }

        // The outtake and intake motors spin in opposite directions
        Intake.spin(forward, 80, pct);
        waitUntil(!controller(primary).ButtonL1.pressing());
      }
      else {

        // When no intake buttons are pressed, it stops
        Intake.stop();
        Outtake.stop();
      }
      
  }

  return 0;
}