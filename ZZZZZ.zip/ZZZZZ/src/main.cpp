#include "vex.h"

using namespace vex;
competition Competition;



Drive chassis(


//Add the names of your Drive motors into the motor groups below, separated by commas, i.e. motor_group(Motor1,Motor2,Motor3).
//You will input whatever motor names you chose when you configured your robot using the sidebar configurer, they don't have to be "Motor1" and "Motor2".

//Left Motors:
motor_group(leftMotor1, leftMotor2, leftMotor3),

//Right Motors:
motor_group(rightMotor1, rightMotor2, rightMotor3),

//Specify the PORT NUMBER of your inertial sensor, in PORT format (i.e. "PORT1", not simply "1"):
PORT14,

//Input your wheel diameter. (4" omnis are actually closer to 4.125"):
3.25,

//External ratio, must be in decimal, in the format of input teeth/output teeth.
//If your motor has an 84-tooth gear and your wheel has a 60-tooth gear, this value will be 1.4.
//If the motor drives the wheel directly, this value is 1:
0.75,

//Gyro scale, this is what your gyro reads when you spin the robot 360 degrees.
//For most cases 360 will do fine here, but this scale factor can be very helpful when precision is necessary.
360,

//Input Forward Tracker center distance (a positive distance corresponds to a tracker on the right side of the robot, negative is left.)
//For a zero tracker tank drive with odom, put the positive distance from the center of the robot to the right side of the drive.
//This distance is in inches:
-2

);



int current_auton_selection = 0;
bool auto_started = false;

void pre_auton() {

  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  IMU.calibrate();
  while (IMU.isCalibrating()) {
    wait(20, msec);
  }

  default_constants();
  chassis.set_heading(0);

  while(!auto_started){

    Brain.Screen.clearScreen();
    Brain.Screen.printAt(5, 20, "5956Z");
    Brain.Screen.printAt(5, 40, "Battery Percentage:");
    Brain.Screen.printAt(5, 60, "%d", Brain.Battery.capacity());
    Brain.Screen.printAt(5, 80, "Chassis Heading Reading:");
    Brain.Screen.printAt(5, 100, "%f", chassis.get_absolute_heading());


    Brain.Screen.printAt(5, 120, "Selected Auton:");
    switch(current_auton_selection){
      case 0:
        Brain.Screen.printAt(5, 140, "Skills");
        break;
      case 1:
        Brain.Screen.printAt(5, 140, "Auton 2");
        break;
      case 2:
        Brain.Screen.printAt(5, 140, "Auton 3");
        break;
      case 3:
        Brain.Screen.printAt(5, 140, "Auton 4");
        break;
      case 4:
        Brain.Screen.printAt(5, 140, "Auton 5");
        break;
      case 5:
        Brain.Screen.printAt(5, 140, "Auton 6");
        break;
      case 6:
        Brain.Screen.printAt(5, 140, "Auton 7");
        break;
      case 7:
        Brain.Screen.printAt(5, 140, "Auton 8");
        break;
    }
    if(Brain.Screen.pressing()){
      while(Brain.Screen.pressing()) {}
      current_auton_selection ++;
    } else if (current_auton_selection == 8){
      current_auton_selection = 0;
    }
    task::sleep(10);
  }
}




void autonomous(void) {
  auto_started = true;
  switch(current_auton_selection){ 
    case 0:
      skills();
      break;
    case 1:         
      //drive_test();
      break;
    case 2:
      //turn_test();
      break;
    case 3:
      //swing_test();
      break;
    case 4:
      //full_test();
      break;
    case 5:
      //odom_test();
      break;
    case 6:
      //tank_odom_test();
      break;
    case 7:
      //holonomic_odom_test();
      break;
 }
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void usercontrol(void) {
  auto_started = true; 

  // Comment out the asterisks when testing code
    /*

  IMU.calibrate();
  
  while (IMU.isCalibrating()) {
    wait(20, msec);
  }
   
  default_constants();
   
  skills();
  wait(300000000000000,sec);
  
    */

  // Tasks: 

  task t100(intakeBlock);
  task t101(tongueToggle);
  task t102(wingToggle);
  task t103(hoodToggle);
  task t104(middleGoalToggle);

  while (1) {
    
    chassis.control_exponential(65, 3, 1.8);

  }
}



// Main will set up the competition functions and callbacks.

int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(20, msec);
  }
}
