#include "vex.h"

using namespace vex;
using signature = vision::signature;
using code = vision::code;

// A global instance of brain used for printing to the V5 Brain screen.
brain  Brain;

controller Controller = controller(vex::controllerType::primary);

//The motor constructor takes motors as (port, ratio, reversed), so for example
//motor LeftFront = motor(PORT1, ratio6_1, false);

//Add your devices below, and don't forget to do the same in robot-config.h:

inertial IMU = inertial(PORT14);


motor leftMotor1 = motor(PORT13, ratio6_1, true);
motor leftMotor2 = motor(PORT12, ratio6_1, true);
motor leftMotor3 = motor(PORT11, ratio6_1, false);

motor rightMotor1 = motor(PORT18, ratio6_1, false);
motor rightMotor2 = motor(PORT19, ratio6_1, false);
motor rightMotor3 = motor(PORT20, ratio6_1, true);


motor Intake = motor(PORT1, ratio6_1, false);
motor Outtake = motor(PORT10, ratio18_1, false);


distance Front = distance(PORT9);
distance Back = distance(PORT2);
distance ScoreDistance = distance(PORT3);
// aivision AIVision = aivision(PORT8);


pneumatics Wing = pneumatics(Brain.ThreeWirePort.C);
pneumatics Tongue = pneumatics(Brain.ThreeWirePort.A);
pneumatics Hood = pneumatics(Brain.ThreeWirePort.D);
pneumatics MiddleGoal = pneumatics(Brain.ThreeWirePort.F);


void vexcodeInit( void ) {
  // nothing to initialize
}