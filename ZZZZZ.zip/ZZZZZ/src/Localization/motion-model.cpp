#include "vex.h"
#include <array>
#include <random>
#include <math.h>

// Constants: forward tracker
// input: forward tracker position, sideways tracker position, orientation
// output: x, y, orientation


// forward tracker - center distance, size, 

std::mt19937 gen(std::random_device{}());


const int NUM_PARTICLES = 500;
const bool using_odom = true;

const double x_init_std_dev = 1.0;
const double y_init_std_dev = 1.0;



double k_rot_from_rot;     // rotation error proportional to rotation
double k_rot_from_trans;   // rotation error proportional to translation
double k_fwd_from_trans; // translation error proportional to translation
double k_fwd_from_rot;   // translation error proportional to rotation
double k_side_from_rot;
double k_side_from_trans;



std::array<double, NUM_PARTICLES> particles_x;
std::array<double, NUM_PARTICLES> particles_y;
std::array<double, NUM_PARTICLES> particles_weight;



double starting_x;
double starting_y;

extern rotation ForwardTracker;
extern rotation SidewaysTracker;
extern motor_group LeftDrive;
extern motor_group RightDrive;
float drivebase_wheel_diameter;
float forward_tracker_diameter;
float forward_tracker_offset;
float sideways_tracker_offset;

// every update cycle: 
// INPUTS: forward tracker position (degrees), 

// returns forward position in inches
// circumference = pi*d, theta/360 multiplied by circumference gives distance in inches

float to_rad (float angle_deg) {
  
    return ( angle_deg * M_PI / 180.0);

}


float get_forward_position () {

    if (using_odom) {
        return ForwardTracker.position(deg) * forward_tracker_diameter * M_PI / 360.0;
    } else {
        return ((LeftDrive.position(deg) + RightDrive.position(deg)) / 2.0) * drivebase_wheel_diameter * M_PI / 360.0;
    }
}

float get_sideways_position () {
    if (using_odom) {
        return SidewaysTracker.position(deg) * forward_tracker_diameter * M_PI / 360.0;
    } else {
        return 0.0;
    }
}



float forward_prev = 0;
float sideways_prev = 0;
float orientation_rad_prev = 0;

void idk_update_motion_model () {

    // finds forward delta and reassigns previous forward value
    float forward_curr = get_forward_position();
    float forward_delta = forward_curr - forward_prev;
    forward_prev = forward_curr;

    // finds sideways delta and reassigns previous sideways value
    float sideways_curr = get_sideways_position();
    float sideways_delta = sideways_curr - sideways_prev;
    sideways_prev = sideways_curr;

    // finds orientation delta and reassigns previous orientation value
    float orientation_rad_curr = to_rad(get_theta());
    float orientation_rad_delta = orientation_rad_curr - orientation_rad_prev;
    orientation_rad_prev = orientation_rad_curr;


    const float EPSILON = 1e-6; // 0.000001



    float local_x;
    float local_y;

    // fixes edge case where 
    if (fabs(orientation_rad_delta) < EPSILON) {
        local_x = sideways_delta;
        local_y = forward_delta;
    } else {
        // look into chord movement of robot
        local_x = (2*sin(orientation_rad_delta/2))*((sideways_delta/orientation_rad_delta)+sideways_tracker_offset); 
        local_y = (2*sin(orientation_rad_delta/2))*((forward_delta/orientation_rad_delta)+forward_tracker_offset);
    }




}

double odom_fwd_delta;
double odom_theta_delta;
double odom_side_delta;


double theta;
// make sure theta is converted from compass angles to real angles



// 
float get_theta() {



}


// 
void initParticles () {

    std::normal_distribution<double> n_init_x (0.0, x_init_std_dev);
    std::normal_distribution<double> n_init_y (0.0, y_init_std_dev);

    for (int i = 0; i < NUM_PARTICLES; i++) {

        particles_x[i] = starting_x + n_init_x (gen);
        particles_y[i] = starting_y + n_init_y (gen);
        particles_weight[i] = 1.0 / NUM_PARTICLES;

    }

}


// Updates every particle in the motion model after odom deltas are updated
void updateMotionModel () {

    double fwd_std_dev = k_fwd_from_trans * fabs(odom_fwd_delta) + k_fwd_from_rot * fabs(odom_theta_delta);
    double side_std_dev = k_side_from_trans * fabs(odom_fwd_delta) + k_side_from_rot * fabs(odom_theta_delta);

    std::normal_distribution<double> n_fwd (0.0, fwd_std_dev);
    std::normal_distribution<double> n_side (0.0, side_std_dev);

    double cos_theta = cos(theta);
    double sin_theta = sin(theta);

    for (int i = 0; i < NUM_PARTICLES; i++) {
        
        double particle_fwd_delta = odom_fwd_delta + n_fwd(gen);
        double particle_side_delta = odom_side_delta + n_side(gen);

        double particle_x_delta = particle_fwd_delta * cos_theta - particle_side_delta * sin_theta;
        double particle_y_delta = particle_fwd_delta * sin_theta + particle_side_delta * cos_theta;

        particles_x[i] += particle_x_delta;
        particles_y[i] += particle_y_delta;

    }

}