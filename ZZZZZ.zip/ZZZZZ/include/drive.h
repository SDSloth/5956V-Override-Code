#pragma once
#include "vex.h"

enum distance_sensor {front, back};


/**
 * Drive class supporting tank and holo drive, with or without odom.
 * Eight flavors of odom and six custom motion algorithms.
 */

class Drive
{
private:
  float wheel_diameter;
  float wheel_ratio;
  float gyro_scale;
  float drive_in_to_deg_ratio;
  float ForwardTracker_center_distance;
  float SidewaysTracker_center_distance;

public: 

  motor_group DriveL;
  motor_group DriveR;
  inertial Gyro;



  float turn_min_voltage;
  float turn_max_voltage;
  float turn_kp;
  float turn_ki;
  float turn_kd;
  float turn_starti;

  float drive_min_voltage;
  float drive_max_voltage;
  float drive_kp;
  float drive_ki;
  float drive_kd;
  float drive_starti;
  
  float heading_min_voltage;
  float heading_max_voltage;
  float heading_kp;
  float heading_ki;
  float heading_kd;
  float heading_starti;

  float swing_min_voltage;
  float swing_max_voltage;
  float swing_kp;
  float swing_ki;
  float swing_kd;
  float swing_starti;

  float vision_min_voltage;
  float vision_max_voltage;
  float vision_kp;
  float vision_ki;
  float vision_kd;
  float vision_starti;


  float turn_settle_error;
  float turn_settle_time;
  float turn_timeout;

  float drive_settle_error;
  float drive_settle_time;
  float drive_timeout;

  float swing_settle_error;
  float swing_settle_time;
  float swing_timeout;


  float boomerang_lead;
  float boomerang_setback;


  
  Drive(motor_group DriveL, motor_group DriveR, int gyro_port, float wheel_diameter, float wheel_ratio, float gyro_scale, float ForwardTracker_center_distance);

  void drive_with_voltage(float leftVoltage, float rightVoltage);

  float get_absolute_heading();

  float get_left_position_in();

  float get_right_position_in();

  // drive constants

  void set_turn_constants(float turn_min_voltage, float turn_max_voltage, float turn_kp, float turn_ki, float turn_kd, float turn_starti); 
  void set_drive_constants(float drive_min_voltage, float drive_max_voltage, float drive_kp, float drive_ki, float drive_kd, float drive_starti);
  void set_heading_constants(float heading_min_voltage, float heading_max_voltage, float heading_kp, float heading_ki, float heading_kd, float heading_starti);
  void set_swing_constants(float swing_min_voltage, float swing_max_voltage, float swing_kp, float swing_ki, float swing_kd, float swing_starti);
  void set_vision_constants(float vision_min_voltage, float vision_max_voltage, float vision_kp, float vision_ki, float vision_kd, float vision_starti);

  void set_turn_exit_conditions(float turn_settle_error, float turn_settle_time, float turn_timeout);
  void set_drive_exit_conditions(float drive_settle_error, float drive_settle_time, float drive_timeout);
  void set_swing_exit_conditions(float swing_settle_error, float swing_settle_time, float swing_timeout);

  // drive controls

  void control_tank(float percent);
  void control_tank();

  void control_arcade(float drive_percent, float turn_percent);
  void control_arcade(float percent);
  void control_arcade();

  void control_exponential(float percent, float power, float slew_rate);


  // drive basics

  void turn_to_angle(float angle);
  void turn_to_angle(float angle, float turn_min_voltage, float turn_max_voltage);
  void turn_to_angle(float angle, float turn_min_voltage, float turn_max_voltage, float turn_settle_error, float turn_settle_time, float turn_timeout);

  void drive_distance(float distance);
  void drive_distance(float distance, float heading);
  void drive_distance(float distance, float heading, float drive_min_voltage, float drive_max_voltage, float heading_min_voltage, float heading_max_voltage);
  void drive_distance(float distance, float heading, float drive_min_voltage, float drive_max_voltage, float heading_min_voltage, float heading_max_voltage, float drive_settle_error, float drive_settle_time, float drive_timeout);

  void left_swing_to_angle(float angle);
  void left_swing_to_angle(float angle, float swing_min_voltage, float swing_max_voltage);
  void left_swing_to_angle(float angle, float swing_min_voltage, float swing_max_voltage, float swing_settle_error, float swing_settle_time, float swing_timeout);
  
  void right_swing_to_angle(float angle);
  void right_swing_to_angle(float angle, float swing_min_voltage, float swing_max_voltage);
  void right_swing_to_angle(float angle, float swing_min_voltage, float swing_max_voltage, float swing_settle_error, float swing_settle_time, float swing_timeout);
  


  Odom odom;
  void set_coordinates(float X_position, float Y_position, float orientation_deg);
  void set_heading(float orientation_deg);
  void position_track();
  static int position_track_task();
  vex::task odom_task;
  float get_X_position();
  float get_Y_position();

  void drive_stop(vex::brakeType mode);

  void drive_to_point(float X_position, float Y_position);
  void drive_to_point(float X_position, float Y_position, float drive_min_voltage, float drive_max_voltage, float heading_max_voltage);
  void drive_to_point(float X_position, float Y_position, float drive_min_voltage, float drive_max_voltage, float heading_max_voltage, float drive_settle_error, float drive_settle_time, float drive_timeout);
  void drive_to_point(float X_position, float Y_position, float drive_min_voltage, float drive_max_voltage, float heading_max_voltage, float drive_settle_error, float drive_settle_time, float drive_timeout, float drive_kp, float drive_ki, float drive_kd, float drive_starti, float heading_kp, float heading_ki, float heading_kd, float heading_starti);
  
  void drive_to_pose(float X_position, float Y_position, float angle);
  void drive_to_pose(float X_position, float Y_position, float angle, float lead, float setback, float drive_min_voltage);
  void drive_to_pose(float X_position, float Y_position, float angle, float lead, float setback, float drive_min_voltage, float drive_max_voltage, float heading_max_voltage);
  void drive_to_pose(float X_position, float Y_position, float angle, float lead, float setback, float drive_min_voltage, float drive_max_voltage, float heading_max_voltage, float drive_settle_error, float drive_settle_time, float drive_timeout);
  void drive_to_pose(float X_position, float Y_position, float angle, float lead, float setback, float drive_min_voltage, float drive_max_voltage, float heading_max_voltage, float drive_settle_error, float drive_settle_time, float drive_timeout, float drive_kp, float drive_ki, float drive_kd, float drive_starti, float heading_kp, float heading_ki, float heading_kd, float heading_starti);
  
  void turn_to_point(float X_position, float Y_position);
  void turn_to_point(float X_position, float Y_position, float extra_angle_deg);
  void turn_to_point(float X_position, float Y_position, float extra_angle_deg, float turn_max_voltage, float turn_settle_error, float turn_settle_time, float turn_timeout);




  // added functions

  void drive_with_vision(float distance, float drive_min_voltage, float drive_max_voltage, float vision_min_voltage, float vision_max_voltage, float drive_settle_error, float drive_settle_time, float drive_timeout);
  void drive_with_vision(float distance, float drive_min_voltage, float drive_max_voltage, float vision_min_voltage, float vision_max_voltage);
  void drive_with_vision(float distance);

  void drive_with_front_distance(float distance, float heading, float drive_min_voltage, float drive_max_voltage, float heading_min_voltage, float heading_max_voltage, float drive_settle_error, float drive_settle_time, float drive_timeout);
  void drive_with_front_distance(float distance, float heading, float drive_min_voltage, float drive_max_voltage, float heading_min_voltage, float heading_max_voltage);
  void drive_with_front_distance(float distance, float heading);
  void drive_with_front_distance(float distance);

  void drive_with_back_distance(float distance, float heading, float drive_min_voltage, float drive_max_voltage, float heading_min_voltage, float heading_max_voltage, float drive_settle_error, float drive_settle_time, float drive_timeout);
  void drive_with_back_distance(float distance, float heading, float drive_min_voltage, float drive_max_voltage, float heading_min_voltage, float heading_max_voltage);
  void drive_with_back_distance(float distance, float heading);
  void drive_with_back_distance(float distance);



};


void AWB();