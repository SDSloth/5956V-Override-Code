#pragma once
#include "vex.h"

int intakeBlock();

int tongueToggle();
int wingToggle();
int hoodToggle();
int middleGoalToggle();