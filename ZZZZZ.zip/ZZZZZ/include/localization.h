#pragma once
#include "vex.h"

class Localization {

    private: 


    public: 
    


};