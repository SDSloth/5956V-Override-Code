using namespace vex;

extern brain Brain;

extern controller Controller;

//To set up a motor called LeftFront here, you'd use
//extern motor LeftFront;

//Add your devices below, and don't forget to do the same in robot-config.cpp:

extern inertial IMU;


extern motor leftMotor1;
extern motor leftMotor2;
extern motor leftMotor3;

extern motor rightMotor1;
extern motor rightMotor2;
extern motor rightMotor3;


extern motor Intake;
extern motor Outtake;


extern distance Front;
extern distance Back;
extern distance ScoreDistance;
// extern aivision AIVision;


extern pneumatics Wing;
extern pneumatics Tongue;
extern pneumatics Hood;
extern pneumatics MiddleGoal;


void  vexcodeInit( void );