#pragma once
#include "drive.h"

class Drive;

extern Drive chassis;

void clearLoader(float time, float heading);
void scoreLongGoal(float time);

void default_constants();
void setup();

void skills();
