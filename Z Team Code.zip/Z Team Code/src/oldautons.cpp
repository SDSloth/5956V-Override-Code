#include "vex.h"
using namespace vex;


void breakHold() {
    
    lBase1.stop(hold);
    lBase2.stop(hold);
    lBase3.stop(hold);
    rBase1.stop(hold);
    rBase2.stop(hold);
    rBase3.stop(hold);

}

void breakCoast() {

    lBase1.stop(coast);
    lBase2.stop(coast);
    lBase3.stop(coast);
    rBase1.stop(coast);
    rBase2.stop(coast);
    rBase3.stop(coast);

}


void Skills1()
{

    Inertial20.setHeading(180, deg);
    chassis.set_coordinates(65, 16, 180);
    // clear parking area
    chassis.drive_to_point(65, 24);
    frontdistanceNew(44, 180, 12, 8, 1, 300, 3000000);
    // clear
    // chassis.drive_to_point(47, -47);
    // tongueToggle();
    // frontdistanceNew(6.8, 270, 8, 0, 1, 300, 3000);

    // chassis.drive_to_point(65, -28);
    /*
        // drive to next area
        chassis.turn_to_point(47, -47);
        chassis.drive_to_point(47, -47);
        Intake.stop();
        Transition.stop();
        chassis.turn_to_point(61, -47);
        */
    wait(30000000, msec);

    // pick up blocks from tube
    Intake.spin(forward, 100, pct);
    Transition.spin(forward, 100, pct);
    Tongue.open();
    chassis.drive_to_point(155, -120);
    wait(2, sec);
    Tongue.close();
    Intake.stop();
    Transition.stop();

    // score on first goal
    chassis.drive_to_point(70, -120);
    LeftWing.open();
    RightWing.open();
    Intake.spin(forward, 100, pct);
    Transition.spin(forward, 100, pct);
    Outtake.spin(forward, 100, pct);
    wait(2, sec);
    Intake.stop();
    Transition.stop();
    Outtake.stop();
    LeftWing.close();
    RightWing.close();

    // drive to next area
    chassis.drive_to_point(120, -120);
    chassis.turn_to_point(0, -60);
    chassis.drive_to_point(0, -60);
    chassis.turn_to_point(-120, -120);
    chassis.drive_to_point(-120, -120);
    chassis.turn_to_point(-155, -120);
    wait(30, msec);

    // pick up blocks from tube
    Intake.spin(forward, 100, pct);
    Transition.spin(forward, 100, pct);
    Tongue.open();
    chassis.drive_to_point(-155, -120);
    wait(2, sec);
    Tongue.close();
    Intake.stop();
    Transition.stop();

    // score on first goal
    chassis.drive_to_point(-70, -120);
    LeftWing.open();
    RightWing.open();
    Intake.spin(forward, 100, pct);
    Transition.spin(forward, 100, pct);
    Outtake.spin(forward, 100, pct);
    wait(2, sec);
    Intake.stop();
    Transition.stop();
    Outtake.stop();
    LeftWing.close();
    RightWing.close();

    // drive to next area
    chassis.drive_to_point(-120, -120);
    chassis.turn_to_point(-165, -45);
    chassis.drive_to_point(-165, -45);

    // clear parking area
    chassis.turn_to_point(-165, -65);
    chassis.drive_to_point(-165, -65);
    chassis.drive_to_point(-165, 45);
}

void Skills2()
{
    Inertial20.setHeading(0, deg);
    // matchloader unload
    frontdistanceNew(16.5, 0, 8, 0, 1, 300, 3000);
    Tongue.open();
    chassis.turn_to_angle(90);
    Intake.spin(forward, 100, pct);
    Transition.spin(forward, 100, pct);
    Outtake.spin(forward, 100, pct);
    wait(200, msec);
    frontdistanceNew(5.9, 90, 2, 0, 1, 300, 3000);
    wait(1500, msec);
    // score long goal
    Intake.spin(forward, 0, pct);
    Transition.spin(forward, 0, pct);
    Outtake.spin(forward, 0, pct);
    chassis.drive_distance(-5);
    Tongue.close();
    LeftWing.open();
    RightWing.open();
    chassis.drive_max_voltage = 5;
    chassis.drive_distance(-35);
    Intake.spin(forward, 100, pct);
    Transition.spin(forward, 100, pct);
    Outtake.spin(forward, 100, pct);
    wait(4000, msec);
    // control bonus
    /*
    frontdistanceNew(14, 90, 6, 0, 1, 300, 3000);
    LeftWing.close();
    RightWing.close();
    chassis.turn_to_angle(260);
    chassis.drive_max_voltage=12;
    chassis.drive_distance(16);
    */
    // new parts
    // middle blocks
    frontdistanceNew(14, 90, 6, 0, 1, 300, 3000);
    LeftWing.close();
    RightWing.close();
    chassis.turn_to_angle(225);
    chassis.drive_max_voltage = 3;
    chassis.drive_distance(35.5);
    chassis.turn_to_angle(180);
    chassis.drive_max_voltage = 8;
    chassis.drive_distance(35);
    chassis.drive_max_voltage = 3;
    chassis.drive_distance(15);
    chassis.drive_max_voltage = 8;
    chassis.turn_to_angle(135);
    chassis.drive_distance(28.5);
    // second long goal
    chassis.turn_to_angle(90);
    Intake.spin(forward, 0, pct);
    Transition.spin(forward, 0, pct);
    Outtake.spin(forward, 0, pct);
    LeftWing.open();
    RightWing.open();
    chassis.drive_max_voltage = 5;
    chassis.drive_distance(-20);
    Intake.spin(forward, 100, pct);
    Transition.spin(forward, 100, pct);
    Outtake.spin(forward, 100, pct);
    wait(4000, msec);
    // second match loader
    frontdistanceNew(14, 90, 6, 0, 1, 300, 3000);
    LeftWing.close();
    RightWing.close();
    Tongue.open();
    frontdistanceNew(6, 90, 3, 0, 1, 300, 3000);
    wait(1600, msec);
    // score long goal again
    Intake.spin(forward, 0, pct);
    Transition.spin(forward, 0, pct);
    Outtake.spin(forward, 0, pct);
    chassis.drive_distance(-5);
    Tongue.close();
    LeftWing.open();
    RightWing.open();
    chassis.drive_max_voltage = 5;
    chassis.drive_distance(-35);
    Intake.spin(forward, 100, pct);
    Transition.spin(forward, 100, pct);
    Outtake.spin(forward, 100, pct);
    wait(4000, msec);
    // park
    chassis.drive_max_voltage = 8;
    chassis.drive_distance(10);
    chassis.turn_to_angle(0);
    chassis.drive_distance(30);
    // chassis.turn_to_angle(90);
    frontdistanceNew(65, 0, 8, 0, 1, 300, 3000);
    chassis.turn_to_angle(90);
    chassis.drive_distance(-5);
    chassis.drive_distance(50);

    //

    /*
    chassis.turn_to_angle(0);
    chassis.drive_distance(16);
    chassis.drive_max_voltage=8;
    wait(20,msec);
    Intake.spin(forward, 0, pct);
    Transition.spin(forward, 0, pct);
    Outtake.spin(forward, 0, pct);
    chassis.drive_distance(-16);
    chassis.turn_to_angle(90);
    LeftWing.open();
    RightWing.open();
    chassis.drive_distance(-20);
    Intake.spin(forward, 100, pct);
    Transition.spin(forward, 100, pct);
    Outtake.spin(forward, 100, pct);
    */

    // chassis.set_coordinates(48, 0, 0);

    // chassis.drive_to_point(48, 48);
    // chassis.turn_to_point(48, 60);
    // chassis.drive_to_point(-165, -45);
}

void Skills3()
{
    //int
    Inertial20.setHeading(0, deg);
    chassis.set_coordinates(0, 0, 0);
    chassis.drive_max_voltage = 10;

    // matchloader unload
    frontdistanceNew(16.5, 0, 10, 0, 1, 300, 3000);
    chassis.turn_to_angle(90);

    Intake.spin(forward, 100, pct);
    Transition.spin(forward, 100, pct);
    Outtake.spin(forward, 100, pct);
    task t1076(antijam);

    Tongue.open();
    wait(250, msec);

    frontdistanceNew(6, 90, 4, 0, 1, 300, 3000);
    wait(1200, msec);

    // score long goal
    t1076.suspend();
    Intake.spin(forward, 0, pct);
    Transition.spin(forward, 0, pct);
    Outtake.spin(forward, 0, pct);

    chassis.drive_max_voltage = 10;
    chassis.drive_distance(-5);

    Tongue.close();
    LeftWing.open();
    RightWing.open();

    chassis.drive_max_voltage = 4;
    chassis.drive_distance(-31);
    t1076.resume();
    Intake.spin(forward, 100, pct);
    Transition.spin(forward, 100, pct);
    Outtake.spin(forward, 100, pct);
    
    wait(2800, msec);

    // second match loader
    frontdistanceNew(17, 90, 9, 0, 1, 300, 3000);

    LeftWing.close();
    RightWing.close();
    
    chassis.turn_to_angle(180);
    frontdistanceNew(16.5, 180, 10, 0, 1, 300, 3000);   
    chassis.turn_to_angle(90);

    Intake.spin(forward, 100, pct);
    Transition.spin(forward, 100, pct);
    Outtake.spin(forward, 100, pct);
    //t1076.resume();

    Tongue.open();

    wait(250, msec);
    frontdistanceNew(6, 90, 4, 0, 1, 300, 3000);
    // wait(1500, msec);
    wait(1200, msec);

    // score second long goal
    t1076.suspend();
    Intake.spin(forward, 0, pct);
    Transition.spin(forward, 0, pct);
    Outtake.spin(forward, 0, pct);

    chassis.drive_max_voltage = 6;
    chassis.drive_distance(-5);

    Tongue.close();
    LeftWing.open();
    RightWing.open();

    chassis.drive_max_voltage = 7;
    chassis.drive_distance(-33);
    t1076.resume();
    Intake.spin(forward, 100, pct);
    Transition.spin(forward, 100, pct);
    Outtake.spin(forward, 100, pct);

    wait(2800, msec);

    // go to otherside of field
    frontdistanceNew(18, 90, 9, 0, 1, 300, 3000);

    LeftWing.close();
    RightWing.close();

    chassis.turn_to_angle(0);
    chassis.drive_distance(20);

    chassis.turn_to_angle(270);

   // wait(300000000000, sec);
    chassis.drive_distance(72);
    frontdistanceNew(16, 270, 10, 0, 1, 300, 3000);

    // unload third matchloader
    chassis.turn_to_angle(180);
    frontdistanceNew(16.5, 180, 10, 0, 1, 300, 3000);

    chassis.turn_to_angle(270);

    Intake.spin(forward, 100, pct);
    Transition.spin(forward, 100, pct);
    Outtake.spin(forward, 100, pct);
    //t1076.resume();

    Tongue.open();
    wait(250, msec);

    frontdistanceNew(5.9, 270, 5, 0, 1, 300, 3000);
    // wait(1500, msec);

    // score third long goal
    t1076.suspend();
    Intake.spin(forward, 0, pct);
    Transition.spin(forward, 0, pct);
    Outtake.spin(forward, 0, pct);

    chassis.drive_max_voltage = 10;
    
    chassis.drive_distance(-5);

    Tongue.close();
    LeftWing.open();
    RightWing.open();

    chassis.drive_max_voltage = 7;
    chassis.turn_to_angle(271);
    chassis.drive_distance(-33);
    t1076.resume();
    Intake.spin(forward, 100, pct);
    Transition.spin(forward, 100, pct);
    Outtake.spin(forward, 100, pct);

    wait(2500, msec);
     //clearblueparkzone
    chassis.drive_max_voltage = 10;
    chassis.turn_to_angle(313);
    chassis.drive_distance(40);
    LeftWing.close();
    RightWing.close();

    //wait(300000000000, sec);

    chassis.turn_to_angle(0);
    chassis.drive_max_voltage = 12;
    frontdistanceNew(50, 0, 12, 0, 1, 300, 3000);
    
    // to 4th match loader
    chassis.drive_max_voltage = 10;
    chassis.turn_to_angle(90);
    chassis.drive_distance(12);

    // 4th match loader
    chassis.turn_to_angle(0);
    frontdistanceNew(16.5, 0, 10, 0, 1, 300, 3000);

    chassis.turn_to_angle(270);

    Intake.spin(forward, 100, pct);
    Transition.spin(forward, 100, pct);
    Outtake.spin(forward, 100, pct);
    //t1076.resume();

    Tongue.open();
    wait(200, msec);

    frontdistanceNew(5.9, 270, 5, 0, 1, 300, 3000);

    // score long 4thgoal
    t1076.suspend();
    Intake.spin(forward, 0, pct);
    Transition.spin(forward, 0, pct);
    Outtake.spin(forward, 0, pct);

    chassis.drive_max_voltage = 10;
    chassis.drive_distance(-5);

    Tongue.close();
    LeftWing.open();
    RightWing.open();

    chassis.drive_max_voltage = 7;
    chassis.drive_distance(-33);
    t1076.resume();
    Intake.spin(forward, 100, pct);
    Transition.spin(forward, 100, pct);
    Outtake.spin(forward, 100, pct);
    wait(2500, msec);

    // go park
    frontdistanceNew(16, 270, 10, 0, 1, 300, 3000);

    LeftWing.close();
    RightWing.close();

    chassis.drive_max_voltage = 10;
    chassis.turn_to_angle(180);
    chassis.drive_distance(20);

    chassis.turn_to_angle(90);
    frontdistanceNew(2, 90, 10, 0, 1, 300, 3000);

    chassis.turn_to_angle(180);
    chassis.drive_max_voltage = 12;
    chassis.drive_distance(24);
    
}
void RightQuals()
{
    Inertial20.setHeading(0, deg);
    chassis.set_coordinates(0, 0, 0);
    // 3 block pickup
    chassis.drive_max_voltage = 10;
    chassis.turn_to_angle(17);
    Intake.spin(forward, 100, pct);
    Transition.spin(forward, 75, pct);
    Outtake.spin(forward, 50, pct);
    chassis.drive_max_voltage = 10;
    chassis.drive_distance(20);
    chassis.drive_max_voltage = 5;
    chassis.drive_distance(5);
    chassis.drive_max_voltage = 10;
    Intake.spin(forward, 0, pct);
    Transition.spin(forward, 0, pct);
    Outtake.spin(forward, 0, pct);
    // score low goal.
    chassis.turn_to_angle(318);
    chassis.drive_distance(16);
    Intake.spin(forward, -100, pct);
    Transition.spin(forward, -100, pct);
    Outtake.spin(forward, -100, pct);
    wait(1000, msec);
    Intake.spin(forward, 0, pct);
    Transition.spin(forward, 0, pct);
    Outtake.spin(forward, 0, pct);
    chassis.drive_distance(-34);
    chassis.turn_to_angle(90);
    // unload match loader
    wait(30, msec);
    frontdistanceNew(16.5, 90, 8, 0, 1, 300, 3000);
    Tongue.open();
    chassis.turn_to_angle(180);
    Intake.spin(forward, 100, pct);
    Transition.spin(forward, 100, pct);
    Outtake.spin(forward, 100, pct);
    wait(100, msec);
    // chassis.drive_distance(2);
    frontdistanceNew(5, 180, 6, 0, 1, 300, 2000);
    // wait(100, msec);
    // score long goal
    Intake.spin(forward, 0, pct);
    Transition.spin(forward, 0, pct);
    Outtake.spin(forward, 0, pct);
    chassis.drive_distance(-5);
    Tongue.close();
    LeftWing.open();
    RightWing.open();
    chassis.turn_to_angle(180);
    chassis.drive_max_voltage = 6;
    chassis.drive_distance(-25);
    Intake.spin(forward, 100, pct);
    Transition.spin(forward, 100, pct);
    Outtake.spin(forward, 100, pct);

    /*
        backdistanceNew(22, -45, 8, 5, 1, 300, 3000000);
        Tongue.open();
        Intake.spin(forward, 100, pct);
        Transition.spin(forward, 100, pct);
        Outtake.spin(forward, 100, pct);
        frontdistanceNew(6.8, 180, 8, 0, 1, 300, 3000000);
        */
}
 
void RightElims()
{
    Inertial20.setHeading(0, deg);
    chassis.set_coordinates(0, 0, 0);
    // 3 block pickup
    chassis.drive_max_voltage = 10;
    chassis.turn_to_angle(15);
    Intake.spin(forward, 100, pct);
    Transition.spin(forward, 75, pct);
    Outtake.spin(forward, 50, pct);
    chassis.drive_max_voltage = 10;
    chassis.drive_distance(22);
    chassis.drive_max_voltage = 5;
    chassis.drive_distance(8);
    chassis.drive_max_voltage = 10;
    Intake.spin(forward, 0, pct);
    Transition.spin(forward, 0, pct);
    Outtake.spin(forward, 0, pct);
    chassis.turn_to_angle(0);
    backdistanceNew(16, 0, 8, 0, 1, 300, 3000);
    chassis.turn_to_angle(90);
    // unload match loader
    // wait(30, msec);
    frontdistanceNew(16.5, 90, 8, 0, 1, 300, 3000);
    Tongue.open();
    chassis.turn_to_angle(180);
    Intake.spin(forward, 100, pct);
    Transition.spin(forward, 100, pct);
    Outtake.spin(forward, 100, pct);
    wait(100, msec);
    // chassis.drive_distance(2);
    frontdistanceNew(5, 180, 6, 0, 1, 300, 2000);
    // wait(100, msec);
    // score long goal
    Intake.spin(forward, 0, pct);
    Transition.spin(forward, 0, pct);
    Outtake.spin(forward, 0, pct);
    chassis.drive_distance(-5);
    Tongue.close();
    LeftWing.open();
    RightWing.open();
    chassis.turn_to_angle(180);
    chassis.drive_max_voltage = 6;
    chassis.drive_distance(-25);
    Intake.spin(forward, 100, pct);
    Transition.spin(forward, 100, pct);
    Outtake.spin(forward, 100, pct);
    wait(2500, msec);
    Intake.spin(forward, 0, pct);
    Transition.spin(forward, 0, pct);
    Outtake.spin(forward, 0, pct);
}

void LeftElims()
{
    Inertial20.setHeading(0, deg);
    chassis.set_coordinates(0, 0, 0);
    // 3 block pickup
    chassis.drive_max_voltage = 10;
    chassis.turn_to_angle(345);
    Intake.spin(forward, 100, pct);
    Transition.spin(forward, 75, pct);
    Outtake.spin(forward, 50, pct);
    chassis.drive_max_voltage = 10;
    chassis.drive_distance(20);
    chassis.drive_max_voltage = 5;
    chassis.drive_distance(8);
    chassis.drive_max_voltage = 10;
    Intake.spin(forward, 0, pct);
    Transition.spin(forward, 0, pct);
    Outtake.spin(forward, 0, pct);
    chassis.turn_to_angle(0);
    backdistanceNew(16, 0, 8, 0, 1, 300, 3000);
    chassis.turn_to_angle(90);
    // unload match loader
    // wait(30, msec);
    frontdistanceNew(16.5, 270, 8, 0, 1, 300, 3000);
    Tongue.open();
    chassis.turn_to_angle(180);
    Intake.spin(forward, 100, pct);
    Transition.spin(forward, 100, pct);
    Outtake.spin(forward, 100, pct);
    wait(100, msec);
    // chassis.drive_distance(2);
    frontdistanceNew(5, 180, 6, 0, 1, 300, 2000);
    // wait(100, msec);
    // score long goal
    Intake.spin(forward, 0, pct);
    Transition.spin(forward, 0, pct);
    Outtake.spin(forward, 0, pct);
    chassis.drive_distance(-5);
    Tongue.close();
    LeftWing.open();
    RightWing.open();
    chassis.turn_to_angle(180);
    chassis.drive_max_voltage = 6;
    chassis.drive_distance(-25);
    Intake.spin(forward, 100, pct);
    Transition.spin(forward, 100, pct);
    Outtake.spin(forward, 100, pct);
}

void SoloAWP() {

}