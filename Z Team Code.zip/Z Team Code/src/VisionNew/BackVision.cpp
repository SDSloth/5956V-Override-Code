#include "vex.h"
using namespace vex;

aivision::colordesc AIVision2__BLUEBOX(1, 84, 199, 237, 29, 0.36);
aivision::colordesc AIVision2__REDBOX(2, 243, 109, 110, 28, 0.52);
aivision::colordesc AIVision2__GREENBOX(1, 179, 122, 19, 17, 0.2);
aivision::colordesc AIVision2__Green(3, 151, 70, 26, 16, 0.2);
enum gameElements {
  mobileGoal,

  redRing,
  blueRing,
};
//aivision::colordesc AIVision1__GREENBOX(3, 66, 117, 48, 10, 0.2);
// AI Vision Code Definitions
vex::aivision AIVision2(PORT8, AIVision2__BLUEBOX, AIVision2__GREENBOX, AIVision2__REDBOX, AIVision2__Green);
//vex::aivision AIVision2(PORT21, aivision::ALL_AIOBJS);


void BackdistanceVisionST(int desiredValue, float desiredTurnValue, int speed, float speeds, float settle_error, float settle_time, float timeout) {
 T1.clear();

 settled = false;
 time_spent_running = 0;
 time_spent_settled = 0;
 z = Inertial20.heading();
 if (redringb)
    AIVision2.takeSnapshot(AIVision2__REDBOX);
    else if (blueringb)
    AIVision2.takeSnapshot(AIVision2__BLUEBOX);
    else if (greengoalb)
    AIVision2.takeSnapshot(AIVision2__GREENBOX);
    else if (greenb)
    AIVision2.takeSnapshot(AIVision2__Green);

 //error =  RTMG.objectDistance(mm) - desiredValue;
 error =  desiredValue - Goaldistance.objectDistance(inches);
  while (!settled) {

    //error =  RTMG.objectDistance(mm) - desiredValue;
    error =  desiredValue - Goaldistance.objectDistance(inches);

  if (Goaldistance.objectDistance(inches)<=0 || Goaldistance.objectDistance(inches)>=195)
    {
      error = prevError-1.1;
    }

    if (fabs(error) < starti){
    totalError += error;
    }
     // Checks if the error has crossed 0, and if it has, it eliminates the integral term.
    if ((error>0 && prevError<0)||(error<0 && prevError>0)){ 
    totalError = 0; 
    }

    derivative = error - prevError;

    double lateralMotorPower = error * dkP + derivative * dkD + totalError * dkI;
    /////////////////////////////////////////////////////////////////////

    prevError = error;

    if (lateralMotorPower > speed) {
        lateralMotorPower = speed;
      }
   
      else if (lateralMotorPower < -speed) {
        lateralMotorPower = -speed;
      }

      if (lateralMotorPower>0 && lateralMotorPower < speeds && speeds > 0) 
      {
        lateralMotorPower = speeds;
      }
      else if (lateralMotorPower<0 && lateralMotorPower > -speeds && speeds > 0) 
      {
        lateralMotorPower = -speeds;
      }
  
    //int dturnDifference = leftMotorPosition - rightMotorPosition;
    if (redringb)
    AIVision2.takeSnapshot(AIVision2__REDBOX);
    else if (blueringb)
    AIVision2.takeSnapshot(AIVision2__BLUEBOX);
    else if (greengoalb)
    AIVision2.takeSnapshot(AIVision2__GREENBOX);
    else if (greenb)
    AIVision2.takeSnapshot(AIVision2__Green);
  
   float turnDifference1 = AIVision2.objects[0].centerX - desiredTurnValue;
      
    if (fabs(turnDifference1) < istarti){
    turnTotalError += turnDifference1;
    }
     // Checks if the error has crossed 0, and if it has, it eliminates the integral term.
    if ((turnDifference1>0 && turnPrevError<0)||(turnDifference1<0 && turnPrevError>0)){ 
    turnTotalError = 0; 
    }

    turnDerivative = turnDifference1 - turnPrevError;

    double turnMotorPower = turnDifference1 * vbturnkP + turnDerivative * vbturnkD + turnTotalError * vbturnkI;
    /////////////////////////////////////////////////////////////////////
    turnPrevError = turnDifference1;
      
      
     if (turnMotorPower > speed) {
        turnMotorPower = speed;
      }
   
      else if (turnMotorPower < -speed) {
        turnMotorPower = -speed;
      }

  
      lBase1.spin(forward, lateralMotorPower + turnMotorPower,voltageUnits::volt);
      lBase2.spin(forward, lateralMotorPower + turnMotorPower,voltageUnits::volt);
      lBase3.spin(forward, lateralMotorPower + turnMotorPower,voltageUnits::volt);             
      rBase1.spin(forward, lateralMotorPower - turnMotorPower,voltageUnits::volt);
      rBase2.spin(forward, lateralMotorPower - turnMotorPower,voltageUnits::volt);
      rBase3.spin(forward, lateralMotorPower - turnMotorPower,voltageUnits::volt);
     

 if(fabs(error)<settle_error){
        time_spent_settled+=10;
   }
   else { 
        time_spent_settled = 0;
   }

   time_spent_running+=10;


  if (time_spent_running>timeout && timeout != 0){
    settled = true;
  }
 else if (time_spent_settled>settle_time){
    settled = true;
  }
else
  settled = false;



if(goalexit)
{  
if (backClaw.value() == 0)
  {
  break;
  }

}

if(lineexit)
{
  if(linetrackerL.reflectivity(percent)>70)
  break;

  if(linetrackerR.reflectivity(percent)>70)
  break;
}

if(breakout)
{
  if(error>breakdistance)
  break;
}
    
    //printf("error %f\tturndifference %f\tfrontdistance %f\ttimespentsettled %f\ttimerunning %f\n", error, turnDifference1, Frontdistance.objectDistance(mm),time_spent_settled, time_spent_running);
    printf("centerX %d\tcenterY %d\terror %f\tturndifference %lf\tdistance %0.1f\n",AIVision2.objects[0].centerX, AIVision2.objects[0].centerY, error, turnDifference1, Goaldistance.objectDistance(inches));
    wait(20, msec);
    
  }
   lBase2.setPosition(0, degrees);
   rBase2.setPosition(0, degrees);
   lBase1.spin(fwd, 0, pct);
   lBase2.spin(fwd, 0, pct);
   lBase3.spin(fwd, 0, pct);
   rBase1.spin(fwd, 0, pct);
   rBase2.spin(fwd, 0, pct);
   rBase3.spin(fwd, 0, pct);

}





void BackturnVisionST(float desiredTurnValue, float turnspeed, float turnspeed1, float settle_error, float settle_time, float timeout) {
 
  settled = false;
  time_spent_running = 0;
  time_spent_settled = 0;

 
  z = Inertial20.heading();
  
  if (redringb)
  AIVision2.takeSnapshot(AIVision2__REDBOX);
  else if (blueringb)
  AIVision2.takeSnapshot(AIVision2__BLUEBOX);
  else if (greengoalb)
  AIVision2.takeSnapshot(AIVision2__GREENBOX);
  else if (greenb)
  AIVision2.takeSnapshot(AIVision2__Green);
    ///////////////////////////////////////////
    // Turning movement PID
    wait (10, msec);

  while (!AIVision2.objects[0].exists) {

  if (redringb)
  AIVision2.takeSnapshot(AIVision2__REDBOX);
  else if (blueringb)
  AIVision2.takeSnapshot(AIVision2__BLUEBOX);
  else if (greengoalb)
  AIVision2.takeSnapshot(AIVision2__GREENBOX);
  else if (greenb)
  AIVision2.takeSnapshot(AIVision2__Green);

    lBase1.spin(forward, turnspeed1, voltageUnits::volt);
    lBase2.spin(forward, turnspeed1, voltageUnits::volt);
    lBase3.spin(forward, turnspeed1, voltageUnits::volt);
    rBase1.spin(forward, -turnspeed1, voltageUnits::volt);  //right
    rBase2.spin(forward, -turnspeed1, voltageUnits::volt);
    rBase3.spin(forward, -turnspeed1, voltageUnits::volt);
    ///////////////////////////////////////////
    // Turning movement PID
  }
  
  
   turnError =   AIVision2.objects[0].centerX - desiredTurnValue;
    
   
   while (!settled) {
  if (redringb)
  AIVision2.takeSnapshot(AIVision2__REDBOX);
  else if (blueringb)
  AIVision2.takeSnapshot(AIVision2__BLUEBOX);
  else if (greengoalb)
  AIVision2.takeSnapshot(AIVision2__GREENBOX);
  else if (greenb)
  AIVision2.takeSnapshot(AIVision2__Green);

    turnError =   AIVision2.objects[0].centerX - desiredTurnValue;
    // Derivative
    turnDerivative = turnError - turnPrevError;

    // Integral
    if (fabs(error) < integralBound) {
      turnTotalError += turnError;
    } else {
      turnTotalError = 0;
    }
    // turnTotalError = turnTotalError + turnError;

    // This would cap the integral
    turnTotalError = fabs(turnTotalError) > maxIntegral
                         ? signnum_c(turnTotalError) * maxIntegral
                         : turnTotalError;

    double turnMotorPower =
        turnError * vturnkP + turnDerivative * vturnkD + turnTotalError * vturnkI;

    
      if (turnMotorPower > turnspeed) {
        turnMotorPower = turnspeed;
      }
   
      else if (turnMotorPower < -turnspeed) {
        turnMotorPower = -turnspeed;
      }
    

    /////////////////////////////////////////////////////////////////////

    
      lBase1.spin(forward, turnMotorPower, voltageUnits::volt);
      lBase2.spin(forward, turnMotorPower, voltageUnits::volt);
      lBase3.spin(forward, turnMotorPower, voltageUnits::volt);
      rBase1.spin(forward, -turnMotorPower, voltageUnits::volt);  //right
      rBase2.spin(forward, -turnMotorPower, voltageUnits::volt);
      rBase3.spin(forward, -turnMotorPower, voltageUnits::volt);
    


   turnPrevError = turnError;

   if(fabs(turnError)<settle_error){
        time_spent_settled+=10;
   }
   else { 
        time_spent_settled = 0;
   }

   time_spent_running+=10;


  if (time_spent_running>timeout && timeout != 0){
    settled = true;
  }
  else if (time_spent_settled>settle_time){
    settled = true;
  }
else
  settled = false;


    //printf("centerX %d\toriginX %d/tcenterY %d\t error%d\t motorpower%lf\n",FrontVision1.largestObject.centerX, FrontVision1.largestObject.originX, FrontVision1.largestObject.centerY, vturnError, vturnMotorPower);
   printf("centerX %d\toriginX %d\tcenterY %d\t error%f\t motorpower%lf\n",AIVision2.objects[0].centerX, AIVision2.objects[0].originX, AIVision2.objects[0].centerY, turnError, turnMotorPower);
 wait(10, msec);
    
  }
   
   lBase1.spin(fwd, 0, pct);
   lBase2.spin(fwd, 0, pct);
   lBase3.spin(fwd, 0, pct);
   rBase1.spin(fwd, 0, pct);
   rBase2.spin(fwd, 0, pct);
   rBase3.spin(fwd, 0, pct);
  }




void scanB(int desiredValue, int turnspeed1) 
{ 
v=0;
int i = 0;
int t = 0;
T1.clear();
int e = turnspeed1;
while(t<=1 && v==0 && T1.value()<3)
{
while (i<=1 && v==0 && T1.value()<3)
{
    lBase2.setPosition(0, degrees);
    while(fabs(lBase2.position(degrees))<desiredValue && v==0 && T1.value()<4)
    {
    if (redringb)
    AIVision2.takeSnapshot(AIVision2__REDBOX);
    else if (blueringb)
    AIVision2.takeSnapshot(AIVision2__BLUEBOX);
    else if (greengoalb)
    AIVision2.takeSnapshot(AIVision2__GREENBOX);
    else if (greenb)
    AIVision2.takeSnapshot(AIVision2__Green);

    lBase1.spin(forward, turnspeed1, voltageUnits::volt);
    lBase2.spin(forward, turnspeed1, voltageUnits::volt);
    lBase3.spin(forward, turnspeed1, voltageUnits::volt);
    rBase1.spin(forward, -turnspeed1, voltageUnits::volt);  //right
    rBase2.spin(forward, -turnspeed1, voltageUnits::volt);
    rBase3.spin(forward, -turnspeed1, voltageUnits::volt);


    if(AIVision2.objects[0].exists && AIVision2.objects[0].width>70) 
    {   
        lBase1.stop(hold);
        lBase2.stop(hold);
        lBase3.stop(hold);
        rBase1.stop(hold);
        rBase2.stop(hold);
        rBase3.stop(hold);
        v=1;
    }
    }  
    i++;
    if (turnspeed1 >0)
    turnspeed1 = -turnspeed1 - 3;
    else if (turnspeed1 <0)
    turnspeed1 = -turnspeed1 + 3; 
  } 
    i=0;  
    turnspeed1 = -e;
    t++;
}  
        lBase1.stop(hold);
        lBase2.stop(hold);
        lBase3.stop(hold);
        rBase1.stop(hold);
        rBase2.stop(hold);
        rBase3.stop(hold);
  
}

  
void AWBB()
{
 
  AIVision2.startAwb();
   wait(20, msec);
}



void BackstraightVisionST(int desiredValue, float desiredTurnValue, int speed, int speeds, float settle_error, float settle_time, float timeout) 
{
T1.clear();
settled = false;
time_spent_running = 0;
time_spent_settled = 0;

lBase2.setPosition(0, degrees);
rBase2.setPosition(0, degrees);

//AIVision1.takeSnapshot(AIVision1__BLUEBOX);
if (redringb)
    AIVision2.takeSnapshot(AIVision2__REDBOX);
    else if (blueringb)
    AIVision2.takeSnapshot(AIVision2__BLUEBOX);
    else if (greengoalb)
    AIVision2.takeSnapshot(AIVision2__GREENBOX);
    else if (greenb)
    AIVision2.takeSnapshot(AIVision2__Green);

//error =  lBase2.position(degrees) - desiredValue;
error = desiredValue - ((rBase2.position(degrees) + lBase2.position(degrees))/2);
if (AIVision2.objects[0].exists)
{
while (!settled) {
//while(true){
    // Get the position of both motors
    float averagePosition = (rBase2.position(degrees) + lBase2.position(degrees))/2;
    //int rightMotorPosition = rBase2.position(degrees);
     error = desiredValue - averagePosition;
    
    if (fabs(error) < starti){
    totalError += error;
    }
     // Checks if the error has crossed 0, and if it has, it eliminates the integral term.
    if ((error>0 && prevError<0)||(error<0 && prevError>0)){ 
    totalError = 0; 
    }

    derivative = error - prevError;

    lateralMotorPower = error * kP + derivative * kD + totalError * kI;
    /////////////////////////////////////////////////////////////////////
    prevError = error;
    
      if (lateralMotorPower > speed) 
      {
        lateralMotorPower = speed;
      }
      else if (lateralMotorPower < - speed) 
      {
        lateralMotorPower = -speed;
      }

      if (lateralMotorPower>0 && lateralMotorPower < speeds && speeds > 0) 
      {
        lateralMotorPower = speeds;
      }
      else if (lateralMotorPower<0 && lateralMotorPower > -speeds && speeds > 0) 
      {
        lateralMotorPower = -speeds;
      }
      


    if (redringb)
    AIVision2.takeSnapshot(AIVision2__REDBOX);
    else if (blueringb)
    AIVision2.takeSnapshot(AIVision2__BLUEBOX);
    else if (greengoalb)
    AIVision2.takeSnapshot(AIVision2__GREENBOX);
    else if (greenb)
    AIVision2.takeSnapshot(AIVision2__Green);
  
   float turnDifference1 = AIVision2.objects[0].centerX - desiredTurnValue;
    
   if (fabs(turnDifference1) < istarti){
    turnTotalError += turnDifference1;
    }
     // Checks if the error has crossed 0, and if it has, it eliminates the integral term.
    if ((turnDifference1>0 && turnPrevError<0)||(turnDifference1<0 && turnPrevError>0)){ 
    turnTotalError = 0; 
    }

    turnDerivative = turnDifference1 - turnPrevError;

    double turnMotorPower = turnDifference1 * vturnkP + turnDerivative * vturnkD + turnTotalError * vturnkI;
    /////////////////////////////////////////////////////////////////////
    turnPrevError = turnDifference1;


if (turnMotorPower > speed) {
        turnMotorPower = speed;
      }
   
      else if (turnMotorPower < -speed) {
        turnMotorPower = -speed;
      }   

  
      lBase1.spin(forward, lateralMotorPower + turnMotorPower,voltageUnits::volt);
      lBase2.spin(forward, lateralMotorPower + turnMotorPower,voltageUnits::volt);
      lBase3.spin(forward, lateralMotorPower + turnMotorPower, voltageUnits::volt);              
      rBase1.spin(forward, lateralMotorPower - turnMotorPower, voltageUnits::volt);
      rBase2.spin(forward, lateralMotorPower - turnMotorPower, voltageUnits::volt);
      rBase3.spin(forward, lateralMotorPower - turnMotorPower, voltageUnits::volt);
        

  if(fabs(error)<settle_error){
        time_spent_settled+=10;
   }
   else { 
        time_spent_settled = 0;
   }

   time_spent_running+=10;


  if (time_spent_running>timeout && timeout != 0){
    settled = true;
  }
  else if (time_spent_settled>settle_time){
    settled = true;
  }
  else 
  settled = false;

/*
if (backClaw.value() == 0)
  {
  break;
  }
*/

if (yexit)
{
  if (AIVision2.objects[0].centerY>=200) //60
  break;
}


if(lineexit)
{
  if(linetrackerL.reflectivity(percent)>70)
  break;

  if(linetrackerR.reflectivity(percent)>70)
  break;
}

//$$$$$$$$$$$$$startnew
/*
if (g==1)        
{
  while(g==1)
  {
   lBase1.spin(fwd, 0, pct);
    lBase2.spin(fwd, 0, pct);
    lBase3.spin(fwd, 0, pct);
    
    rBase1.spin(fwd, 0, pct);
    rBase2.spin(fwd, 0, pct);
    rBase3.spin(fwd, 0, pct);
  }
  
}  
  */                
//$$$$$$$$$$$$$$$$$endnew


   //printf("error %0.1f\tlatteralpower %0.1f\tturndifference %0.1f\tInertial %0.1f\ttimespentsettled %0.1f\ttimerunning %0.1f\n",error, lateralMotorPower, turnDifference1, Inertial20.heading(), time_spent_settled, time_spent_running);
   //wait(10, msec);
   //printf("X %d\tY %d\t W %d\tH %d\terror%f\t turndifference%lf\n",AIVision1.objects[0].centerX, AIVision1.objects[0].centerY, AIVision1.objects[0].width, AIVision1.objects[0].height, error, turnDifference1);
    wait(10, msec);

  }
  //printf("error %f\tturndifference %f\tInertial %f\n",error, turnDifference1, Inertial20.heading());
   //lBase2.setPosition(0, degrees);
   //rBase2.setPosition(0, degrees);
    /*
    lBase1.spin(fwd, 0, pct);
    lBase2.spin(fwd, 0, pct);
    lBase3.spin(fwd, 0, pct);
    
    rBase1.spin(fwd, 0, pct);
    rBase2.spin(fwd, 0, pct);
    rBase3.spin(fwd, 0, pct);
*/
    lBase1.stop(coast);
    lBase2.stop(coast);
    lBase3.stop(coast);
    
    rBase1.stop(coast);
    rBase2.stop(coast);
    rBase3.stop(coast);
    
}
}
