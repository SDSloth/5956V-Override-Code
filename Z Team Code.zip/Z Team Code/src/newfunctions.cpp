#include "vex.h"
using namespace vex;

// Driver functions





int tongueToggle() {
  while(1) {
    if(Controller1.ButtonY.pressing()) {
      if (Tongue.value() == 1) {
        Tongue.close();
      }
      else {
        Tongue.open();
      }

      waitUntil(!Controller1.ButtonY.pressing());
  }

}

  return 0;
}

int intakeBlock() {
  while(1) {
      if (Controller1.ButtonR1.pressing()) {
        if (Hood.value() == 0) {
          Intake.spin(forward, 100, pct);
          Outtake.stop();
        } else {
          Intake.spin(forward, 100, pct);
          Outtake.spin(forward, 100, pct);
        }
      }
      else if (Controller1.ButtonR2.pressing()) {

        Intake.spin(reverse, 100, pct);
        Outtake.spin(reverse, 100, pct);
      }
      else if (Controller1.ButtonL1.pressing()) {
        Outtake.spin(reverse, 100, pct);
        Intake.spin(reverse, 80, pct);
        wait(0.15, sec);
        Intake.spin(forward, 80, pct);
        waitUntil(!Controller1.ButtonL1.pressing());
      }
      else if (Controller1.ButtonL2.pressing()) {
        Outtake.spin(reverse, 100, pct);
        Intake.spin(reverse, 10, pct);
        waitUntil(!Controller1.ButtonL2.pressing());
      }
      else {
        Intake.stop();
        Outtake.stop();
      }
      
  }

  return 0;
}

int wingToggle() {
  while(1) {
    if(Controller1.ButtonB.pressing()) {
      if (Wing.value() == 1) {
        Wing.close();
      } else {
        Wing.open();
      }

      waitUntil(!Controller1.ButtonB.pressing());
  }

}

  return 0;
}


int hoodToggle() {
  while(1) {
    if(Controller1.ButtonA.pressing()) {
      if (Hood.value() == 1) {
        Hood.close();
      } else {
        Hood.open();
      }

      waitUntil(!Controller1.ButtonA.pressing());
  }

}

  return 0;
}

int parkToggle() {
  while(1) {
    if(Controller1.ButtonX.pressing()) {
      if (DoublePark.value() == 1) {
        DoublePark.close();
      } else {
        DoublePark.open();
      }

      waitUntil(!Controller1.ButtonX.pressing());
  }

}

  return 0;
}






int oldIntakeBlock() {
  while(1) {

    if (Controller1.ButtonR1.pressing()) {
      Intake.spin(forward, 100, pct);
      Transition.spin(forward, 100, pct);
      Outtake.spin(forward, 100, pct);
    }
    else if (Controller1.ButtonR2.pressing()) {
      Intake.spin(reverse, 100, pct);
      Transition.spin(reverse, 100, pct);
      Outtake.spin(reverse, 100, pct);
    }
    else if (Controller1.ButtonL1.pressing()) {
      Intake.spin(forward, 100, pct);
      Transition.spin(forward, 100, pct);
      Outtake.spin(reverse, 100, pct);
    }
    else {
      Intake.stop();
      Transition.stop();
      Outtake.stop();
    }
      
  }

  return 0;
}

int rightWingToggle() {
  while(1) {
    if(Controller1.ButtonRight.pressing()) {
      if (RightWing.value() == 1) {
        RightWing.close();
      }
      else {
        RightWing.open();
      }
      waitUntil(!Controller1.ButtonRight.pressing());
    }
  }
  return 0;
}

int leftWingToggle() {
  while(1) {
    if(Controller1.ButtonLeft.pressing()) {
      if (LeftWing.value() == 1) {
        LeftWing.close();
      }
      else {
        LeftWing.open();
      }

      waitUntil(!Controller1.ButtonLeft.pressing());
  }

}

  return 0;
}


int oldWingToggle() {
  while(1) {
    if(Controller1.ButtonA.pressing()) {
      if (LeftWing.value() == 1) {
        LeftWing.close();
        RightWing.close();
      }
      else if (RightWing.value() == 1) {
        RightWing.close();
      }
      else {
        LeftWing.open();
        RightWing.open();
      }

      waitUntil(!Controller1.ButtonA.pressing());
  }

}

  return 0;
}