#include "vex.h"
using namespace vex;







void leftSAWP() {
    
    AWB();
    AWBB();
    AWBI();
    g = 0;
    greengoalb = true;
    
    Inertial20.setHeading(65, deg);
    chassis.set_coordinates(0, 0, 65);

    chassis.drive_distance(19.5, 65, 3, 10, 10);
    Intake.spin(fwd, 100, pct);
    //Tongue.open();
    chassis.drive_distance(19.5, 65, 3, 5, 10);
    //Tongue.close();
    Intake.stop();
    chassis.left_swing_to_angle(315);
    //Intake.spin(reverse, 100, pct);
    chassis.drive_distance(-13, 315, 3, 6, 6);
    Intake.spin(fwd,85,pct);
    Outtake.spin(reverse,60,pct);
    wait(2,sec);
    Intake.stop();
    Outtake.stop();

    breakdistance = 10;
    breakout = true;
    chassis.drive_distance(46.5, 319, 10, 10, 10);
    chassis.turn_to_angle(270);
    breakout = false;

    Tongue.open();
    Intake.spin(forward, 100, pct);
    breakHold();
    wait(0.2,sec);
    frontdistanceNew(7.9, 270, 6, 5, 1, 0, 1200);
    wait(.65,sec); // 1.75
    chassis.drive_distance(-37, 270, 10, 10, 10, 1, 0, 1000);
    //BackstraightVisionST(-2400, 160, 6, 0, 5, 0, 1200);
    Outtake.spin(forward, 100, pct);
    wait(0.15,sec);
    Tongue.close();
    Hood.open();
    //Outtake.spin(forward, 100, pct);
    wait(2,sec); // 2.75
    breakCoast();

    chassis.right_swing_to_angle(186);
    chassis.drive_distance(68, 186, 4, 10, 10);
    chassis.right_swing_to_angle(45);
    Intake.spin(fwd,75,pct);
    chassis.drive_distance(18, 45, 7, 7, 10);
    Intake.stop();
    chassis.drive_distance(8, 45, 4, 4, 10);
    Outtake.spin(reverse,100,pct);
    Intake.spin(reverse,100,pct);
    wait(1.8,sec);
    Outtake.stop();
    Intake.stop();


}


void newleftelims() {

    AWB();
    AWBB();
    AWBI();
    g = 0;
    greengoalb = true;
    
    Inertial20.setHeading(65, deg);
    chassis.set_coordinates(0, 0, 65);

    chassis.drive_distance(19.5, 65, 3, 10, 10);
    Intake.spin(fwd, 100, pct);
    //Tongue.open();
    chassis.drive_distance(19.5, 65, 3, 5, 10);
    //Tongue.close();
    Intake.stop();
    chassis.left_swing_to_angle(315);
    //Intake.spin(reverse, 100, pct);
    chassis.drive_distance(-13, 315, 3, 6, 6);
    Intake.spin(fwd,85,pct);
    Outtake.spin(reverse,60,pct);
    wait(2,sec);
    Intake.stop();
    Outtake.stop();

    breakdistance = 10;
    breakout = true;
    chassis.drive_distance(46.5, 319, 10, 10, 10);
    chassis.turn_to_angle(270);
    breakout = false;

    Tongue.open();
    Intake.spin(forward, 100, pct);
    breakHold();
    wait(0.2,sec);
    frontdistanceNew(7.9, 270, 6, 5, 1, 0, 1200);
    wait(.65,sec); // 1.75
    chassis.drive_distance(-37, 270, 10, 10, 10, 1, 0, 1000);
    //BackstraightVisionST(-2400, 160, 6, 0, 5, 0, 1200);
    Outtake.spin(forward, 100, pct);
    wait(0.15,sec);
    Tongue.close();
    Hood.open();
    //Outtake.spin(forward, 100, pct);
    wait(2,sec); // 2.75
    breakCoast();
    

    chassis.left_swing_to_angle(0);
    frontdistanceNew(3, 0, 5, 0, 1, 0, 1200);
    chassis.turn_to_angle(270);
    chassis.drive_distance(-19, 268, 1, 5, 6);


}




void newrightelims() {
    
    AWB();
    AWBB();
    AWBI();
    g = 0;
    greengoalb = true;

    Inertial20.setHeading(115, deg);
    chassis.set_coordinates(0, 0, 115);
    
    Intake.spin(fwd, 100, pct);
    chassis.drive_distance(15.5, 115, 3, 10, 10);
    chassis.drive_distance(8, 115, 1, 2, 10);
    Tongue.open();
    wait(0.2,sec);
    chassis.turn_max_voltage = 5;
    chassis.right_swing_to_angle(45);
    Tongue.close();
    chassis.turn_max_voltage = 10;
    chassis.drive_distance(2, 45, 3, 6, 6);
    Intake.stop();
    chassis.drive_distance(8, 45, 3, 6, 6);
    Outtake.spin(reverse,100,pct);
    Intake.spin(reverse,100,pct);
    wait(2,sec);
    Outtake.stop();

    breakdistance = -10;
    breakoutR = true;

    chassis.drive_distance(-46.25, 34, 10, 10, 10);
    chassis.turn_to_angle(270);
    breakoutR = false;
    
    Tongue.open();
    Intake.spin(forward, 100, pct);
    breakHold();
    wait(0.2,sec);
    frontdistanceNew(7.9, 270, 6, 5, 1, 0, 1200);
    wait(.65,sec); // 1.75
    chassis.drive_distance(-37, 270, 10, 10, 10, 1, 0, 1000);
    //BackstraightVisionST(-2400, 160, 6, 0, 5, 0, 1200);
    Outtake.spin(forward, 100, pct);
    wait(0.15,sec);
    Tongue.close();
    Hood.open();
    //Outtake.spin(forward, 100, pct);
    wait(2,sec); // 2.75
    breakCoast();

    chassis.left_swing_to_angle(0);
    backdistanceNew(31.3, 0, 5, 0, 1, 0, 1200);
    chassis.turn_to_angle(270);
    chassis.drive_distance(-19, 272, 1, 5, 6);

}



void newskills() {
    
    
    AWB();
    AWBB();
    AWBI();
    g = 0;
    greengoalb = true;

    
    Inertial20.setHeading(65, deg);
    chassis.set_coordinates(0, 0, 65);

    // pick up first blocks
    Wing.open();
    chassis.drive_distance(19.5, 65, 3, 10, 10);
    Intake.spin(fwd, 100, pct);
    //Tongue.open();
    chassis.drive_distance(19.5, 65, 3, 5, 10);
    //Tongue.close();
    Intake.stop();
    chassis.left_swing_to_angle(315);
    //Intake.spin(reverse, 100, pct);
    chassis.drive_distance(-13, 315, 3, 6, 6);
    Intake.spin(fwd,85,pct);
    Outtake.spin(reverse,60,pct);
    wait(3,sec);
    Outtake.stop();

    chassis.drive_distance(55, 319, 3, 10, 10);
    chassis.turn_to_angle(270);
    //BackstraightVisionST(-2400, 160, 11, 0, 5, 0, 1200);

    // gets first loader

    // gets bot ready to reach loader
    Tongue.open();
    Intake.spin(forward, 100, pct);
    breakHold();
    wait(0.2,sec);

    // moves to loader
    frontdistanceNew(7.9, 270, 6, 5, 1, 0, 1200);
    wait(1.5,sec);
    breakCoast();
    Intake.stop();
    
    // moves to next goal
    breakdistance = -10;
    breakoutR = true;
    chassis.drive_distance(-50, 245, 10, 10, 10);
    Tongue.close();
    chassis.drive_distance(-20, 270, 10, 10, 10);
    breakoutR = false;
    chassis.drive_distance(-40, 270, 10, 10, 10);
    chassis.right_swing_to_angle(0);
    chassis.right_swing_to_angle(90);
    chassis.drive_distance(-16, 90, 10, 10, 10, 1, 0, 800);
    // BackstraightVisionST(-1350, 160, 6, 0, 5, 0, 1200);

    // scores next goal
    scoreLongGoal(2.75);

    // gets second loader
     // gets bot ready to reach loader
    Tongue.open();
    Intake.spin(forward, 100, pct);
    breakHold();
    wait(0.2,sec);

    // moves to loader
    frontdistanceNew(7.9, 90, 6, 5, 1, 0, 1200);
    wait(1.5,sec);
    breakCoast();
    Intake.stop();


    chassis.drive_distance(-37, 90, 10, 10, 10, 1, 0, 1000);
    Tongue.close();
    // BackstraightVisionST(-2400, 160, 6, 0, 5, 0, 1200);

    // scores again
    scoreLongGoal(2.75);
    
    
    
    // **SECOND STAGE**
    
    // Inertial20.setHeading(90, deg);
    // chassis.set_coordinates(0,0,90);

    // goes over parking zone
    Intake.spin(fwd, 100, pct);
    frontdistanceNew(5.8, 130, 5, 0, 1, 0, 1400);
    chassis.left_swing_to_angle(177);
    chassis.drive_distance(50, 179, 10, 10, 10);
    frontdistanceNew(42, 182, 10, 10, 1, 0, 2000);
    chassis.drive_distance(10.5, 210, 10, 10, 10);

    //wait(1000,sec);


    // moves to goal
    chassis.right_swing_to_angle(90);
    chassis.drive_distance(-37, 90, 10, 10, 10, 1, 0, 1000);
    //BackstraightVisionST(-2400, 160, 11, 0, 5, 0, 1200);


    // scores middle goal
    scoreLongGoal(2.75);


    // gets next loader
     // gets bot ready to reach loader
    Tongue.open();
    Intake.spin(forward, 100, pct);
    breakHold();
    wait(0.2,sec);

    // moves to loader
    frontdistanceNew(7.9, 90, 6, 5, 1, 0, 1200);
    wait(1.5,sec);
    breakCoast();
    Intake.stop();

    // moves to next goal
    breakdistance = -10;
    breakoutR = true;
    chassis.drive_distance(-50, 65, 10, 10, 10);
    Tongue.close();
    chassis.drive_distance(-20, 90, 10, 10, 10);
    breakoutR = false;
    chassis.drive_distance(-40, 90, 10, 10, 10);
    chassis.right_swing_to_angle(180);
    chassis.right_swing_to_angle(270);
    chassis.drive_distance(-16, 270, 10, 10, 10, 1, 0, 1000);
    //BackstraightVisionST(-1350, 160, 6, 0, 5, 0, 1200);

    // scores next goal
    scoreLongGoal(2.75);

    // gets last loader
     // gets bot ready to reach loader
    Tongue.open();
    Intake.spin(forward, 100, pct);
    breakHold();
    wait(0.2,sec);

    // moves to loader
    frontdistanceNew(7.9, 270, 6, 5, 1, 0, 1200);
    wait(1.5,sec);
    breakCoast();
    Intake.stop();

    chassis.drive_distance(-37, 270, 10, 10, 10, 1, 0, 1000);
    Tongue.close();
    //BackstraightVisionST(-2400, 160, 6, 0, 5, 0, 1200);

    // scores again
    scoreLongGoal(2.75);
    
    // final parking zone
    breakdistance = 10;
    breakout = true;
    Intake.spin(fwd, 100, pct);
    frontdistanceNew(5.8, 310, 5, 0, 1, 0, 1400);
    chassis.left_swing_to_angle(357);
    chassis.drive_distance(35, 359, 10, 10, 10);
    breakout = false;
    Intake.stop();

}






void badsawp() {

    Inertial20.setHeading(180, deg);
    chassis.set_coordinates(0, 0, 180);

    frontdistanceNew(21, 165, 10, 7, 1, 0, 1200);
    chassis.turn_to_angle(270,6,7,2,0,500);

    Tongue.open();
    Intake.spin(forward, 100, pct);
    breakHold();
    wait(0.2,sec);

    // moves to loader
    frontdistanceNew(7.9, 270, 6, 5, 1, 0, 1200);
    wait(0.75,sec);
    Intake.stop();

    //clearLoader(0.65, 270);

    frontdistanceNew(37.5, 268, 6, 5, 1, 0, 1200);
    Tongue.close();
    breakCoast();


    // scores again
    scoreLongGoal(2.1);

    chassis.turn_to_angle(0);

    Intake.spin(fwd,75,pct);
    chassis.drive_distance(22,10,2,2,10);
    Intake.stop();
    chassis.drive_distance(-8,0,4,7,10);
    chassis.turn_to_angle(45);
    chassis.drive_distance(17,45,2,6,10);
    Outtake.spin(reverse,100,pct);
    Intake.spin(reverse,100,pct);
    wait(1.8,sec);
    Outtake.stop();
    Intake.stop();
    wait(100,sec);





    chassis.drive_distance(67.5,5,2,6,10);
    Intake.stop();
    chassis.left_swing_to_angle(315);
    chassis.drive_distance(-16,315,6,7,10);
    Intake.spin(fwd,85,pct);
    Outtake.spin(reverse,60,pct);
    wait(1.8,sec);
    Intake.stop();
    Outtake.stop();




}


void simpleSkills() {
        Intake.spin(forward, 100, pct);

    chassis.drive_distance(24, 0, 1, 8, 6);

}

void rightSAWP() {
    
    AWB();
    AWBB();
    AWBI();
    g = 0;
    greengoalb = true;

    Inertial20.setHeading(115, deg);
    chassis.set_coordinates(0, 0, 115);
    
    chassis.drive_distance(23.5, 115, 3, 10, 10);
    chassis.right_swing_to_angle(45);
    chassis.drive_distance(8, 45, 3, 6, 6);

    breakdistance = -10;
    breakoutR = true;

    chassis.drive_distance(-41.5, 34, 10, 10, 10);
    chassis.turn_to_angle(270);
    breakoutR = false;
    frontdistanceNew(4, 270, 5, 0, 1, 0, 1200);
    BackstraightVisionST(-1400, 160, 11, 0, 5, 0, 1200);
    wait(0.4, sec);

    chassis.left_swing_to_angle(354);
    chassis.left_swing_to_angle(11.5);
    chassis.drive_distance(71, 17, 4, 10, 10);
    chassis.left_swing_to_angle(315);
    chassis.drive_distance(-10, 315, 7, 7, 10);


}