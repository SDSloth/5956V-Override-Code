#include "vex.h"
#include "vex_addrled.h"

using namespace vex;
using signature = vision::signature;
using code = vision::code;

// A global instance of brain used for printing to the V5 Brain screen
brain  Brain;

controller Controller1(vex::controllerType::primary);
controller Controller2(vex::controllerType::partner);

motor ringliftL(PORT22, true);
gps GPS8 = gps(PORT22, -3, 4, inches, 0); //19
motor ringliftR(PORT22, false);

motor intake(PORT22, ratio6_1, false);
motor hook(PORT22, false);

motor lBase1(PORT13, ratio6_1, true); //5 true        // old 5      new 13
motor lBase2(PORT12, ratio6_1, true);                 // old 6      new 12
motor lBase3(PORT11, ratio6_1, false);                // old 4      new 11

motor rBase1(PORT18, ratio6_1, false); //false        // old 8      new 18
motor rBase2(PORT19, ratio6_1, false);                // old 10     new 19
motor rBase3(PORT20, ratio6_1, true);                 // old 9      new 20

motor Intake = motor(PORT1, ratio6_1, false);         // old 20     new 1
motor Transition = motor(PORT22, ratio18_1, true);    // old 3      new 22
motor Outtake = motor(PORT10, ratio18_1, false);      // old 2      new 10

pneumatics RightWing = pneumatics(Brain.ThreeWirePort.G);
pneumatics LeftWing = pneumatics(Brain.ThreeWirePort.G);
pneumatics Wing = pneumatics(Brain.ThreeWirePort.C);
pneumatics Tongue = pneumatics(Brain.ThreeWirePort.A);
pneumatics DoublePark = pneumatics(Brain.ThreeWirePort.B);
pneumatics Hood = pneumatics(Brain.ThreeWirePort.D);

line linetrackerL = line(Brain.ThreeWirePort.G);
line linetrackerR = line(Brain.ThreeWirePort.G);
line linetrackerLB = line(Brain.ThreeWirePort.G);
line linetrackerRB = line(Brain.ThreeWirePort.G);
triport Expander7 = triport(PORT22);
//led LED3A = led(Expander3.A);
//pneumatics lbp = pneumatics(Expander7.A);
//pneumatics doinkR = pneumatics(Expander7.B);
//limit limitSwitch = limit(Expander7.B);

inertial Inertial20 = inertial(PORT14); 

distance Frontdistance = distance(PORT9);
distance Backdistance = distance(PORT2);
distance Goaldistance = distance(PORT22);
distance ring = distance(PORT22);
distance intakedistance = distance(PORT22);
distance Leftdistance = distance(PORT22);
distance Rightdistance = distance(PORT22);

//limit limitSwitch = limit(Brain.ThreeWirePort.J);
limit limitSwitch = limit(Expander7.B);


pneumatics backClaw(Brain.ThreeWirePort.G);
pneumatics doinkR(Brain.ThreeWirePort.G);
pneumatics doinkL(Brain.ThreeWirePort.G);
pneumatics lbp(Brain.ThreeWirePort.G);
pneumatics lbp2(Brain.ThreeWirePort.G);




//distance Leftdistance = distance(PORT20);
//distance Rightdistance = distance(PORT9 );
distance RTMG = distance(PORT22);

rotation rotationARM = rotation(PORT22, false);
optical Optical1 = optical(PORT22); //left
optical Optical2 = optical(PORT22);



motor flywheel(PORT22, true);

motor cata(PORT22, false);
motor cata2(PORT22, false);

//motor intaketop(PORT20,true);
motor intaketop(PORT22,false);

motor lift(PORT22, false);



 

motor intake2(PORT22, false);

/*
motor lBase1(PORT11, ratio18_1, true); //5 true
motor lBase2(PORT3, ratio18_1, true);
motor lBase3(PORT4, ratio18_1, true);

motor rBase1(PORT9, ratio18_1, false); //false
motor rBase2(PORT8, ratio18_1, false);
motor rBase3(PORT7, ratio18_1, false);
*/






//pneumatics PTOleftPnmtc(Brain.ThreeWirePort.B);
//pneumatics PTOrightPnmtc(Brain.ThreeWirePort.C);
//pneumatics WL(Brain.ThreeWirePort.H);
//pneumatics WR(Brain.ThreeWirePort.H);
//pneumatics WBL(Brain.ThreeWirePort.H);
//pneumatics WBR(Brain.ThreeWirePort.H);
pneumatics WL = pneumatics(Expander7.B);
pneumatics WR = pneumatics(Expander7.B);
pneumatics WBL = pneumatics(Expander7.B);
pneumatics WBR = pneumatics(Expander7.B);

//digital_out WL = digital_out(Brain.ThreeWirePort.A);
//digital_out WR = digital_out(Brain.ThreeWirePort.D);

//pneumatics IL(Brain.ThreeWirePort.H); 
//pneumatics IR(Brain.ThreeWirePort.H);
//pneumatics H(Brain.ThreeWirePort.H);
//pneumatics N(Brain.ThreeWirePort.H);
//pneumatics Ratchet(Brain.ThreeWirePort.H);
//pneumatics block(Brain.ThreeWirePort.H);
pneumatics IL = pneumatics(Expander7.B);
pneumatics IR = pneumatics(Expander7.B);
pneumatics H = pneumatics(Expander7.B);
pneumatics N = pneumatics(Expander7.B);
pneumatics Ratchet = pneumatics(Expander7.B);
pneumatics block = pneumatics(Expander7.B);


//pneumatics ringclaw(Brain.ThreeWirePort.H);
//pneumatics PTO(Brain.ThreeWirePort.H);
//pneumatics Arm(Brain.ThreeWirePort.H);
//pneumatics Claw(Brain.ThreeWirePort.H);
pneumatics ringclaw = pneumatics(Expander7.B);
pneumatics PTO = pneumatics(Expander7.B);
pneumatics Arm = pneumatics(Expander7.B);
pneumatics Claw = pneumatics(Expander7.B);

//pneumatics rapid(Brain.ThreeWirePort.H);
//pneumatics expand(Brain.ThreeWirePort.H);
//pneumatics deflect(Brain.ThreeWirePort.H);
pneumatics rapid = pneumatics(Expander7.B);
pneumatics expand = pneumatics(Expander7.B);
pneumatics deflect = pneumatics(Expander7.B);


rotation rotations = rotation(PORT22, true);
rotation rotation1 = rotation(PORT22, true);







optical Optical3 = optical(PORT22); 
optical Optical4 = optical(PORT22);



timer T1;
timer T2;
timer T3;
//triport Expander3 = triport(PORT3);
//led LED3A = led(Expander3.A);

//sonar frontSonar(Brain.ThreeWirePort.G);
//sonar backSonar(Brain.ThreeWirePort.E);
//signature Vision6__YELLOWDISK = signature (1, 699, 1405, 1052, -4893, -3823, -4358, 3.2, 0);
//vision Vision6 = vision (PORT6, 50, Vision6__YELLOWDISK);
vision frontVision(PORT22);
vision frontVision1(PORT22);
//vision backVision(PORT12);
//aivision AIVision2 (PORT12);


//motor_group LeftDriveSmart(lBase1, lBase2, lBase3);


//motor_group RightDriveSmart(rBase1, rBase2, rBase3);

//inertial TurnGyroSmart(PORT20);

//smartdrive Drivetrain(LeftDriveSmart, RightDriveSmart, GPS8, 299.24, 320, 40, mm, 0.6 );



/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void vexcodeInit( void ) {
  // nothing to initialize
}