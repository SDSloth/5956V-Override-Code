#include "vex.h"
using namespace vex;

int armNoPID() {

while(ringliftL.position(degrees)<=adesiredValue && g==0)
      {
        ringliftL.spin(fwd, 100, pct);
        ringliftR.spin(fwd, 100, pct);
        printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
      }
      ringliftL.spin(fwd, 0, pct);
      ringliftR.spin(fwd, 0, pct);
      ringliftL.stop(hold);
      ringliftR.stop(hold);
      g=1;

      return 0;

}