#include "vex.h"
using namespace vex;

int armPID() {

//rotationARM.setPosition(0, degrees);
//ringliftL.setPosition(0, degrees);
aerror = adesiredValue - ringliftL.position(degrees);
while (true) {

    aerror = adesiredValue - ringliftL.position(degrees);
    
    aderivative = aerror - aprevError;
    // Integral
    if (fabs(aerror) > integralBound) {
      atotalError += aerror; // totalError = totalError + error;
    } else {
      atotalError = 0;
    }
    // This would cap the integral
    atotalError = fabs(atotalError) > maxIntegral? signnum_c(atotalError) * maxIntegral: atotalError;
   
    alateralMotorPower = aerror * akP + aderivative * akD + atotalError * akI;
    /////////////////////////////////////////////////////////////////////

      if (alateralMotorPower > aspeed) 
      {
        alateralMotorPower = aspeed;
      }
      else if (alateralMotorPower < - aspeed) 
      {
        alateralMotorPower = -aspeed;
      }

    ringliftL.spin(forward, alateralMotorPower, voltageUnits::volt);
    ringliftR.spin(forward, alateralMotorPower, voltageUnits::volt);
     
    aprevError = aerror;

   //printf("armposition %f\terror %f\n",rotationARM.position(degrees), error);
   wait(10, msec);

  }
   //ringlift.spin(fwd, 0, pct);
   return 0;
}
