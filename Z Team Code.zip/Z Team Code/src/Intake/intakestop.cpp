#include "vex.h"
using namespace vex;

int intakestop() { 

  while (1) 
  {
    difference =  fabs(intake.position(degrees) - previouspostition);
    if (difference >= 450)
    {
        previouspostition = intake.position(degrees);
    }
    printf("differnce %0.1f\previouspostition %0.1f\tencoder %0.1f\n",difference, previouspostition, intake.position(degrees));
    task::sleep(10);
    
  }
  return(0);
}

 int intakestop2()
  {
    while (difference <=450 && g==0)
    {
         task::sleep(10);
    }
    g = 1;
    intake.stop();

    return 0;
  }

int intakereverse() { 

  while (1) 
  {
    task::sleep(100);
    difference =  fabs(intake.position(degrees) - previouspostition);
    timediff = T2.value() - previoustime;
    
    previouspostition = fabs(intake.position(degrees));
    previoustime = T2.value();
    //printf("differnce %0.1f\previouspostition %0.1f\tencoder %0.1f\n",difference, previouspostition, intake.position(degrees));
    
  }
  return(0);
}