#include "vex.h"
using namespace vex;

int intakeringLB() { 
  intake.spin(reverse, 100, pct);
  wait(0.1, sec);
  L=0;
  while(1)
  {
    while(L==0)
    {
      
  while((intakedistance.objectDistance(mm)>20 || intakedistance.objectDistance(mm)<=0) && L==0)
        //while(!Controller1.ButtonL2.pressing() && !Controller1.ButtonL1.pressing())
        {
          
          intake.spin(reverse, 100, pct);
          if(intake.velocity(rpm)<=10 && intake.velocity(rpm)>=0)
          {
            intake.spin(fwd, 100, pct);
            wait(0.25, sec); 
            intake.spin(reverse, 100, pct);
            wait(0.15, sec); 
           
          }
          task::sleep(10);
        }
        
         
        // L=1;
         intake.spin(reverse, 100, pct); 
         wait(0.5, sec); //.25
         //lbp.open();
         intake.stop(); 
         //lbp.open();
         //L=1;
         intake.spin(fwd, 80, pct); 
         wait(.1, sec);
         intake.stop(coast); 
        
         adesiredValue = 170;
         wait(0.25, sec); 
        lbp2.open();
        L=1;
        wait(0.25, sec); 
        adesiredValue = 400;
         
         
      }
      task::sleep(10);
    }
          
    return 0;
  }