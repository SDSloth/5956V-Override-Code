#include "vex.h"
using namespace vex;

int intakering2() { 
  intake.spin(reverse, 100, pct);
  wait(0.1, sec);

  while(1)
  {
    /*
  while((ring.objectDistance(inches)>2 || ring.objectDistance(inches)<=0)&& L==0)
        //while(!Controller1.ButtonL2.pressing() && !Controller1.ButtonL1.pressing())
        {
        
          intake.spin(reverse, 100, pct);
          
          if(intake.velocity(rpm)<=100 && intake.velocity(rpm)>=0)
          {
           intake.spin(fwd, 100, pct);
           wait(0.25, sec); 
           intake.spin(reverse, 100, pct);
           wait(0.15, sec); 
           
          }
          task::sleep(10);
        }
*/
        while((intakedistance.objectDistance(mm)>50 || intakedistance.objectDistance(mm)<=0)&& L==0)
        //while(!Controller1.ButtonL2.pressing() && !Controller1.ButtonL1.pressing())
        {
        
          intake.spin(reverse, 70, pct);
          if(intake.velocity(rpm)<=10 && intake.velocity(rpm)>=0)
          {
            intake.stop();
            //intake.spin(fwd, 100, pct);
            wait(0.15, sec); 
            intake.spin(reverse, 100, pct);
            wait(0.15, sec); 
           
          }
          task::sleep(10);
         
        }

         intake.stop(hold); 
         //intake.spin(fwd, 25, pct); 
         //wait(0.3, sec);
         intake.stop(); 
         L=1;
         task::sleep(10);
      }    
  
    return 0;
  }