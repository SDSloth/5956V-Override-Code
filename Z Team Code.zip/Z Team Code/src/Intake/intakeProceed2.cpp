#include "vex.h"
using namespace vex;

int intakeProceed2()
{     
 while((intakedistance.objectDistance(mm)>50 || intakedistance.objectDistance(mm)<=0)&& L==0)
        //while(!Controller1.ButtonL2.pressing() && !Controller1.ButtonL1.pressing())
        {
        
          intake.spin(reverse, 100, pct);
          task::sleep(10);
        }
        wait(0.25, sec);  
        L=1; 
              
        //printf("centerX %d\tcenterY %d\tdistance%lf\n",AIVision3.objects[0].centerX, AIVision3.objects[0].centerY, intakedistance.objectDistance(mm));
        //wait(0.25, sec);
        
        return 1;
        }