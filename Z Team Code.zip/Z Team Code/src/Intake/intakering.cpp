#include "vex.h"
using namespace vex;

int intakering() { 
  
    
    while((ring.objectDistance(mm)>25 || ring.objectDistance(mm)<=0)&& g==0)
        //while(!Controller1.ButtonL2.pressing() && !Controller1.ButtonL1.pressing())
        {
        
          intake.spin(reverse, 60, pct);
          task::sleep(10);
        }
        g=1;
         wait(0.3,sec);
         intake.stop(); 
         intake.spin(fwd, 25, pct); 
         wait(0.1, sec);
         intake.stop(); 
         
            
  
    return 0;
  }