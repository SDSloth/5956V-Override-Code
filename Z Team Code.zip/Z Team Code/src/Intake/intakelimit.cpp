#include "vex.h"
using namespace vex;

int intakelimit()
{     
    T2.clear();
    g=0;
   while(!limitSwitch.pressing() && T2.value()<4 && g==0)
        //while(!Controller1.ButtonL2.pressing() && !Controller1.ButtonL1.pressing())
        {
        
          intake.spin(reverse, 12, volt);
          hook.spin(fwd, 12, volt);
          task::sleep(10);
        }  
        // wait(100, msec);   
        intake.stop(); 
        hook.stop(); 
        //wait(350, msec); 
        T2.clear();
        while(limitSwitch.pressing() && T2.value()<4 && g==0)
        //while(!Controller1.ButtonL2.pressing() && !Controller1.ButtonL1.pressing())
        {
        
          intake.spin(reverse, 5, volt);
          hook.spin(fwd, 5, volt);
          task::sleep(10);
        } 
        intake.spin(fwd, 12, volt);
        hook.spin(reverse, 12, volt);
        wait(0.25, sec);
        intake.stop(); 
        hook.stop();
        g=1;
        return 1;

        }
                  
       