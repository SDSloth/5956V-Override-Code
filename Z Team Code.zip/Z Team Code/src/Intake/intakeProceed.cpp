#include "vex.h"
using namespace vex;

int intakeProceed()
{     
 while((ring.objectDistance(mm)>25 || ring.objectDistance(mm)<=0)&& g==0)
        //while(!Controller1.ButtonL2.pressing() && !Controller1.ButtonL1.pressing())
        {
        
          intake.spin(reverse, 100, pct);
          task::sleep(10);
        }
                  
        //printf("centerX %d\tcenterY %d\tdistance%lf\n",AIVision3.objects[0].centerX, AIVision3.objects[0].centerY, intakedistance.objectDistance(mm));
        //wait(0.25, sec);
        g=1; 
        return 1;
        }

      

