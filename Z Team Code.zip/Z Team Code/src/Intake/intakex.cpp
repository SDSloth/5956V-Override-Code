#include "vex.h"
using namespace vex;

int intakex()
{     
 while(1)
 {
    g=0;
    intake.spin(reverse, 100, pct);
    if (ring.objectDistance(mm)<50 && ring.objectDistance(mm)>0) 
    {
    T1.clear();
    while (ring.objectDistance(mm)<50 && ring.objectDistance(mm)>0) 
    {
        if(T1.value()>1 && ring.objectDistance(mm)<50 && ring.objectDistance(mm)>0)
        {
        g=1;    
        intake.spin(fwd, 100, pct);
        wait(0.15, sec); 
        T1.clear();
        }
    }

    } 
        
 task::sleep(10);
 }
            
        //printf("centerX %d\tcenterY %d\tdistance%lf\n",AIVision3.objects[0].centerX, AIVision3.objects[0].centerY, intakedistance.objectDistance(mm));
        //wait(0.25, sec);
        
        return 1;
}