#include "vex.h"
using namespace vex;

int antijam()
{    
    intake.spin(reverse, 100, pct);
    wait(0.15, sec); 
 while(1)
        
        {
        
            intake.spin(reverse, 100, pct);
          
            if(intake.velocity(rpm)<=10 && intake.velocity(rpm)>=0)
            {
             intake.spin(fwd, 100, pct);
             wait(0.15, sec); 
             intake.spin(reverse, 100, pct);
             wait(0.15, sec); 
             
             
            }
            task::sleep(10);
        }
                  

        return 1;
}

      

