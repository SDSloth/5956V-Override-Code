#include "vex.h"
using namespace vex;

int intakeLBcombo() { 
  intake.spin(reverse, 100, pct);
  wait(0.1, sec);
  L=0;
    while(L==0)
    {
      
  while((intakedistance.objectDistance(mm)>20 || intakedistance.objectDistance(mm)<=0) && L==0)
        //while(!Controller1.ButtonL2.pressing() && !Controller1.ButtonL1.pressing())
        {
          
          intake.spin(reverse, 100, pct);
          if(intake.velocity(rpm)<=10 && intake.velocity(rpm)>=0)
          {
            intake.spin(fwd, 100, pct);
            wait(0.25, sec); 
            intake.spin(reverse, 100, pct);
            wait(0.15, sec); 
           
          }
          task::sleep(10);
        }
        
        // L=1;
         intake.spin(reverse, 100, pct); 
         wait(0.3, sec); //.25
          
        
         //L=1;
         intake.spin(fwd, 80, pct); 
         wait(.15, sec);
         intake.stop(coast); 
         
         aspeed = 6;
         adesiredValue = 170;
         wait(0.1, sec);
         lbp2.open();
         L=1;
         intake.spin(reverse, 100, pct);
         wait(0.15, sec);
        L=0;
        while((intakedistance.objectDistance(mm)>50 || intakedistance.objectDistance(mm)<=0)&& L==0)
        //while(!Controller1.ButtonL2.pressing() && !Controller1.ButtonL1.pressing())
        {
        
          intake.spin(reverse, 80, pct);
          if(intake.velocity(rpm)<=10 && intake.velocity(rpm)>=0)
          {
            intake.spin(fwd, 100, pct);
            wait(0.25, sec); 
            intake.spin(reverse, 100, pct);
            wait(0.15, sec); 
           
          }
          task::sleep(10);
         
        }

         intake.stop(hold); 
         //intake.spin(fwd, 25, pct); 
         //wait(0.3, sec);
         intake.stop(); 
         //wait(5, sec);
         //adesiredValue = 600;
         //wait(2, sec);
         L=1;
         
      }
      return 0;
     
    }
          
   