#include "vex.h"
using namespace vex;
/*
int intakeDisk()
{   
    
    while(1)
    {


    if(Controller1.ButtonL1.pressing() && Optical1.hue() <= 180)
        {   
        intake.spin(reverse, 100, pct);
        }
    else if (Controller1.ButtonL1.pressing() && Optical1.hue() > 200)
        {
        while(!Optical2.isNearObject() && !Controller1.ButtonL2.pressing())
            {
            intake.spin(reverse, 100, pct);
            }
            intake.stop();
            wait(500, msec);
            //task::sleep(250);
            //intake.spin(reverse, 100, pct);
            //wait(1000, msec);
            //task::sleep(500);
        }
    else if(Controller1.ButtonL2.pressing())
        {
        intake.spin(fwd, 100, pct);
        } 
    
 //else if (states1 ==1)
    //{ 
     else if (Controller1.ButtonX.pressing()) //both joysticks can increase the flywheel speed by 5 rpm  
        {
        states1 = 0;    
        while(Optical1.hue() > 10 && !Controller1.ButtonL1.pressing() && !Controller1.ButtonL2.pressing() && states1 ==0)
            {
                intake.spin(reverse, 100, pct);

           if (Optical1.hue() >= 180) 
            {     
              while(!Optical2.isNearObject() && !Controller1.ButtonL1.pressing() && !Controller1.ButtonL2.pressing() && states1 ==0)
                {
                intake.spin(reverse, 100, pct);
                }
                intake.stop();
                wait(250, msec);
                intake.spin(fwd, 100, pct);
                wait(1000, msec);
                intake.stop();
                
                states1 = 1;
            }
            }
        while(!Optical2.isNearObject() && !Controller1.ButtonL1.pressing() && !Controller1.ButtonL2.pressing() && states1 == 0)
            {
                intake.spin(reverse, 100, pct);
            }
        intake.stop();
        T1.clear();
        while(T1.value()<0.3 && states1 ==0)
        {

        }
            //task::sleep(250);
        intake.spin(reverse, 100, pct);
        //wait(500, msec);
        T1.clear();
        while(T1.value()<1 && states1 ==0)
        {
            
        }
            //task::sleep(700);
            intake.setPosition(0, degrees);
        while(fabs(intake.position(deg)) < 10 && !Controller1.ButtonL1.pressing() && !Controller1.ButtonL2.pressing() && states1 == 0)
            {
            intake.spin(fwd, 100, pct);
            }
      
            intake.stop();
            //states = 0;
       // wait(2000, msec);
        }   

    else
        {
        intake.stop();
        }

    wait(10, msec);
    }
    return 0;
    
}
*/

int intakeDisk()
{     
while(1)
{

    if (Controller1.ButtonX.pressing()) 
    {   while(!Controller1.ButtonR2.pressing() && !Controller1.ButtonR1.pressing())
        {
        while((intakedistance.objectDistance(mm)>50 || intakedistance.objectDistance(mm)<=0) && !Controller1.ButtonR2.pressing() && !Controller1.ButtonR1.pressing())
        //while(!Controller1.ButtonL2.pressing() && !Controller1.ButtonL1.pressing())
        {   
          intake.spin(reverse, 100, pct);
        }
            if(intakedistance.objectDistance(mm)<50 && Optical2.hue() > 200)
                {
                  intake.stop();
                  wait(1000, msec);
                }
            
        while(Optical2.isNearObject() && !Controller1.ButtonR2.pressing() && !Controller1.ButtonR1.pressing())
        {
              intake.spin(reverse, 100, pct);
        }
            
        } 
    }
    

    else if(Controller1.ButtonR1.pressing())
        {   
        intake.spin(reverse, 100, pct);
        }
    
    else if(Controller1.ButtonR2.pressing())
        {
        intake.spin(fwd, 100, pct);
        } 

    else
        {
        intake.stop();
        }  
     task::sleep(10);
    }
    return 0;
}



