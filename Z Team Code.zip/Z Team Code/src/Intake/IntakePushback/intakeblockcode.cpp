#include "vex.h"
using namespace vex;

void intakeLongGoal() {
    Intake.spin(forward, 100, pct);
    Transition.spin(forward, 100, pct);
    Outtake.spin(forward, 100, pct);
}
void intakeMiddleGoal() {
    Intake.spin(forward, 100, pct);
    Transition.spin(forward, 100, pct);
    Outtake.spin(forward, -100, pct);
}
void intakeLowGoal() {
    Intake.spin(forward, -100, pct);
    Transition.spin(forward, -100, pct);
    Outtake.spin(forward, -100, pct);
}
void intakeStop() {
    Intake.spin(forward, 0, pct);
    Transition.spin(forward, 0, pct);
    Outtake.spin(forward, 0, pct);
}
