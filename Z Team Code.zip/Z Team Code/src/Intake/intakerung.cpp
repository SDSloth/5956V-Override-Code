#include "vex.h"
using namespace vex;

int intakeRung() { 
  L=0;
  intake.spin(reverse, 100, pct);
  wait(0.15, sec);
    while((intakedistance.objectDistance(mm)>20 || intakedistance.objectDistance(mm)<=0) && g==0)
        //while(!Controller1.ButtonL2.pressing() && !Controller1.ButtonL1.pressing())
        { 
          intake.spin(reverse, 100, pct);
          
          
            if(intake.velocity(rpm)<=10 && intake.velocity(rpm)>=0)
            {
             intake.spin(fwd, 100, pct);
             wait(0.25, sec); 
             intake.spin(reverse, 100, pct);
             wait(0.15, sec); 
             
             
            }
          
          task::sleep(10);
        }
    intake.setPosition(0, degrees); 
    while(fabs(intake.position(degrees))<=400)   
       { 
         intake.spin(reverse, 100, pct); 
         if(intake.velocity(rpm)<=10 && intake.velocity(rpm)>=0)
          {
           intake.spin(fwd, 100, pct);
           wait(0.25, sec); 
           intake.spin(reverse, 100, pct);
           wait(0.15, sec); 
           
           
          }
       }   
       intake.stop(); 
       L=1;
  
    return 0;
  }