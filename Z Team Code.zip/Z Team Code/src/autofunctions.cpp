#include "vex.h"
using namespace vex;

void scoreLongGoal(double time) {

    // starts the intake
    Intake.spin(forward, 100, pct);
    Outtake.spin(forward, 100, pct);
    wait(0.15,sec);

    // opens the hood and waits until the bot is done scoring
    Hood.open();
    wait(time,sec);

    // stops the intake and closes the hood
    Outtake.stop();
    Intake.stop();
    Hood.close();

}

void clearLoader(double time, double heading) {

    // gets bot ready to reach loader
    Tongue.open();
    Intake.spin(forward, 100, pct);
    breakHold();
    wait(0.2,sec);

    // moves to loader
    frontdistanceNew(7.9, heading, 6, 5, 1, 0, 1200);
    wait(time,sec);
    breakCoast();
    Intake.stop();


}