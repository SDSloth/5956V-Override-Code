#include "vex.h"
using namespace vex;

void driveStraightInertialSTNR(int desiredValue, float desiredTurnValue, int speed, float settle_error, float settle_time, float timeout) {
T1.clear();
settled = false;
time_spent_running = 0;
time_spent_settled = 0;

error = desiredValue - lBase2.position(degrees);
while (!settled) {
//while(true){
    // Get the position of both motors
    int leftMotorPosition = lBase2.position(degrees);
    //int rightMotorPosition = rBase2.position(degrees);

    error = desiredValue - leftMotorPosition; // forward with postitive encoder value
    // error = leftMotorPosition - desiredValue; //reverse with negative encoder value
    // Derivative
    derivative = error - prevError;
    // Integral
    if (fabs(error) > integralBound) {
      totalError += error; // totalError = totalError + error;
    } else {
      totalError = 0;
    }
    // This would cap the integral
    totalError = fabs(totalError) > maxIntegral? signnum_c(totalError) * maxIntegral: totalError;
   

    lateralMotorPower = error * kP + derivative * kD + totalError * kI;
    /////////////////////////////////////////////////////////////////////

    
      if (lateralMotorPower > speed) 
      {
        lateralMotorPower = speed;
      }
      else if (lateralMotorPower < - speed) 
      {
        lateralMotorPower = -speed;
      }

      float turnDifference1 = desiredTurnValue -Inertial20.heading();
      if (fabs(turnDifference1) >=180)
      {
       turnDifference1 = -fabs(turnDifference1)/turnDifference1 * (360 - fabs(turnDifference1));
      }

  
      lBase1.spin(forward, lateralMotorPower + turnDifference1 * kMI,
                 voltageUnits::volt);
      lBase2.spin(forward, lateralMotorPower + turnDifference1 * kMI,
                 voltageUnits::volt);
      lBase3.spin(forward, lateralMotorPower + turnDifference1 * kMI,
                 voltageUnits::volt);             
      rBase1.spin(forward, lateralMotorPower - turnDifference1 * kMI,
                  voltageUnits::volt);
      rBase2.spin(forward, lateralMotorPower - turnDifference1 * kMI,
                  voltageUnits::volt);
      rBase3.spin(forward, lateralMotorPower - turnDifference1 * kMI,
                  voltageUnits::volt);
     

                  
    prevError = error;

    if(fabs(error)<settle_error){
        time_spent_settled+=10;
   }
   else { 
        time_spent_settled = 0;
   }

   time_spent_running+=10;


  if (time_spent_running>timeout && timeout != 0){
    settled = true;
  }
  else if (time_spent_settled>settle_time){
    settled = true;
  }
  else 
  settled = false;

   printf("error %f\tturndifference %f\tInertial %f\ttimespentsettled %f\ttimerunning %f\n",error, turnDifference1, Inertial20.heading(), time_spent_settled, time_spent_running);
   wait(10, msec);

  }
  
    lBase1.spin(fwd, 0, pct);
    lBase2.spin(fwd, 0, pct);
    lBase3.spin(fwd, 0, pct);
    rBase1.spin(fwd, 0, pct);
    rBase2.spin(fwd, 0, pct);
    rBase3.spin(fwd, 0, pct);
   
}