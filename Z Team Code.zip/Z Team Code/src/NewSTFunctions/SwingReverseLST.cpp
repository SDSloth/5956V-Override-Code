#include "vex.h"
using namespace vex;

void SwingReverseLST(int desiredTurnValue, int turnspeed, float settle_error, float settle_time, float timeout) //negative
    {
    settled = false;
    time_spent_running = 0;
    time_spent_settled = 0;
    lBase2.setPosition(0, degrees);
    rBase2.setPosition(0, degrees);
    int turnDifference = lBase2.position(degrees) - rBase2.position(degrees);
    turnError = desiredTurnValue - turnDifference;

    while (!settled) {

    // Get the position of both motors
    int leftMotorPosition = lBase2.position(degrees);
    int rightMotorPosition = rBase2.position(degrees);

    turnDifference = leftMotorPosition - rightMotorPosition;
    // Potential
    // turnError = turnDifference - desiredTurnValue;
    turnError = desiredTurnValue - turnDifference;
    // Derivative
    turnDerivative = turnError - turnPrevError;

    // Integral
    if (fabs(error) < integralBound) {
      turnTotalError += turnError;
    } else {
      turnTotalError = 0;
    }
    // turnTotalError = turnTotalError + turnError;

    // This would cap the integral
    turnTotalError = fabs(turnTotalError) > maxIntegral? signnum_c(turnTotalError) * maxIntegral: turnTotalError;

    turnMotorPower = turnError * turnkP + turnDerivative * turnkD + turnTotalError * turnkI;

      if (turnMotorPower > turnspeed) {
        turnMotorPower = turnspeed;
      }

      else if (turnMotorPower < -turnspeed) {
        turnMotorPower = -turnspeed;
      }
   

      lBase1.spin(forward, turnMotorPower, voltageUnits::volt);
      lBase2.spin(forward, turnMotorPower, voltageUnits::volt);
      lBase3.spin(forward, turnMotorPower, voltageUnits::volt);
      rBase1.spin(forward, 0, voltageUnits::volt);
      rBase2.spin(forward, 0, voltageUnits::volt);
      rBase3.spin(forward, 0, voltageUnits::volt);
    
    
    turnPrevError = turnError;

  if(fabs(error)<settle_error){
        time_spent_settled+=10;
   }
   else { 
        time_spent_settled = 0;
   }

   time_spent_running+=10;


  if (time_spent_running>timeout && timeout != 0){
    settled = true;
  }
  if (time_spent_settled>settle_time){
    settled = true;
  }

  settled = false;

     printf("LE %d\tRE %d\tturnerror %f\n",leftMotorPosition, rightMotorPosition, turnError);

    
    
    wait (10, msec);

  }
   lBase2.setPosition(0, degrees);
   rBase2.setPosition(0, degrees);
   lBase1.spin(fwd, 0, pct);
   lBase2.spin(fwd, 0, pct);
   lBase3.spin(fwd, 0, pct);
   rBase1.spin(fwd, 0, pct);
   rBase2.spin(fwd, 0, pct);
   rBase3.spin(fwd, 0, pct);

}