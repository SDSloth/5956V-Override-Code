#include "vex.h"
using namespace vex;

void driveStraightInertialNOPID(int desiredValue, float desiredTurnValue, int speed, float timeout) { //negative speed to reverse
T1.clear();
settled = false;
time_spent_running = 0;
//lBase2.setPosition(0, degrees);

while (fabs(lBase2.position(degrees))<desiredValue && !settled) {

      float turnDifference1 = desiredTurnValue -Inertial20.heading();
      if (fabs(turnDifference1) >=180)
      {
       turnDifference1 = -fabs(turnDifference1)/turnDifference1 * (360 - fabs(turnDifference1));
      }

  
      lBase1.spin(forward, speed + turnDifference1 * kMI,
                 voltageUnits::volt);
      lBase2.spin(forward, speed + turnDifference1 * kMI,
                 voltageUnits::volt);
      lBase3.spin(forward, speed + turnDifference1 * kMI,
                 voltageUnits::volt);             
      rBase1.spin(forward, speed - turnDifference1 * kMI,
                  voltageUnits::volt);
      rBase2.spin(forward, speed - turnDifference1 * kMI,
                  voltageUnits::volt);
      rBase3.spin(forward, speed - turnDifference1 * kMI,
                  voltageUnits::volt);
     


   time_spent_running+=10;


  if (time_spent_running>timeout && timeout != 0){
    settled = true;
  }
  else 
  settled = false;

   printf("LE %f\tturndifference %f\tInertial %f\ttimerunning %f\n",lBase2.position(degrees), turnDifference1, Inertial20.heading(), time_spent_running);
   wait(10, msec);

  }
  
    lBase1.spin(fwd, 0, pct);
    lBase2.spin(fwd, 0, pct);
    lBase3.spin(fwd, 0, pct);
    rBase1.spin(fwd, 0, pct);
    rBase2.spin(fwd, 0, pct);
    rBase3.spin(fwd, 0, pct);
   
}