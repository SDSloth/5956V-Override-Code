#include "vex.h"
using namespace vex;

//Added float timeout just for skills so that we can change when the inertial turn times out
//we use a , then the value for every inertial turn to set this timeout


void inertialSwingST(float desiredTurnValue, float turnspeed, float settle_error, float settle_time, float timeout, float R, float L) {
//T1.clear();
//T2.clear();
//timeout = T1.value();
//settle_time = T2.value();

settled = false;
time_spent_running = 0;
time_spent_settled = 0;

turnError = desiredTurnValue - Inertial20.heading();
if (fabs(turnError) >=180)
  {
    turnError = -fabs(turnError)/turnError * (360 - fabs(turnError));
  }

 while (settled == false) {
  //while (h==1) {

    if (desiredTurnValue <0)
    {
      desiredTurnValue += 360;
    }

    turnError = desiredTurnValue - Inertial20.heading(); //turn 

    if (fabs(turnError) >=180)
    {
      turnError = -fabs(turnError)/turnError * (360 - fabs(turnError));
    }

    // Derivative
    turnDerivative = turnError - turnPrevError;

    // Integral
    if (fabs(turnError) < integralBound) {
      turnTotalError += turnError;
    } else {
      turnTotalError = 0;
    }
    // turnTotalError = turnTotalError + turnError;

    // This would cap the integral
    turnTotalError = fabs(turnTotalError) > maxIntegral? signnum_c(turnTotalError) * maxIntegral: turnTotalError;

    turnMotorPower = turnError * iturnkPf + turnDerivative * iturnkDf + turnTotalError * iturnkIf;

    if (turnMotorPower > turnspeed) {
        turnMotorPower = turnspeed;
      }
      else if (turnMotorPower < -turnspeed){
        turnMotorPower = -turnspeed;
      }

    
      lBase1.spin(forward, R * turnMotorPower, voltageUnits::volt);
      lBase2.spin(forward, R * turnMotorPower, voltageUnits::volt);
      lBase3.spin(forward, R * turnMotorPower, voltageUnits::volt);
      rBase1.spin(forward, L * turnMotorPower, voltageUnits::volt);
      rBase2.spin(forward, L * turnMotorPower, voltageUnits::volt);
      rBase3.spin(forward, L * turnMotorPower, voltageUnits::volt);
    

    turnPrevError = turnError;

  if(fabs(turnError)<settle_error){
        time_spent_settled+=10;
   }
   else { 
        time_spent_settled = 0;
   }

   time_spent_running+=10;


  if (time_spent_running>timeout && timeout != 0){
    settled = true;
  }
   else if (time_spent_settled>settle_time){
    settled = true;
  }
else
  settled = false;


    printf("inertial %f\tturnerror%f turnpower %f\timespentsettled %f\ttimerunning %f\n",Inertial20.heading(), turnError, turnMotorPower, time_spent_settled, time_spent_running);
    wait(10, msec);

  }
  

   //lBase2.setPosition(0, degrees);
   //rBase2.setPosition(0, degrees);
   lBase1.spin(fwd, 0, pct);
   lBase2.spin(fwd, 0, pct);
   lBase3.spin(fwd, 0, pct);
   rBase1.spin(fwd, 0, pct);
   rBase2.spin(fwd, 0, pct);
   rBase3.spin(fwd, 0, pct);
   //wait(20, msec);

   //printf("$$$$$$$$$inertial %0.2f\tdesiredValue %0.2f\tturnerror %0.2f\tturnpower %f\tGPSInertial %0.2f\n",Inertial20.heading(), desiredTurnValue, turnError, turnMotorPower, GPSInertial);

}
