#include "vex.h"
using namespace vex;

void PIDReverseInertial(int desiredValue, int desiredTurnValue, int speed, float timeout) {  //use negative desiredValue
T1.clear();
lBase2.setPosition(0, degrees);
rBase2.setPosition(0, degrees);
error = desiredValue - lBase2.position(degrees);
while (error < 0  && T1.value()<timeout) {
//while(true){
    // Get the position of both motors
    int leftMotorPosition = lBase2.position(degrees);
    //int rightMotorPosition = rBase2.position(degrees);

    error = desiredValue - leftMotorPosition; // forward with postitive encoder value
    // error = leftMotorPosition - desiredValue; //reverse with negative encoder value
    // Derivative
    derivative = error - prevError;
    // Integral
    if (fabs(error) > integralBound) {
      totalError += error; // totalError = totalError + error;
    } else {
      totalError = 0;
    }
    // This would cap the integral
    totalError = fabs(totalError) > maxIntegral? signnum_c(totalError) * maxIntegral: totalError;
   

    lateralMotorPower = error * kP + derivative * kD + totalError * kI;
    /////////////////////////////////////////////////////////////////////

    
      if (lateralMotorPower > speed) 
      {
        lateralMotorPower = speed;
      }
      else if (lateralMotorPower < - speed) 
      {
        lateralMotorPower = -speed;
      }

  
  float turnDifference1 = Inertial20.heading() - desiredTurnValue;
      if (fabs(turnDifference1) >=180)
  {
    turnDifference1 = -fabs(turnDifference1)/turnDifference1 * (360 - fabs(turnDifference1));
  }

  
      lBase1.spin(forward, lateralMotorPower - turnDifference1 * kMI,
                 voltageUnits::volt);
      lBase2.spin(forward, lateralMotorPower - turnDifference1 * kMI,
                 voltageUnits::volt);
      lBase3.spin(forward, lateralMotorPower - turnDifference1 * kMI,
                 voltageUnits::volt);           
      rBase1.spin(forward, lateralMotorPower + turnDifference1 * kMI,
                  voltageUnits::volt);
      rBase2.spin(forward, lateralMotorPower + turnDifference1 * kMI,
                  voltageUnits::volt);
      rBase3.spin(forward, lateralMotorPower + turnDifference1 * kMI,
                  voltageUnits::volt); 
    
    prevError = error;

   printf("LE %f\tRE %f\terror %f\tturndifference %f\tturnerror %f\tInertial %f\n",lBase2.position(degrees), rBase2.position(degrees), error, turnDifference1, turnError, Inertial20.heading());
   wait(10, msec);

  }
  //printf("LE %f\tRE %f\terror %f\tturnerror %f\tfrontdistance %f\t, backdistance %f\n",lBase2.position(degrees), rBase2.position(degrees), error, turnError, Frontdistance.objectDistance(mm), Backdistance.objectDistance(mm));
   //lBase2.setPosition(0, degrees);
   //rBase2.setPosition(0, degrees);
   lBase1.spin(fwd, 0, pct);
   lBase2.spin(fwd, 0, pct);
   lBase3.spin(fwd, 0, pct);
   rBase1.spin(fwd, 0, pct);
   rBase2.spin(fwd, 0, pct);
   rBase3.spin(fwd, 0, pct);
}
