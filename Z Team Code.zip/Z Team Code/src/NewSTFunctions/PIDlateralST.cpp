#include "vex.h"
using namespace vex;

void PIDlateralST(int desiredValue, int speed, float settle_error, float settle_time, float timeout) {
settled = false;
time_spent_running = 0;
time_spent_settled = 0;
lBase2.setPosition(0, degrees);
rBase2.setPosition(0, degrees);

error = desiredValue - lBase2.position(degrees);
while (!settled) {
//while(true){
    // Get the position of both motors
    int leftMotorPosition = lBase2.position(degrees);
    int rightMotorPosition = rBase2.position(degrees);

    error = desiredValue - leftMotorPosition; // forward with postitive encoder value
    // error = leftMotorPosition - desiredValue; //reverse with negative encoder value
    // Derivative
    derivative = error - prevError;
    // Integral
    if (fabs(error) > integralBound) {
      totalError += error; // totalError = totalError + error;
    } else {
      totalError = 0;
    }
    // This would cap the integral
    totalError = fabs(totalError) > maxIntegral? signnum_c(totalError) * maxIntegral: totalError;
   

    lateralMotorPower = error * kP + derivative * kD + totalError * kI;
    /////////////////////////////////////////////////////////////////////

    
      if (lateralMotorPower > speed) 
      {
        lateralMotorPower = speed;
      }
      else if (lateralMotorPower < - speed) 
      {
        lateralMotorPower = -speed;
      }

      int turnDifference1 = leftMotorPosition - rightMotorPosition;

  
      lBase1.spin(forward, lateralMotorPower - turnDifference1 * kM,
                 voltageUnits::volt);
      lBase2.spin(forward, lateralMotorPower - turnDifference1 * kM,
                 voltageUnits::volt);
      lBase3.spin(forward, lateralMotorPower - turnDifference1 * kM,
                 voltageUnits::volt);           
      rBase1.spin(forward, lateralMotorPower + turnDifference1 * kM,
                  voltageUnits::volt);
      rBase2.spin(forward, lateralMotorPower + turnDifference1 * kM,
                  voltageUnits::volt);
      rBase3.spin(forward, lateralMotorPower + turnDifference1 * kM,
                  voltageUnits::volt); 
    
    prevError = error;

   if(fabs(error)<settle_error){
        time_spent_settled+=10;
   }
   else { 
        time_spent_settled = 0;
   }

   time_spent_running+=10;


  if (time_spent_running>timeout && timeout != 0){
    settled = true;
  }
  else if (time_spent_settled>settle_time){
    settled = true;
  }
else
  settled = false;


   printf("LE %f\tRE %f\terror %f\tturndifference %d\n",lBase2.position(degrees), rBase2.position(degrees), error, turnDifference1);
   wait(10, msec);

  }
  //printf("LE %f\tRE %f\terror %f\tturndifference %d\n",lBase2.position(degrees), rBase2.position(degrees), error, turnDifference1);
   //lBase2.setPosition(0, degrees);
   //rBase2.setPosition(0, degrees);
   lBase1.spin(fwd, 0, pct);
   lBase2.spin(fwd, 0, pct);
   lBase3.spin(fwd, 0, pct);
   rBase1.spin(fwd, 0, pct);
   rBase2.spin(fwd, 0, pct);
   rBase3.spin(fwd, 0, pct);
}
