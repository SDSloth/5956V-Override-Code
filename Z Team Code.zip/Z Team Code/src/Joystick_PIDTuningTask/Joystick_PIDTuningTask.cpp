#include "vex.h"
#include "JAR-Template/drive.h"
#include "autons.h"
using namespace vex;


int choosePIDfunction = 0;

int Joystick_PIDTuningTask() 
{
//odom_constants();
while(1)
  {

  if (Controller1.ButtonUp.pressing()) //both joysticks can increase the flywheel speed by 5 rpm  
    {
      if(!toggle)
      {  
      toggle = true;                 
      choosePIDfunction += 1;  // increment shorthand targetBANG = targetBANG +5
      Controller1.Screen.setCursor(1, 1); //displays on the 1st row, 1st column of the joystick
      //Controller1.Screen.print("targetspeed=%f",settargetspeed); 
      Controller2.Screen.setCursor(1, 1);
      //Controller2.Screen.print("targetspeed=%f",settargetspeed); 
      Controller1.Screen.setCursor(2, 1); //displays on the 2nd row, 1st column of the joystick
      //Controller1.Screen.print("kicks=%d",p); 
      Controller2.Screen.setCursor(2, 1);
      //Controller2.Screen.print("kicks=%d",p); 
      }

    } 
  else if (Controller1.ButtonDown.pressing()) 
    {
      if(!toggle)
      {   
      toggle = true;
      choosePIDfunction -= 1;  
      }
    }
  else 
    {
    toggle = false;
    }


    switch (choosePIDfunction)
    {
        case 0:
        Controller1.Screen.setCursor(1, 1); //displays on the 1st row, 1st column of the joystick
        Controller1.Screen.print("DriveStraightInertialST"); 
        Controller1.Screen.setCursor(2, 1);
        Controller1.Screen.print("P%.3f,D%.3f,I%.3f",kP, kD, kI);
        Controller1.Screen.setCursor(3, 1); //displays on the 1st row, 1st column of the joystick
        Controller1.Screen.print("increment = %.2f", increment);
        if (Controller1.ButtonX.pressing()) 
        {
         constant = kP;
         constantchooser();
         kP = constant;
        
        }
        else if (Controller1.ButtonA.pressing())
        {
         constant = kD;
         constantchooser();
         kD = constant;
        }
        else if (Controller1.ButtonB.pressing())
        {
         constant = kI;
         constantchooser();
         kI = constant;
        }
        else if (Controller1.ButtonRight.pressing())
        {
          Controller1.Screen.clearScreen();  
          Controller1.Screen.setCursor(1, 1); //displays on the 1st row, 1st column of the joystick
          Controller1.Screen.print("DriveStraightInertialST"); 
          driveStraightInertialST(500, 0, 12, 0, 5, 100, 5000);
        }
        else if (Controller1.ButtonR1.pressing())
        {
          increment = 0.1;
        }
        else if (Controller1.ButtonR2.pressing())
        {
          increment = 0.01;
        }
        break;

        case 1:
        Controller1.Screen.setCursor(1, 1); //displays on the 1st row, 1st column of the joystick
        Controller1.Screen.print("InertialPIDfuntionST"); 
        Controller1.Screen.setCursor(2, 1);
        Controller1.Screen.print("P%.3f,D%.3f,I%.3f",iturnkP, iturnkD, iturnkI);
        Controller1.Screen.setCursor(3, 1); //displays on the 1st row, 1st column of the joystick
        Controller1.Screen.print("increment = %.2f", increment);
        if (Controller1.ButtonX.pressing()) 
        {
         constant = iturnkP;
         constantchooser();
         iturnkP = constant;
        }
        else if (Controller1.ButtonA.pressing())
        {
         constant = iturnkD;
         constantchooser();
         iturnkD = constant;
        }
        else if (Controller1.ButtonB.pressing())
        {
         constant = iturnkI;
         constantchooser();
         iturnkI = constant;
        }
        else if (Controller1.ButtonRight.pressing())
        {
          Controller1.Screen.clearScreen();  
          Controller1.Screen.setCursor(1, 1); //displays on the 1st row, 1st column of the joystick
          Controller1.Screen.print("InertialPIDfuntionST");   
          inertialPIDfuntionST(90, 12, 0, 5, 100, 5000);
        }
        else if (Controller1.ButtonR1.pressing())
        {
          increment = 0.1;
        }
        else if (Controller1.ButtonR2.pressing())
        {
          increment = 0.01;
        }
        break;


        case 3:
        Controller1.Screen.setCursor(1, 1); //displays on the 1st row, 1st column of the joystick
        Controller1.Screen.print("distanceFrontInertialST"); 
        Controller1.Screen.setCursor(2, 1);
        Controller1.Screen.print("P%.3f,D%.3f,I%.3f",dkP, dkD, dkI);
        Controller1.Screen.setCursor(3, 1); //displays on the 1st row, 1st column of the joystick
        Controller1.Screen.print("increment = %.2f", increment);
        if (Controller1.ButtonX.pressing()) 
        {
         constant = dkP;
         constantchooser();
         dkP = constant;
        }
        else if (Controller1.ButtonA.pressing())
        {
         constant = dkD;
         constantchooser();
         dkD = constant;
        }
        else if (Controller1.ButtonB.pressing())
        {
         constant = dkI;
         constantchooser();
         dkI = constant;
        }
        else if (Controller1.ButtonRight.pressing())
        {
          Controller1.Screen.clearScreen();  
          Controller1.Screen.setCursor(1, 1); //displays on the 1st row, 1st column of the joystick
          Controller1.Screen.print("distanceFrontInertialST");   
          distanceFrontInertialST(20, 90, 12, 5, 100, 5000);
        }
        else if (Controller1.ButtonR1.pressing())
        {
          increment = 0.1;
        }
        else if (Controller1.ButtonR2.pressing())
        {
          increment = 0.01;
        }
        break;


        case 4:
        Controller1.Screen.setCursor(1, 1); //displays on the 1st row, 1st column of the joystick
        Controller1.Screen.print("drive to point"); 
        Controller1.Screen.setCursor(2, 1);
        Controller1.Screen.print("P%.3f,D%.3f,I%.3f",drive_kp, drive_kd, drive_ki);
        Controller1.Screen.setCursor(3, 1); //displays on the 1st row, 1st column of the joystick
        Controller1.Screen.print("increment = %.2f", increment);
        if (Controller1.ButtonX.pressing()) 
        {
         constant = drive_kp;
         constantchooser();
         drive_kp = constant;
        }
        else if (Controller1.ButtonA.pressing())
        {
         constant = drive_kd;
         constantchooser();
         drive_kd = constant;
        }
        else if (Controller1.ButtonB.pressing())
        {
         constant = drive_ki;
         constantchooser();
         drive_ki = constant;
        }
        else if (Controller1.ButtonRight.pressing())
        {
          Controller1.Screen.clearScreen();  
          Controller1.Screen.setCursor(1, 1); //displays on the 1st row, 1st column of the joystick
          Controller1.Screen.print("drive to point");  
          chassis.drive_to_point(0, 24);
        }
        else if (Controller1.ButtonR1.pressing())
        {
          increment = 0.1;
        }
        else if (Controller1.ButtonR2.pressing())
        {
          increment = 0.01;
        }
        break;

    }

  }
  return 0;
}