#include "vex.h"
using namespace vex;


void constantchooser() 

{
    Controller1.Screen.clearScreen();
    while (!Controller1.ButtonY.pressing())
    {
        Controller1.Screen.setCursor(1, 1);
        Controller1.Screen.print("constant=%.3f",constant);
        Controller1.Screen.setCursor(2, 1); //displays on the 1st row, 1st column of the joystick
        Controller1.Screen.print("increment = %.3f", increment);

     if (Controller1.ButtonUp.pressing()) //both joysticks can increase the flywheel speed by 5 rpm  
            {
                if(!toggle)
                {  
                toggle = true;                 
                constant += increment;  // increment shorthand targetBANG = targetBANG +5
                }
            } 
        else if (Controller1.ButtonDown.pressing()) 
            {
                if(!toggle)
                {   
                toggle = true;
                constant -= increment;  
                }
            }
        else 
            {
                toggle = false;
            }


       if (Controller1.ButtonR1.pressing())
        {
          increment = 0.1;
        }
        else if (Controller1.ButtonR2.pressing())
        {
          increment = 0.01;
        }

        if (Controller1.ButtonR1.pressing())
        {
          increment = 0.1;
        }
        else if (Controller1.ButtonL1.pressing())
        {
          constant = 0;
        }
    }
   // kP = constant;

}


