#include "vex.h"
using namespace vex;

int autoclamp() { 
  
    while ((Goaldistance.objectDistance(inches)>1.5 || Goaldistance.objectDistance(inches)<=0) && !Controller1.ButtonL2.pressing() )
    {
       task::sleep(10);
    }
    wait(.15, sec); //0.25
    BackClamp();
    task::sleep(100);
    return 0;
  }
  


