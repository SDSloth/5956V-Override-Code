#include "vex.h"



void default_constants(){
  // Each constant set is in the form of (maxVoltage, kP, kI, kD, startI).
  chassis.set_drive_constants(10, 1, 0, 10, 0);
  chassis.set_heading_constants(10, .4, 0, 2, 0); //8, .4, 0, 3, 0
  chassis.set_turn_constants(10, .4, .03, 3, 15);
  chassis.set_swing_constants(11, .3, .001, 2, 15);

  // Each exit condition set is in the form of (settle_error, settle_time, timeout).
  chassis.set_drive_exit_conditions(1, 100, 2000);
  chassis.set_turn_exit_conditions(0.5, 100, 2000);
  chassis.set_swing_exit_conditions(2, 0, 2000);
}

void odom_constants(){
  default_constants();
  chassis.drive_max_voltage = 8;
  chassis.drive_settle_error = 2;
}

void drive_test(){
  chassis.drive_distance(6);
  chassis.drive_distance(12);
  chassis.drive_distance(18);
  chassis.drive_distance(-36);
}

void turn_test(){
  chassis.turn_to_angle(5);
  chassis.turn_to_angle(30);
  chassis.turn_to_angle(90);
  chassis.turn_to_angle(225);
  chassis.turn_to_angle(0);
}

void swing_test(){
  chassis.left_swing_to_angle(90);
  chassis.right_swing_to_angle(0);
}

void full_test(){
  chassis.drive_distance(24);
  chassis.turn_to_angle(-45);
  chassis.drive_distance(-36);
  chassis.right_swing_to_angle(-90);
  chassis.drive_distance(24);
  chassis.turn_to_angle(0);
}

void odom_test(){
  chassis.set_coordinates(0, 0, 0);
  while(1){
    Brain.Screen.clearScreen();
    Brain.Screen.printAt(0,50, "X: %f", chassis.get_X_position());
    Brain.Screen.printAt(0,70, "Y: %f", chassis.get_Y_position());
    Brain.Screen.printAt(0,90, "Heading: %f", chassis.get_absolute_heading());
    Brain.Screen.printAt(0,110, "ForwardTracker: %f", chassis.get_ForwardTracker_position());
    Brain.Screen.printAt(0,130, "SidewaysTracker: %f", chassis.get_SidewaysTracker_position());
    task::sleep(20);
  }
}

void Setup()
{
  GPS8.calibrate();
  // waits for Inertial Sensor to calibrate 
  while (Inertial20.isCalibrating()) {
    wait(100, msec);
  }
  Inertial20.setHeading(0, deg);
  //chassis.set_coordinates(0, 0,0);
  wait(1000, msec);

  task t716221(autoPath); 

while(1)
{

  if (Controller1.ButtonUp.pressing())
  {
    chassis.turn_max_voltage = 5;
    chassis.turn_settle_time = 500000;
    chassis.turn_timeout = 500000;
    chassis.turn_to_angle(65);  ///skills (55)RedPos, Right 60, Back 10.5, front 16.2
    //chassis.turn_to_angle(141.5);  ///RedNeg, Left 58, Back 10.5, Front 11
  } //AWPRed 213
  //RedNegative 145
 

  float throttle = deadband(controller(primary).Axis3.value(), 5);
  float turn = deadband(controller(primary).Axis1.value(), 5);

  lBase1.spin(fwd, to_volt(throttle+turn)*.2, volt);
  lBase2.spin(fwd, to_volt(throttle+turn)*.2, volt);
  lBase3.spin(fwd, to_volt(throttle+turn)*.2, volt);
  rBase1.spin(fwd, to_volt(throttle-turn)*.2, volt);
  rBase2.spin(fwd, to_volt(throttle-turn)*.2, volt);
  rBase3.spin(fwd, to_volt(throttle-turn)*.2, volt);
  }

}





void BigRed()

{
  Inertial20.setHeading(0, deg); // 160 inertial, 1500 back distance
  chassis.set_coordinates(0, 0, 0); 
  //printf("hello\n");
  //chassis.turn_to_angle(90); 
  chassis.drive_distance(24); 
  wait(3000000, sec);

  greengoalb=true;
  bluering = false;
  redring = true;
  redringi = true;
  blueringc=true;
  redringc=false;
  greenb = true;

  g=0;
  intake.setPosition(0, degrees);
  ringliftL.setPosition(0, degrees);
  backClaw.open();
  lbp2.close();
  T2.clear();

  earlyexit = false;

  lineexit = false;
  AWBB();
  AWB();
  AWBI();

 
  doinkL.open(); 
  BackstraightVisionST(-600, 160, 11, 6, 5, 0, 2000);   //get goal
  chassis.drive_max_voltage=11;
  chassis.drive_distance(-8);
  
  backClaw.close();
  wait(300, msec);
  task t61010(colorsortAuto);                         //colorsort on 
  doinkL.close(); 
  
  chassis.turn_max_voltage=6;
  chassis.turn_to_angle(0);         //slower turn to make sure ring doesn't fly out
  chassis.turn_max_voltage=10;
  
  breakdistance = 350;
  breakout = true;
  FrontstraightVisionST(750, 165, 10, 8, 5, 0, 3000); //$$$$$$$1string
  breakout = false;
  ee = 2;
  earlyexit = true;
  FrontstraightVisionST(950, 165, 8, 6, 5, 0, 3000); 
  //FrontdistanceVisionST(1, 165, 10, 0, 1, 0, 3000);   //$$$$$$$$1st ring
  //allMtrsStop();
  //doinkR.open();                                       //right doinker down
  earlyexit = false;                                    
  //waitforring = true;                                 //wait for ring to come in
  //chassis.drive_distance(4);                          //a bit further
  //waitforring = false;
  chassis.turn_to_angle(280);                         //turn left
  //task::stop(colorsortAuto);                          //turn off intake and colorsort
  //intake.stop();
  backdistanceNew(24, 280, 10, 8, 1, 0, 2000);        //back up to wall
  task::stop(colorsortAuto); 
  intake.spin(fwd, 100, pct);                         //reverse intake
  chassis.turn_to_angle(40);                          //turn to face corner ring stack
  doinkR.close();                                     //right doinker up
  scanF(300, 5);
  
  task t610910(colorsortAuto);                        //start colorsort
  earlyexit = true;                                   
  chassis.drive_timeout = 1200;
  ee = 4;                                             //this changes distance for early exit                     
  FrontstraightVisionST(1400, 165, 7, 5, 5, 0, 3000); //go towards red rings in stack
  waitforring = true;                                 //wait for the ring to come in while moving backwards
  chassis.drive_max_voltage = 7;
  chassis.drive_distance(-14);
  waitforring = false;

  ee = 2;
  FrontstraightVisionST(1400, 165, 7, 5, 5, 0, 2000); 
  waitforring = true;
  
  chassis.drive_distance(-14);
  waitforring = false;
  
  FrontstraightVisionST(1400, 165, 7, 5, 5, 0, 2000); 
  waitforring = true;
  
  chassis.drive_distance(-14);
  waitforring = false;

  FrontstraightVisionST(1400, 165, 7, 5, 5, 0, 2000); 
  waitforring = true;
  
  chassis.drive_distance(-14);
  waitforring = false;

  earlyexit = false;                                   // turn off early exit
  
  chassis.turn_to_angle(358);                          //turn to angle slightly left of 0

  frontdistanceNew(30, 358, 10, 8, 1, 0, 2000); 

  doinkL.open();                                        //left doinker down to turn left
  lbp.open();                                           //intake piston up

  chassis.turn_to_angle(181);                           //turn left and clear any rings in front of you
  doinkL.close();                                       //left doinker up

  multipleobjectsL = true;
  ee = 3.5;
  earlyexit = true;
  FrontstraightVisionST(1400, 165, 10, 0, 5, 0, 3000); 
  //FrontdistanceVisionST(4, 165, 10, 0, 1, 0, 2000);      //$$4th ring on stack
  multipleobjectsL = false;
  chassis.turn_to_angle(195);                            //turn to go back to wall

  backdistanceNew(14, 195, 12, 0, 1, 0, 2000);           // back to wall

  task::stop(autoclamp);

  backClaw.open();                                       //drop goal


wait(3000000, sec);


  
  chassis.turn_to_angle(0);
  frontdistanceNew(18, 0, 8, 0, 0.5, 100, 2000); 

  //task::stop(intakeringLB); 
  //intake.spin(reverse, 100, pct);

  chassis.turn_max_voltage = 10;
  task::stop(autoclamp);
  backClaw.open();
  chassis.drive_timeout = 2000;
  chassis.turn_settle_time = 100;
  chassis.turn_to_angle(316);
  chassis.drive_max_voltage = 4;
  chassis.drive_distance(16);
  
  
  
  
  wait(30000000, sec);
  Inertial20.setHeading(214, deg); // 160 inertial, 1500 back distance
  chassis.set_coordinates(0, 0, 214);  //214
  
  greengoalb=true;
  redring = true;
  redringi = true;
  blueringc=true;
  redringc=false;
  greenb = true;
/*
  greengoalb=true;
  bluering = true;
  blueringi = true;
  redringc=true;
  blueringc=false; 
  greenb = true;
  */
  g=0;
  intake.setPosition(0, degrees);
  T2.clear();
  
  earlyexit = false;
  
  lineexit = false;
  AWBB();
  AWB();
  

  /*
  breakout=false;
  breakdistance = 10;
  chassis.turn_to_angle(60); 
  scanF(300, 8);
  //FrontturnVisionST(165, 10, 10, 10, 0, 1000);
  breakout=true;
  lBase2.setPosition(0, degrees); 
  breakdistance = 100;
  FrontstraightVisionST(1400, 165, 12, 0, 5, 0, 2000); //1400 is 24inches
  chassis.drive_distance(10);
  lBase2.setPosition(0, degrees); 
  wait(3000000000,sec);
  chassis.drive_max_voltage = 12;
  chassis.drive_min_voltage = 0;
  chassis.heading_max_voltage = 12;
  //chassis.drive_settle_error = 8;
  breakout=true;
  breakdistance = 10;
  chassis.drive_distance(34);
  
    breakout=true; 
    breakdistance = 500; 
  FrontstraightVisionST(4000, 165, 12, 0, 5, 0, 2000); //1400 is 24inches
  chassis.drive_min_voltage = 0;
  chassis.drive_settle_error = 2;
  breakout=false; 
  
  chassis.drive_distance(10);
  wait(300000000000, sec);
  
  */
  
  while(rotationARM.position(degrees)<=150)             // 3rd ring on stake
        {
          ringliftL.spin(fwd, 100, pct);
          ringliftR.spin(fwd, 100, pct);
          printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
        }
        ringliftL.stop(hold);
        ringliftR.stop(hold); 
  wait(300, msec);
  aspeed = 12;
  adesiredValue = 0;
  task t64161474(armPID);
  
  v=0;
  
  task t71621(autoclamp); 
  
  //scanB(300, 6);
  //BackturnVisionST(160, 12, 10, 15, 0, 1000); // lock in to get goal
  breakout=true;
  breakdistance = -100;
  BackstraightVisionST(-1500, 160, 10, 0, 10, 0, 2000); 
  breakout=false;
  chassis.drive_max_voltage = 4;
  chassis.drive_min_voltage = 0;
  chassis.drive_distance(-12); ///get goal slower
  
  backClaw.open(); // close back claw
  
  chassis.drive_max_voltage = 12; 
  //chassis.drive_distance(8); // drive foward to 1st red ring stack 4.1
  scanF(300, 6);  //scan right for red ring
  breakout=true;
  breakdistance = 100;
  FrontstraightVisionST(800, 250, 10, 0, 5, 0, 2000);
  //FrontturnVisionST(250, 12, 10, 25, 0, 2000); // lock in doinkerR for red ring
  dRexit=true;
  breakout=false;          // put doinder down when within 4 inch error
  chassis.drive_distance(5.5); // drive to 1st ring
  
  
  //doinkR.open();
  
  //wait(200, msec);
  
  chassis.drive_distance(-10); //drive backwards slower
  
  dRexit=false; 
  chassis.drive_max_voltage = 12;
  
  chassis.turn_max_voltage = 12;
  
  chassis.turn_min_voltage = 0;
  
  chassis.turn_to_angle(85); 
  
  
  doinkR.close();  //close doinker
  
  
  intake.spin(reverse,100,pct);
  FrontstraightVisionST(1100, 165, 8, 0, 5, 0, 2000); // get both rings
  chassis.drive_distance(6.5); 
  

  
  //chassis.turn_settle_time = 300; //accurate turn
  chassis.turn_max_voltage = 8;
  chassis.turn_to_angle(235); //turn to go across field
  chassis.turn_max_voltage = 12;
  
  task::stop(autoclamp); 
  backClaw.close();            //open claw to drop
  intake.spin(fwd, 100, pct);
  wait(0.5,sec);
  intake.spin(reverse, 100, pct);
  
  chassis.drive_distance(48);  
  chassis.turn_to_angle(130);
  intake.stop();
  task t716241(autoclamp); 
  scanB(350, 6);
  breakout=true;
  breakdistance = -100;
  BackstraightVisionST(-1400, 160, 12, 0, 5, 0, 2000); 
  breakout=false;
  chassis.drive_max_voltage = 4;
  chassis.drive_min_voltage = 0;
  chassis.drive_distance(-12); ///get goal slower
  
  backClaw.open();
  
  chassis.turn_to_angle(270);
  intake.spin(reverse, 100, pct);
  chassis.drive_max_voltage = 12;
  scanF(300, 6);
  earlyexit=true;
  breakout=false;
  FrontstraightVisionST(1200, 250, 12, 0, 5, 0, 2000);
  chassis.drive_distance(6);
  //frontdistanceNew(12, 270, 12, 0, 1, 100, 3000); 
  
  aspeed = 12;
  adesiredValue = 150;
  task t64674(armPID);            //LB for 1st ring
  g=0;
  L=0;
  frontdistanceNew(60, 260, 12, 0, 1, 100, 3000); 
  
  wait(300000000, sec);


}

void BigRed2()

{
  Inertial20.setHeading(90, deg); // 160 inertial, 1500 back distance
  chassis.set_coordinates(0, 0, 90);  

  greengoalb=true;
  bluering = false;
  redring = true;
  redringi = true;
  blueringc=true;
  redringc=false;
  greenb = true;

  g=0;
  intake.setPosition(0, degrees);
  ringliftL.setPosition(0, degrees);
  backClaw.open();
  lbp2.close();
  T2.clear();

  earlyexit = false;

  lineexit = false;
  AWBB();
  AWB();
  AWBI();

 
  doinkL.open(); 
  BackstraightVisionST(-600, 160, 11, 6, 5, 0, 2000);   //get goal
  chassis.drive_max_voltage=11;
  chassis.drive_distance(-8);
  
  backClaw.close();
  wait(300, msec);
  task t61010(colorsortAuto);                         //colorsort on 
  doinkL.close();
  
  chassis.turn_max_voltage=6;
  chassis.turn_to_angle(180);         //slower turn to make sure ring doesn't fly out
  chassis.turn_max_voltage=10;
  
  breakdistance = 350;
  breakout = true;
  FrontstraightVisionST(750, 165, 10, 8, 5, 0, 3000); //$$$$$$$1string
  breakout = false;
  ee = 2;
  earlyexit = true;
  FrontstraightVisionST(950, 165, 8, 6, 5, 0, 3000); 
  //FrontdistanceVisionST(1, 165, 10, 0, 1, 0, 3000);   //$$$$$$$$1st ring
  //allMtrsStop();
  //doinkR.open();                                       //right doinker down
  earlyexit = false;                                    
  //waitforring = true;                                 //wait for ring to come in
  //chassis.drive_distance(4);                          //a bit further
  //waitforring = false;
  chassis.turn_to_angle(80);                         //turn around
  //task::stop(colorsortAuto);                          //turn off intake and colorsort
  //intake.stop();
  frontdistanceNew(24, 80, 10, 8, 1, 0, 2000);        //forward to wall
  task::stop(colorsortAuto); 
  intake.spin(fwd, 100, pct);                         //reverse intake
  chassis.turn_to_angle(140);                          //turn to face corner ring stack
  doinkR.close();                                     //right doinker up
  scanF(300, 5);
  
  task t610910(colorsortAuto);                        //start colorsort
  earlyexit = true;                                   
  chassis.drive_timeout = 1200;
  ee = 4;                                             //this changes distance for early exit                     
  FrontstraightVisionST(1400, 165, 7, 5, 5, 0, 3000); //go towards red rings in stack
  waitforring = true;                                 //wait for the ring to come in while moving backwards
  chassis.drive_max_voltage = 7;
  chassis.drive_distance(-14);
  waitforring = false;

  ee = 2;
  FrontstraightVisionST(1400, 165, 7, 5, 5, 0, 2000); 
  waitforring = true;
  
  chassis.drive_distance(-14);
  waitforring = false;
  
  FrontstraightVisionST(1400, 165, 7, 5, 5, 0, 2000); 
  waitforring = true;
  
  chassis.drive_distance(-14);
  waitforring = false;

  FrontstraightVisionST(1400, 165, 7, 5, 5, 0, 2000); 
  waitforring = true;
  
  chassis.drive_distance(-14);
  waitforring = false;

  earlyexit = false;                                   // turn off early exit
  
  chassis.turn_to_angle(182);                          //turn to angle slightly right of 180

  frontdistanceNew(35, 182, 10, 8, 1, 0, 2000); 

  doinkR.open();                                        //right doinker down to turn right
  lbp.open();                                           //intake piston up

  chassis.turn_to_angle(355);                           //turn right and clear any rings in front of you
  doinkR.close();                                       //right doinker up

  multipleobjectsR = true;
  ee = 3.5;
  earlyexit = true;
  FrontstraightVisionST(1400, 165, 10, 0, 5, 0, 3000); 
  //FrontdistanceVisionST(4, 165, 10, 0, 1, 0, 2000);      //$$4th ring on stack
  multipleobjectsR = false;

  chassis.drive_max_voltage = 12;
  chassis.drive_distance(-12, 0);                        //back up a bit
  chassis.turn_to_angle(285);                            //turn to go to ladder

  aspeed = 12;                                           // arm up to contact ladder
  adesiredValue = 500;
  task t645474(armPID);

  backdistanceNew(30, 285, 12, 0, 1, 0, 2000);           // distance to ladder
 
  


wait(3000000, sec);
}

void BigBlue2()  //blue negative side

{
  Inertial20.setHeading(270, deg); // 160 inertial, 1500 back distance
  chassis.set_coordinates(0, 0, 270);  
  greengoalb=true;
  bluering = true;
  redring = false;
  redringi = false;
  blueringc= false;
  redringc= true;
  greenb = true;
  /*
  greengoalb=true;
  bluering = false;
  redring = true;
  redringi = true;
  blueringc=true;
  redringc=false;
  greenb = true;*/

  g=0;
  intake.setPosition(0, degrees);
  ringliftL.setPosition(0, degrees);
  backClaw.open();
  lbp2.close();
  T2.clear();

  earlyexit = false;

  lineexit = false;
  AWBB();
  AWB();
  AWBI();

  colorEncoder = 200;

 
  doinkL.open(); 
  BackstraightVisionST(-600, 160, 11, 6, 5, 0, 2000);   //get goal
  chassis.drive_max_voltage=11;
  chassis.drive_distance(-8);
  
  backClaw.close();
  wait(300, msec);
  task t61010(colorsortAuto);                         //colorsort on 
  doinkL.close();
  
  chassis.turn_max_voltage=6;
  chassis.turn_to_angle(181);         //slower turn to make sure ring doesn't fly out
  chassis.turn_max_voltage=10;
  
  breakdistance = 350;
  breakout = true;
  FrontstraightVisionST(600, 165, 10, 8, 5, 0, 3000); //$$$$$$$1string
  breakout = false;
  ee = 2;
  earlyexit = true;
  FrontstraightVisionST(950, 165, 8, 6, 5, 0, 3000); 
  //FrontdistanceVisionST(1, 165, 10, 0, 1, 0, 3000);   //$$$$$$$$1st ring
  //allMtrsStop();
  //doinkR.open();                                       //right doinker down
  earlyexit = false;                                    
  //waitforring = true;                                 //wait for ring to come in
  //chassis.drive_distance(4);                          //a bit further
  //waitforring = false;
  chassis.turn_to_angle(280);                         //turn around
  //task::stop(colorsortAuto);                          //turn off intake and colorsort
  //intake.stop();
  frontdistanceNew(24, 280, 10, 8, 1, 0, 2000);        //forward to wall
  task::stop(colorsortAuto); 
  intake.spin(fwd, 100, pct);                         //reverse intake
  chassis.turn_to_angle(220);                          //turn to face corner ring stack
  doinkR.close();                                     //right doinker up
  scanF(300, 5);
  
  task t610910(colorsortAuto);                        //start colorsort
  earlyexit = true;                                   
  chassis.drive_timeout = 1200;
  ee = 4;                                             //this changes distance for early exit                     
  FrontstraightVisionST(1400, 165, 7, 5, 5, 0, 3000); //go towards red rings in stack
  waitforring = true;                                 //wait for the ring to come in while moving backwards
  chassis.drive_max_voltage = 7;
  chassis.drive_distance(-14);
  waitforring = false;

  ee = 2;
  FrontstraightVisionST(1400, 165, 7, 5, 5, 0, 2000); 
  waitforring = true;
  
  chassis.drive_distance(-14);
  waitforring = false;
  
  FrontstraightVisionST(1400, 165, 7, 5, 5, 0, 2000); 
  waitforring = true;
  
  chassis.drive_distance(-14);
  waitforring = false;

  FrontstraightVisionST(1400, 165, 7, 5, 5, 0, 2000); 
  waitforring = true;
  
  chassis.drive_distance(-14);
  waitforring = false;

  earlyexit = false;                                   // turn off early exit
  
  chassis.turn_to_angle(178);                          //turn to angle slightly left of 180

  frontdistanceNew(30, 179, 10, 8, 1, 0, 2000); 

  doinkL.open();                                        //left doinker down to turn left
  lbp.open();                                           //intake piston up

  chassis.turn_to_angle(1);                           //turn left and clear any rings in front of you
  doinkL.close();                                       //left doinker up

  multipleobjectsL = true;
  ee = 3.5;
  earlyexit = true;
  FrontstraightVisionST(1400, 165, 10, 0, 5, 0, 3000); 
  //FrontdistanceVisionST(4, 165, 10, 0, 1, 0, 2000);      //$$4th ring on stack
  multipleobjectsL = false;
  
  chassis.drive_max_voltage = 12;
  chassis.drive_distance(-12, 180);                      // back up a bit
  chassis.turn_to_angle(75);                            //turn to go back to ladder

  aspeed = 12;                                          //arm up to contact ladder
  adesiredValue = 500;
  task t645474(armPID);

  backdistanceNew(30, 75, 12, 0, 1, 0, 2000);          //distance to ladder



wait(3000000, sec);
}

void BigBlue3()

{
  Inertial20.setHeading(270, deg); // 160 inertial, 1500 back distance
  chassis.set_coordinates(0, 0, 270);  
  greengoalb=true;
  bluering = true;
  redring = false;
  redringi = false;
  blueringc= false;
  redringc= true;
  greenb = true;
  /*
  greengoalb=true;
  bluering = false;
  redring = true;
  redringi = true;
  blueringc=true;
  redringc=false;
  greenb = true;*/

  g=0;
  intake.setPosition(0, degrees);
  ringliftL.setPosition(0, degrees);
  backClaw.open();
  lbp2.close();
  T2.clear();

  earlyexit = false;

  lineexit = false;
  AWBB();
  AWB();
  AWBI();
 
  doinkL.open(); 
  BackstraightVisionST(-600, 160, 11, 6, 5, 0, 2000);   //get goal
  chassis.drive_max_voltage=11;
  chassis.drive_distance(-8);
  
  backClaw.close();
  wait(300, msec);
  task t61010(colorsortAuto);                         //colorsort on 
  doinkL.close(); 
  
  chassis.turn_max_voltage=6;
  chassis.turn_to_angle(0);         //slower turn to make sure ring doesn't fly out
  chassis.turn_max_voltage=10;
  
  breakdistance = 350;
  breakout = true;
  FrontstraightVisionST(600, 165, 10, 8, 5, 0, 3000); //$$$$$$$1string
  breakout = false;
  ee = 2;
  earlyexit = true;
  FrontstraightVisionST(950, 165, 8, 6, 5, 0, 3000); 
  //FrontdistanceVisionST(1, 165, 10, 0, 1, 0, 3000);   //$$$$$$$$1st ring
  //allMtrsStop();
  //doinkR.open();                                       //right doinker down
  earlyexit = false;                                    
  //waitforring = true;                                 //wait for ring to come in
  //chassis.drive_distance(4);                          //a bit further
  //waitforring = false;
  chassis.turn_to_angle(80);                         //turn left
  //task::stop(colorsortAuto);                          //turn off intake and colorsort
  //intake.stop();
  backdistanceNew(24, 80, 10, 8, 1, 0, 2000);        //back up to wall
  task::stop(colorsortAuto); 
  intake.spin(fwd, 100, pct);                         //reverse intake
  chassis.turn_to_angle(320);                          //turn to face corner ring stack
  doinkR.close();                                     //right doinker up
  scanF(300, 5);
  
  task t610910(colorsortAuto);                        //start colorsort
  earlyexit = true;                                   
  chassis.drive_timeout = 1200;
  ee = 4;                                             //this changes distance for early exit                     
  FrontstraightVisionST(1400, 165, 7, 5, 5, 0, 3000); //go towards red rings in stack
  waitforring = true;                                 //wait for the ring to come in while moving backwards
  chassis.drive_max_voltage = 7;
  chassis.drive_distance(-14);
  waitforring = false;

  ee = 2;
  FrontstraightVisionST(1400, 165, 7, 5, 5, 0, 2000); 
  waitforring = true;
  
  chassis.drive_distance(-14);
  waitforring = false;
  
  FrontstraightVisionST(1400, 165, 7, 5, 5, 0, 2000); 
  waitforring = true;
  
  chassis.drive_distance(-14);
  waitforring = false;

  FrontstraightVisionST(1400, 165, 7, 5, 5, 0, 2000); 
  waitforring = true;
  
  chassis.drive_distance(-14);
  waitforring = false;

  earlyexit = false;                                   // turn off early exit
  
  chassis.turn_to_angle(2);                          //turn to angle slightly right of 0

  frontdistanceNew(30, 1, 10, 8, 1, 0, 2000); 

  doinkR.open();                                        //right doinker down to turn left
  lbp.open();                                           //intake piston up

  chassis.turn_to_angle(179);                           //turn right and clear any rings in front of you
  doinkR.close();                                       //right doinker up

  multipleobjectsR = true;
  ee = 3.5;
  earlyexit = true;
  FrontstraightVisionST(1000, 165, 10, 0, 5, 0, 3000); 
  //FrontdistanceVisionST(4, 165, 10, 0, 1, 0, 2000);      //$$4th ring on stack
  multipleobjectsR = false;
  chassis.turn_to_angle(165);                            //turn to go back to wall

  backdistanceNew(14, 165, 12, 0, 1, 0, 2000);           // back to wall

  task::stop(autoclamp);

  backClaw.open();                                       //drop goal


wait(3000000, sec);
}

void BigBlue()

{
  Inertial20.setHeading(214, deg); // 160 inertial, 1500 back distance
  chassis.set_coordinates(0, 0, 214);  //214
  /*
  greengoalb=true;
  redring = true;
  redringi = true;
  blueringc=true;
  redringc=false;
  greenb = true;*/

  greengoalb=true;
  bluering = true;
  blueringi = true;
  redringc=true;
  blueringc=false; 
  greenb = true;
  
  g=0;
  intake.setPosition(0, degrees);
  T2.clear();
  
  earlyexit = false;
  
  lineexit = false;
  AWBB();
  AWB();
  

  /*
  breakout=false;
  breakdistance = 10;
  chassis.turn_to_angle(60); 
  scanF(300, 8);
  //FrontturnVisionST(165, 10, 10, 10, 0, 1000);
  breakout=true;
  lBase2.setPosition(0, degrees); 
  breakdistance = 100;
  FrontstraightVisionST(1400, 165, 12, 0, 5, 0, 2000); //1400 is 24inches
  chassis.drive_distance(10);
  lBase2.setPosition(0, degrees); 
  wait(3000000000,sec);
  chassis.drive_max_voltage = 12;
  chassis.drive_min_voltage = 0;
  chassis.heading_max_voltage = 12;
  //chassis.drive_settle_error = 8;
  breakout=true;
  breakdistance = 10;
  chassis.drive_distance(34);
  
    breakout=true; 
    breakdistance = 500; 
  FrontstraightVisionST(4000, 165, 12, 0, 5, 0, 2000); //1400 is 24inches
  chassis.drive_min_voltage = 0;
  chassis.drive_settle_error = 2;
  breakout=false; 
  
  chassis.drive_distance(10);
  wait(300000000000, sec);
  
  */
  
  while(rotationARM.position(degrees)<=150)             // 3rd ring on stake
        {
          ringliftL.spin(fwd, 100, pct);
          ringliftR.spin(fwd, 100, pct);
          printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
        }
        ringliftL.stop(hold);
        ringliftR.stop(hold); 
  wait(300, msec);
  aspeed = 12;
  adesiredValue = 0;
  task t64161474(armPID);
  
  v=0;
  
  task t71621(autoclamp); 
  
  //scanB(300, 6);
  //BackturnVisionST(160, 12, 10, 15, 0, 1000); // lock in to get goal
  breakout=true;
  breakdistance = -100;
  BackstraightVisionST(-1500, 160, 10, 0, 10, 0, 2000); 
  breakout=false;
  chassis.drive_max_voltage = 4;
  chassis.drive_min_voltage = 0;
  chassis.drive_distance(-12); ///get goal slower
  
  backClaw.open(); // close back claw
  
  chassis.drive_max_voltage = 12; 
  //chassis.drive_distance(8); // drive foward to 1st red ring stack 4.1
  scanF(300, 6);  //scan right for red ring
  breakout=true;
  breakdistance = 100;
  FrontstraightVisionST(800, 250, 10, 0, 5, 0, 2000);
  //FrontturnVisionST(250, 12, 10, 25, 0, 2000); // lock in doinkerR for red ring
  dRexit=true;
  breakout=false;          // put doinder down when within 4 inch error
  chassis.drive_distance(5.5); // drive to 1st ring
  
  
  //doinkR.open();
  
  //wait(200, msec);
  
  chassis.drive_distance(-10); //drive backwards slower
  
  dRexit=false; 
  chassis.drive_max_voltage = 12;
  
  chassis.turn_max_voltage = 12;
  
  chassis.turn_min_voltage = 0;
  
  chassis.turn_to_angle(85); 
  
  
  doinkR.close();  //close doinker
  
  
  intake.spin(reverse,100,pct);
  FrontstraightVisionST(1100, 165, 8, 0, 5, 0, 2000); // get both rings
  chassis.drive_distance(6.5); 
  

  
  //chassis.turn_settle_time = 300; //accurate turn
  chassis.turn_max_voltage = 8;
  chassis.turn_to_angle(235); //turn to go across field
  chassis.turn_max_voltage = 12;
  
  task::stop(autoclamp); 
  backClaw.close();            //open claw to drop
  intake.spin(fwd, 100, pct);
  wait(0.5,sec);
  intake.spin(reverse, 100, pct);
  
  chassis.drive_distance(48);  
  chassis.turn_to_angle(130);
  intake.stop();
  task t716241(autoclamp); 
  scanB(350, 6);
  breakout=true;
  breakdistance = -100;
  BackstraightVisionST(-1400, 160, 12, 0, 5, 0, 2000); 
  breakout=false;
  chassis.drive_max_voltage = 4;
  chassis.drive_min_voltage = 0;
  chassis.drive_distance(-12); ///get goal slower
  
  backClaw.open();
  
  chassis.turn_to_angle(270);
  intake.spin(reverse, 100, pct);
  chassis.drive_max_voltage = 12;
  scanF(300, 6);
  earlyexit=true;
  breakout=false;
  FrontstraightVisionST(1200, 250, 12, 0, 5, 0, 2000);
  chassis.drive_distance(6);
  //frontdistanceNew(12, 270, 12, 0, 1, 100, 3000); 
  
  aspeed = 12;
  adesiredValue = 150;
  task t64674(armPID);            //LB for 1st ring
  g=0;
  L=0;
  frontdistanceNew(60, 260, 12, 0, 1, 100, 3000); 
  
  wait(300000000, sec);


}

void RedElims()
{
  Inertial20.setHeading(270, deg); // 160 inertial, 1500 back distance
  chassis.set_coordinates(0, 0, 270);  //214
  
  greengoalb=true;
  bluering = false;
  redring = true;
  redringi = true;
  blueringc=true;
  redringc=false;
  greenb = true;

  g=0;
  intake.setPosition(0, degrees);
  ringliftL.setPosition(0, degrees);
  backClaw.open();
  lbp2.close();
  T2.clear();

  earlyexit = false;

  lineexit = false;
  AWBB();
  AWB();
  AWBI();

  chassis.turn_to_angle(240);
  breakout=true;
  breakdistance = 350;
  FrontstraightVisionST(2350, 240, 10, 0, 5, 0, 2000);
  //FrontturnVisionST(250, 12, 10, 25, 0, 2000); // lock in doinkerR for red ring
  dRexit=true;
  breakout=false;          // put doinder down when within 4 inch error
  chassis.drive_distance(5);
 
  chassis.turn_to_angle(240);
  scanB(300, -5);
  BackstraightVisionST(-1100, 160, 11, 6, 5, 0, 2000);   //get goal
  chassis.drive_max_voltage=11;
  chassis.drive_distance(-10);

  dRexit=false; 


  doinkR.close();  //close doinker






  task t71621(autoclamp); 
  
  //scanB(300, 6);
  //BackturnVisionST(160, 12, 10, 15, 0, 1000); // lock in to get goal
  breakout=true;
  breakdistance = -100;
  BackstraightVisionST(-1600, 160, 10, 0, 10, 0, 2000); 
  breakout=false;
  chassis.drive_max_voltage = 4;
  chassis.drive_min_voltage = 0;
  chassis.drive_distance(-8); ///get goal slower
  
  backClaw.open(); // close back claw
  
  chassis.turn_to_angle(335);
  intake.spin(reverse, 100, pct);
  chassis.drive_distance(2);
  
  scanF(300, 6);  //scan right for red ring
  breakout=true;
  breakdistance = 100;
  FrontstraightVisionST(650, 240, 10, 0, 5, 0, 2000);
  //FrontturnVisionST(250, 12, 10, 25, 0, 2000); // lock in doinkerR for red ring
  dRexit=true;
  breakout=false;          // put doinder down when within 4 inch error
  chassis.drive_distance(5);
  chassis.drive_max_voltage = 12;
  chassis.drive_distance(-16); //drive backwards slower
  
  dRexit=false; 
  chassis.drive_max_voltage = 12;
  
  chassis.turn_max_voltage = 12;
  
  chassis.turn_min_voltage = 0;
   
  doinkR.close();  //close doinker
  
  FrontstraightVisionST(700, 165, 8, 0, 5, 0, 2000); // get both rings
  chassis.drive_distance(3); 

  //chassis.drive_distance(10);

  chassis.drive_distance(-12);

  chassis.turn_to_angle(90);
  
  
  intake.spin(reverse, 100, pct);
  chassis.drive_max_voltage = 12;
  scanF(300, 6);
  earlyexit=true;
  breakout=false;
  FrontstraightVisionST(700, 165, 12, 0, 5, 0, 2000);
  chassis.drive_distance(4);

  task t519(colorsortAuto);

  chassis.turn_to_angle(145);

  chassis.drive_max_voltage = 8;
  chassis.drive_distance(36);
  doinkL.open();

  chassis.turn_max_voltage = 6;
  chassis.turn_to_angle(225);
  doinkL.close();
  scanF(300, 6);
  earlyexit=true;
  FrontstraightVisionST(1000, 165, 12, 0, 5, 0, 2000);
  chassis.turn_to_angle(130);
  scanF(300, -6);
  wait(0.5, sec);
  /*
  earlyexit=false;
  FrontstraightVisionST(700, 165, 12, 0, 5, 0, 2000);
  chassis.drive_distance(6);*/

  //chassis.drive_distance(-20);
  task::stop(colorsortAuto);
  chassis.turn_to_angle(270);
  chassis.drive_distance(-20);
  intake.spin(fwd, 100, pct);
  backClaw.close();
  chassis.turn_to_angle(180);
  chassis.drive_distance(-24);

  /*scanF(300, 6);  //scan right for red ring
  breakout=true;
  breakdistance = 100;
  FrontstraightVisionST(800, 250, 10, 0, 5, 0, 2000);
  //FrontturnVisionST(250, 12, 10, 25, 0, 2000); // lock in doinkerR for red ring
  dRexit=true;
  breakout=false;          // put doinder down when within 4 inch error
  chassis.drive_distance(5.5);

  chassis.drive_distance(-10); //drive backwards slower
  
  dRexit=false; 
  chassis.drive_max_voltage = 12;
  
  chassis.turn_max_voltage = 12;
  
  chassis.turn_min_voltage = 0;
   
  
  
  doinkR.close();  //close doinker
  
  FrontstraightVisionST(1100, 165, 8, 0, 5, 0, 2000); // get both rings
  chassis.drive_distance(6.5);*/ 
  
  wait (30000000000,sec);
}
void BlueElims()
{
  Inertial20.setHeading(180, deg); // 160 inertial, 1500 back distance
  chassis.set_coordinates(0, 0, 180);  //214
  /*
  greengoalb=true;
  redring = true;
  redringi = true;
  blueringc=true;
  redringc=false;
  greenb = true; */

  greengoalb=true;
  bluering = true;
  blueringi = true;
  redringc=true;
  blueringc=false; 
  greenb = true;
  
  g=0;
  intake.setPosition(0, degrees);
  T2.clear();
  
  earlyexit = false;
  
  lineexit = false;
  AWBB();
  AWB(); 

  task t71621(autoclamp); 
  
  //scanB(300, 6);
  //BackturnVisionST(160, 12, 10, 15, 0, 1000); // lock in to get goal
  breakout=true;
  breakdistance = -100;
  BackstraightVisionST(-1600, 160, 10, 0, 10, 0, 2000); 
  breakout=false;
  chassis.drive_max_voltage = 4;
  chassis.drive_min_voltage = 0;
  chassis.drive_distance(-8); ///get goal slower
  
  backClaw.open(); // close back claw
  
  chassis.turn_to_angle(335);
  intake.spin(reverse, 100, pct);
  chassis.drive_distance(2);
  
  scanF(300, 6);  //scan right for red ring
  breakout=true;
  breakdistance = 100;
  FrontstraightVisionST(650, 240, 10, 0, 5, 0, 2000);
  //FrontturnVisionST(250, 12, 10, 25, 0, 2000); // lock in doinkerR for red ring
  dRexit=true;
  breakout=false;          // put doinder down when within 4 inch error
  chassis.drive_distance(5);
  chassis.drive_max_voltage = 12;
  chassis.drive_distance(-16); //drive backwards slower
  
  dRexit=false; 
  chassis.drive_max_voltage = 12;
  
  chassis.turn_max_voltage = 12;
  
  chassis.turn_min_voltage = 0;
   
  doinkR.close();  //close doinker
  
  FrontstraightVisionST(700, 165, 8, 0, 5, 0, 2000); // get both rings
  chassis.drive_distance(3); 

  //chassis.drive_distance(10);

  chassis.drive_distance(-12);

  chassis.turn_to_angle(90);
  
  
  intake.spin(reverse, 100, pct);
  chassis.drive_max_voltage = 12;
  scanF(300, 6);
  earlyexit=true;
  breakout=false;
  FrontstraightVisionST(700, 165, 12, 0, 5, 0, 2000);
  chassis.drive_distance(4);

  task t519(colorsortAuto);

  chassis.turn_to_angle(145);

  chassis.drive_max_voltage = 8;
  chassis.drive_distance(36);
  doinkL.open();

  chassis.turn_max_voltage = 6;
  chassis.turn_to_angle(225);
  doinkL.close();
  scanF(300, 6);
  earlyexit=true;
  FrontstraightVisionST(1000, 165, 12, 0, 5, 0, 2000);
  chassis.turn_to_angle(130);
  scanF(300, -6);
  wait(0.5, sec);
  /*
  earlyexit=false;
  FrontstraightVisionST(700, 165, 12, 0, 5, 0, 2000);
  chassis.drive_distance(6);*/

  //chassis.drive_distance(-20);
  task::stop(colorsortAuto);
  chassis.turn_to_angle(270);
  chassis.drive_distance(-20);
  intake.spin(fwd, 100, pct);
  backClaw.close();
  chassis.turn_to_angle(180);
  chassis.drive_distance(-24);

  /*scanF(300, 6);  //scan right for red ring
  breakout=true;
  breakdistance = 100;
  FrontstraightVisionST(800, 250, 10, 0, 5, 0, 2000);
  //FrontturnVisionST(250, 12, 10, 25, 0, 2000); // lock in doinkerR for red ring
  dRexit=true;
  breakout=false;          // put doinder down when within 4 inch error
  chassis.drive_distance(5.5);

  chassis.drive_distance(-10); //drive backwards slower
  
  dRexit=false; 
  chassis.drive_max_voltage = 12;
  
  chassis.turn_max_voltage = 12;
  
  chassis.turn_min_voltage = 0;
   
  
  
  doinkR.close();  //close doinker
  
  FrontstraightVisionST(1100, 165, 8, 0, 5, 0, 2000); // get both rings
  chassis.drive_distance(6.5);*/ 
  
  wait (30000000000,sec);
}

void RedWithStake()
{
  Inertial20.setHeading(214, deg); // 160 inertial, 1500 back distance
  chassis.set_coordinates(0, 0, 214);  //214
  
  greengoalb=true;
  redring = true;
  redringi = true;
  blueringc=true;
  redringc=false;
  greenb = true;
/*
  greengoalb=true;
  bluering = true;
  blueringi = true;
  redringc=true;
  blueringc=false; 
  greenb = true;
  */
  g=0;
  intake.setPosition(0, degrees);
  T2.clear();
  
  earlyexit = false;
  
  lineexit = false;
  AWBB();
  AWB();
  
  

  /*
  breakout=false;
  breakdistance = 10;
  chassis.turn_to_angle(60); 
  scanF(300, 8);
  //FrontturnVisionST(165, 10, 10, 10, 0, 1000);
  breakout=true;
  lBase2.setPosition(0, degrees); 
  breakdistance = 100;
  FrontstraightVisionST(1400, 165, 12, 0, 5, 0, 2000); //1400 is 24inches
  chassis.drive_distance(10);
  lBase2.setPosition(0, degrees); 
  wait(3000000000,sec);
  chassis.drive_max_voltage = 12;
  chassis.drive_min_voltage = 0;
  chassis.heading_max_voltage = 12;
  //chassis.drive_settle_error = 8;
  breakout=true;
  breakdistance = 10;
  chassis.drive_distance(34);
  
    breakout=true; 
    breakdistance = 500; 
  FrontstraightVisionST(4000, 165, 12, 0, 5, 0, 2000); //1400 is 24inches
  chassis.drive_min_voltage = 0;
  chassis.drive_settle_error = 2;
  breakout=false; 
  
  chassis.drive_distance(10);
  wait(300000000000, sec);
  
  */
  
  while(rotationARM.position(degrees)<=150)             // 3rd ring on stake
        {
          ringliftL.spin(fwd, 100, pct);
          ringliftR.spin(fwd, 100, pct);
          printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
        }
        ringliftL.stop(hold);
        ringliftR.stop(hold); 
  wait(300, msec);
  aspeed = 12;
  adesiredValue = 0;
  task t64161474(armPID);
  
  v=0;
  
  task t71621(autoclamp); 
  
  //scanB(300, 6);
  //BackturnVisionST(160, 12, 10, 15, 0, 1000); // lock in to get goal
  breakout=true;
  breakdistance = -100;
  BackstraightVisionST(-1500, 160, 10, 0, 10, 0, 2000); 
  breakout=false;
  chassis.drive_max_voltage = 4;
  chassis.drive_min_voltage = 0;
  chassis.drive_distance(-12); ///get goal slower
  
  backClaw.open(); // close back claw
  
  chassis.drive_max_voltage = 12; 
  //chassis.drive_distance(8); // drive foward to 1st red ring stack 4.1
  scanF(300, 6);  //scan right for red ring
  breakout=true;
  breakdistance = 100;
  FrontstraightVisionST(800, 250, 10, 0, 5, 0, 2000);
  //FrontturnVisionST(250, 12, 10, 25, 0, 2000); // lock in doinkerR for red ring
  dRexit=true;
  breakout=false;          // put doinder down when within 4 inch error
  chassis.drive_distance(5.5); // drive to 1st ring
  
  
  //doinkR.open();
  
  //wait(200, msec);
  
  chassis.drive_distance(-10); //drive backwards slower
  
  dRexit=false; 
  chassis.drive_max_voltage = 12;
  
  chassis.turn_max_voltage = 12;
  
  chassis.turn_min_voltage = 0;
  
  chassis.turn_to_angle(85); 
  
  
  doinkR.close();  //close doinker
  
  
  intake.spin(reverse,100,pct);
  FrontstraightVisionST(1100, 165, 8, 0, 5, 0, 2000); // get both rings
  chassis.drive_distance(6.5); 

  task t519(colorsortAuto);

  chassis.turn_to_angle(145);

  chassis.drive_max_voltage = 8;
  chassis.drive_distance(36);
  doinkL.open();

  chassis.turn_max_voltage = 6;
  chassis.turn_to_angle(225);
  doinkL.close();
  scanF(300, 6);
  earlyexit=true;
  FrontstraightVisionST(1000, 165, 12, 0, 5, 0, 2000);
  chassis.turn_to_angle(130);
  scanF(300, -6);
  wait(0.5, sec);
  /*
  earlyexit=false;
  FrontstraightVisionST(700, 165, 12, 0, 5, 0, 2000);
  chassis.drive_distance(6);*/

  //chassis.drive_distance(-20);
  task::stop(colorsortAuto);
  chassis.turn_to_angle(270);
  chassis.drive_distance(-15);
  intake.spin(fwd, 100, pct);
  backClaw.close();
  chassis.turn_to_angle(180);
  chassis.drive_distance(-24);

  /*scanF(300, 6);  //scan right for red ring
  breakout=true;
  breakdistance = 100;
  FrontstraightVisionST(800, 250, 10, 0, 5, 0, 2000);
  //FrontturnVisionST(250, 12, 10, 25, 0, 2000); // lock in doinkerR for red ring
  dRexit=true;
  breakout=false;          // put doinder down when within 4 inch error
  chassis.drive_distance(5.5);

  chassis.drive_distance(-10); //drive backwards slower
  
  dRexit=false; 
  chassis.drive_max_voltage = 12;
  
  chassis.turn_max_voltage = 12;
  
  chassis.turn_min_voltage = 0;
   
  
  
  doinkR.close();  //close doinker
  
  FrontstraightVisionST(1100, 165, 8, 0, 5, 0, 2000); // get both rings
  chassis.drive_distance(6.5);*/ 
  
  wait (30000000000,sec);
}

void BlueWithStake()
{
  Inertial20.setHeading(214, deg); // 160 inertial, 1500 back distance
  chassis.set_coordinates(0, 0, 214);  //214
  /*
  greengoalb=true;
  redring = true;
  redringi = true;
  blueringc=true;
  redringc=false;
  greenb = true;*/

  greengoalb=true;
  bluering = true;
  blueringi = true;
  redringc=true;
  blueringc=false; 
  greenb = true;
  
  g=0;
  intake.setPosition(0, degrees);
  T2.clear();
  
  earlyexit = false;
  
  lineexit = false;
  AWBB();
  AWB();
  
  

  /*
  breakout=false;
  breakdistance = 10;
  chassis.turn_to_angle(60); 
  scanF(300, 8);
  //FrontturnVisionST(165, 10, 10, 10, 0, 1000);
  breakout=true;
  lBase2.setPosition(0, degrees); 
  breakdistance = 100;
  FrontstraightVisionST(1400, 165, 12, 0, 5, 0, 2000); //1400 is 24inches
  chassis.drive_distance(10);
  lBase2.setPosition(0, degrees); 
  wait(3000000000,sec);
  chassis.drive_max_voltage = 12;
  chassis.drive_min_voltage = 0;
  chassis.heading_max_voltage = 12;
  //chassis.drive_settle_error = 8;
  breakout=true;
  breakdistance = 10;
  chassis.drive_distance(34);
  
    breakout=true; 
    breakdistance = 500; 
  FrontstraightVisionST(4000, 165, 12, 0, 5, 0, 2000); //1400 is 24inches
  chassis.drive_min_voltage = 0;
  chassis.drive_settle_error = 2;
  breakout=false; 
  
  chassis.drive_distance(10);
  wait(300000000000, sec);
  
  */
  
  while(rotationARM.position(degrees)<=150)             // 3rd ring on stake
        {
          ringliftL.spin(fwd, 100, pct);
          ringliftR.spin(fwd, 100, pct);
          printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
        }
        ringliftL.stop(hold);
        ringliftR.stop(hold); 
  wait(300, msec);
  aspeed = 12;
  adesiredValue = 0;
  task t64161474(armPID);
  
  v=0;
  
  task t71621(autoclamp); 
  
  //scanB(300, 6);
  //BackturnVisionST(160, 12, 10, 15, 0, 1000); // lock in to get goal
  breakout=true;
  breakdistance = -100;
  BackstraightVisionST(-1500, 160, 10, 0, 10, 0, 2000); 
  breakout=false;
  chassis.drive_max_voltage = 4;
  chassis.drive_min_voltage = 0;
  chassis.drive_distance(-12); ///get goal slower
  
  backClaw.open(); // close back claw
  
  chassis.drive_max_voltage = 12; 
  //chassis.drive_distance(8); // drive foward to 1st red ring stack 4.1
  scanF(300, 6);  //scan right for red ring
  breakout=true;
  breakdistance = 100;
  FrontstraightVisionST(800, 250, 10, 0, 5, 0, 2000);
  //FrontturnVisionST(250, 12, 10, 25, 0, 2000); // lock in doinkerR for red ring
  dRexit=true;
  breakout=false;          // put doinder down when within 4 inch error
  chassis.drive_distance(5.5); // drive to 1st ring
  
  
  //doinkR.open();
  
  //wait(200, msec);
  
  chassis.drive_distance(-10); //drive backwards slower
  
  dRexit=false; 
  chassis.drive_max_voltage = 12;
  
  chassis.turn_max_voltage = 12;
  
  chassis.turn_min_voltage = 0;
  
  chassis.turn_to_angle(85); 
  
  
  doinkR.close();  //close doinker
  
  
  intake.spin(reverse,100,pct);
  FrontstraightVisionST(1100, 165, 8, 0, 5, 0, 2000); // get both rings
  chassis.drive_distance(6.5); 

  task t519(colorsortAuto);

  chassis.turn_to_angle(145);

  chassis.drive_max_voltage = 8;
  chassis.drive_distance(36);
  doinkL.open();

  chassis.turn_max_voltage = 6;
  chassis.turn_to_angle(225);
  doinkL.close();
  scanF(300, 6);
  earlyexit=true;
  FrontstraightVisionST(1000, 165, 12, 0, 5, 0, 2000);
  chassis.turn_to_angle(130);
  scanF(300, -6);
  wait(0.5, sec);
  /*
  earlyexit=false;
  FrontstraightVisionST(700, 165, 12, 0, 5, 0, 2000);
  chassis.drive_distance(6);*/

  //chassis.drive_distance(-20);
  task::stop(colorsortAuto);
  chassis.turn_to_angle(270);
  chassis.drive_distance(-15);
  intake.spin(fwd, 100, pct);
  backClaw.close();
  chassis.turn_to_angle(180);
  chassis.drive_distance(-24);

  /*scanF(300, 6);  //scan right for red ring
  breakout=true;
  breakdistance = 100;
  FrontstraightVisionST(800, 250, 10, 0, 5, 0, 2000);
  //FrontturnVisionST(250, 12, 10, 25, 0, 2000); // lock in doinkerR for red ring
  dRexit=true;
  breakout=false;          // put doinder down when within 4 inch error
  chassis.drive_distance(5.5);

  chassis.drive_distance(-10); //drive backwards slower
  
  dRexit=false; 
  chassis.drive_max_voltage = 12;
  
  chassis.turn_max_voltage = 12;
  
  chassis.turn_min_voltage = 0;
   
  
  
  doinkR.close();  //close doinker
  
  FrontstraightVisionST(1100, 165, 8, 0, 5, 0, 2000); // get both rings
  chassis.drive_distance(6.5);*/ 
  
  wait (30000000000,sec);
}

void RedNegative()
{
  Inertial20.setHeading(146, deg); // 160 inertial, 1500 back distance
  chassis.set_coordinates(0, 0, 146);  //214
  
  greengoalb=true;
  redring = true;
  redringi = true;
  blueringc=true;
  redringc=false;
  greenb = true;
/*
  greengoalb=true;
  bluering = true;
  blueringi = true;
  redringc=true;
  blueringc=false; 
  greenb = true;
  */
  g=0;
  intake.setPosition(0, degrees);
  T2.clear();
  
  earlyexit = false;
  
  lineexit = false;
  AWBB();
  AWB();
  
  

  /*
  breakout=false;
  breakdistance = 10;
  chassis.turn_to_angle(60); 
  scanF(300, 8);
  //FrontturnVisionST(165, 10, 10, 10, 0, 1000);
  breakout=true;
  lBase2.setPosition(0, degrees); 
  breakdistance = 100;
  FrontstraightVisionST(1400, 165, 12, 0, 5, 0, 2000); //1400 is 24inches
  chassis.drive_distance(10);
  lBase2.setPosition(0, degrees); 
  wait(3000000000,sec);
  chassis.drive_max_voltage = 12;
  chassis.drive_min_voltage = 0;
  chassis.heading_max_voltage = 12;
  //chassis.drive_settle_error = 8;
  breakout=true;
  breakdistance = 10;
  chassis.drive_distance(34);
  
    breakout=true; 
    breakdistance = 500; 
  FrontstraightVisionST(4000, 165, 12, 0, 5, 0, 2000); //1400 is 24inches
  chassis.drive_min_voltage = 0;
  chassis.drive_settle_error = 2;
  breakout=false; 
  
  chassis.drive_distance(10);
  wait(300000000000, sec);
  
  */
  
  while(rotationARM.position(degrees)<=150)             // 3rd ring on stake
        {
          ringliftL.spin(fwd, 100, pct);
          ringliftR.spin(fwd, 100, pct);
          printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
        }
        ringliftL.stop(hold);
        ringliftR.stop(hold); 
  wait(300, msec);
  aspeed = 12;
  adesiredValue = 0;
  task t64161474(armPID);
  
  v=0;
  
  task t71621(autoclamp); 
  
  //scanB(300, 6);
  //BackturnVisionST(160, 12, 10, 15, 0, 1000); // lock in to get goal
  breakout=true;
  breakdistance = -100;
  BackstraightVisionST(-1500, 160, 10, 0, 10, 0, 2000); 
  breakout=false;
  chassis.drive_max_voltage = 4;
  chassis.drive_min_voltage = 0;
  chassis.drive_distance(-7); ///get goal slower
  
  backClaw.open(); // close back claw
  //chassis.turn_to_angle(45);
  chassis.drive_max_voltage = 12; 
  //chassis.drive_distance(8); // drive foward to 1st red ring stack 4.1
  scanF(300, -6);  //scan right for red ring
  breakout=true;
  breakdistance = 100;
  FrontstraightVisionST(800, 250, 10, 0, 5, 0, 2000);
  //FrontturnVisionST(250, 12, 10, 25, 0, 2000); // lock in doinkerR for red ring
  dRexit=true;
  breakout=false;          // put doinder down when within 4 inch error
  chassis.drive_distance(6); // drive to 1st ring
  
  
  //doinkR.open();
  
  //wait(200, msec);
  
  chassis.drive_distance(-10); //drive backwards slower
  
  dRexit=false; 
  chassis.drive_max_voltage = 12;
  
  chassis.turn_max_voltage = 12;
  
  chassis.turn_min_voltage = 0;
  
  chassis.turn_to_angle(265); 
  
  
  doinkR.close();  //close doinker
  
  
  intake.spin(reverse,100,pct);
  FrontstraightVisionST(1100, 165, 8, 0, 5, 0, 2000); // get both rings
  chassis.drive_distance(6.5); 

  task t519(colorsortAuto);

  chassis.turn_to_angle(215);

  chassis.drive_max_voltage = 8;
  chassis.drive_distance(36);
  doinkR.open();

  chassis.turn_max_voltage = 6;
  chassis.turn_to_angle(135);
  doinkR.close();
  scanF(300, 6);
  earlyexit=true;
  FrontstraightVisionST(1000, 165, 12, 0, 5, 0, 2000);
  chassis.turn_to_angle(230);
  scanF(300, -6);
  wait(0.5, sec);
  /*
  earlyexit=false;
  FrontstraightVisionST(700, 165, 12, 0, 5, 0, 2000);
  chassis.drive_distance(6);*/

  //chassis.drive_distance(-20);
  task::stop(colorsortAuto);
  chassis.turn_to_angle(90);
  chassis.drive_distance(-15);
  intake.spin(fwd, 100, pct);
  backClaw.close();
  chassis.turn_to_angle(180);
  chassis.drive_distance(-24);

  /*scanF(300, 6);  //scan right for red ring
  breakout=true;
  breakdistance = 100;
  FrontstraightVisionST(800, 250, 10, 0, 5, 0, 2000);
  //FrontturnVisionST(250, 12, 10, 25, 0, 2000); // lock in doinkerR for red ring
  dRexit=true;
  breakout=false;          // put doinder down when within 4 inch error
  chassis.drive_distance(5.5);

  chassis.drive_distance(-10); //drive backwards slower
  
  dRexit=false; 
  chassis.drive_max_voltage = 12;
  
  chassis.turn_max_voltage = 12;
  
  chassis.turn_min_voltage = 0;
   
  
  
  doinkR.close();  //close doinker
  
  FrontstraightVisionST(1100, 165, 8, 0, 5, 0, 2000); // get both rings
  chassis.drive_distance(6.5);*/ 
  
  wait (30000000000,sec);
}

void BluePostive()
{
  Inertial20.setHeading(146, deg); // 160 inertial, 1500 back distance
  chassis.set_coordinates(0, 0, 146);  //214
  /*
  greengoalb=true;
  redring = true;
  redringi = true;
  blueringc=true;
  redringc=false;
  greenb = true;*/

  greengoalb=true;
  bluering = true;
  blueringi = true;
  redringc=true;
  blueringc=false; 
  greenb = true;
  
  g=0;
  intake.setPosition(0, degrees);
  T2.clear();
  
  earlyexit = false;
  
  lineexit = false;
  AWBB();
  AWB();
  
  

  /*
  breakout=false;
  breakdistance = 10;
  chassis.turn_to_angle(60); 
  scanF(300, 8);
  //FrontturnVisionST(165, 10, 10, 10, 0, 1000);
  breakout=true;
  lBase2.setPosition(0, degrees); 
  breakdistance = 100;
  FrontstraightVisionST(1400, 165, 12, 0, 5, 0, 2000); //1400 is 24inches
  chassis.drive_distance(10);
  lBase2.setPosition(0, degrees); 
  wait(3000000000,sec);
  chassis.drive_max_voltage = 12;
  chassis.drive_min_voltage = 0;
  chassis.heading_max_voltage = 12;
  //chassis.drive_settle_error = 8;
  breakout=true;
  breakdistance = 10;
  chassis.drive_distance(34);
  
    breakout=true; 
    breakdistance = 500; 
  FrontstraightVisionST(4000, 165, 12, 0, 5, 0, 2000); //1400 is 24inches
  chassis.drive_min_voltage = 0;
  chassis.drive_settle_error = 2;
  breakout=false; 
  
  chassis.drive_distance(10);
  wait(300000000000, sec);
  
  */
  
  while(rotationARM.position(degrees)<=150)             // 3rd ring on stake
        {
          ringliftL.spin(fwd, 100, pct);
          ringliftR.spin(fwd, 100, pct);
          printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
        }
        ringliftL.stop(hold);
        ringliftR.stop(hold); 
  wait(300, msec);
  aspeed = 12;
  adesiredValue = 0;
  task t64161474(armPID);
  
  v=0;
  
  task t71621(autoclamp); 
  
  //scanB(300, 6);
  //BackturnVisionST(160, 12, 10, 15, 0, 1000); // lock in to get goal
  breakout=true;
  breakdistance = -100;
  BackstraightVisionST(-1500, 160, 10, 0, 10, 0, 2000); 
  breakout=false;
  chassis.drive_max_voltage = 4;
  chassis.drive_min_voltage = 0;
  chassis.drive_distance(-7); ///get goal slower
  
  backClaw.open(); // close back claw
  //chassis.turn_to_angle(45);
  chassis.drive_max_voltage = 12; 
  //chassis.drive_distance(8); // drive foward to 1st red ring stack 4.1
  scanF(300, -6);  //scan right for red ring
  breakout=true;
  breakdistance = 100;
  FrontstraightVisionST(800, 250, 10, 0, 5, 0, 2000);
  //FrontturnVisionST(250, 12, 10, 25, 0, 2000); // lock in doinkerR for red ring
  dRexit=true;
  breakout=false;          // put doinder down when within 4 inch error
  chassis.drive_distance(6); // drive to 1st ring
  
  
  //doinkR.open();
  
  //wait(200, msec);
  
  chassis.drive_distance(-10); //drive backwards slower
  
  dRexit=false; 
  chassis.drive_max_voltage = 12;
  
  chassis.turn_max_voltage = 12;
  
  chassis.turn_min_voltage = 0;
  
  chassis.turn_to_angle(265); 
  
  
  doinkR.close();  //close doinker
  
  
  intake.spin(reverse,100,pct);
  FrontstraightVisionST(1100, 165, 8, 0, 5, 0, 2000); // get both rings
  chassis.drive_distance(6.5); 

  task t519(colorsortAuto);

  chassis.turn_to_angle(215);

  chassis.drive_max_voltage = 8;
  chassis.drive_distance(36);
  doinkR.open();

  chassis.turn_max_voltage = 6;
  chassis.turn_to_angle(135);
  doinkR.close();
  scanF(300, 6);
  earlyexit=true;
  FrontstraightVisionST(1000, 165, 12, 0, 5, 0, 2000);
  chassis.turn_to_angle(230);
  scanF(300, -6);
  wait(0.5, sec);
  /*
  earlyexit=false;
  FrontstraightVisionST(700, 165, 12, 0, 5, 0, 2000);
  chassis.drive_distance(6);*/

  //chassis.drive_distance(-20);
  task::stop(colorsortAuto);
  chassis.turn_to_angle(90);
  chassis.drive_distance(-15);
  intake.spin(fwd, 100, pct);
  backClaw.close();
  chassis.turn_to_angle(180);
  chassis.drive_distance(-24);

  /*scanF(300, 6);  //scan right for red ring
  breakout=true;
  breakdistance = 100;
  FrontstraightVisionST(800, 250, 10, 0, 5, 0, 2000);
  //FrontturnVisionST(250, 12, 10, 25, 0, 2000); // lock in doinkerR for red ring
  dRexit=true;
  breakout=false;          // put doinder down when within 4 inch error
  chassis.drive_distance(5.5);

  chassis.drive_distance(-10); //drive backwards slower
  
  dRexit=false; 
  chassis.drive_max_voltage = 12;
  
  chassis.turn_max_voltage = 12;
  
  chassis.turn_min_voltage = 0;
   
  
  
  doinkR.close();  //close doinker
  
  FrontstraightVisionST(1100, 165, 8, 0, 5, 0, 2000); // get both rings
  chassis.drive_distance(6.5);*/ 
  
  wait (30000000000,sec);
}

void AWPRed()
{
Inertial20.setHeading(214, deg); // 160 inertial, 1500 back distance
chassis.set_coordinates(0, 0, 214);  //214

greengoalb=true;
redring = true;
redringi = true;
blueringc=true;
redringc=false;
greenb = true;

g=0;
intake.setPosition(0, degrees);
T2.clear();

earlyexit = false;

lineexit = false;
AWBB();
AWB();

breakout=false;
//breakdistance = 10;
//chassis.turn_to_angle(60); 
//scanF(300, 8);
//FrontturnVisionST(165, 10, 10, 10, 0, 1000);
//breakout=true;
//lBase2.setPosition(0, degrees); 
//earlyexit= true;
intake.spin(reverse, 100, pct);
FrontstraightVisionST(1500, 165, 8, 0, 5, 0, 2000); //1400 is 24inches
//scanF(300, -8);
//wait(0.5,sec);
//FrontstraightVisionST(2000, 165, 12, 0, 5, 0, 2000); //1400 is 24inches
chassis.drive_distance(4);
lBase2.setPosition(0, degrees); 
wait(3000000000,sec);
chassis.drive_max_voltage = 12;
chassis.drive_min_voltage = 0;
chassis.heading_max_voltage = 12;
//chassis.drive_settle_error = 8;
breakout=true;
breakdistance = 10;
chassis.drive_distance(34);

  breakout=true; 
  breakdistance = 500; 
FrontstraightVisionST(4000, 165, 12, 0, 5, 0, 2000); //1400 is 24inches
chassis.drive_min_voltage = 0;
chassis.drive_settle_error = 2;
breakout=false; 

chassis.drive_distance(10);
wait(300000000000, sec);



while(rotationARM.position(degrees)<=150)             // 3rd ring on stake
      {
        ringliftL.spin(fwd, 100, pct);
        ringliftR.spin(fwd, 100, pct);
        printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
      }
      ringliftL.stop(hold);
      ringliftR.stop(hold); 
wait(300, msec);
aspeed = 12;
adesiredValue = 0;
task t64161474(armPID);

v=0;

task t71621(autoclamp); 

scanB(300, 6);
BackturnVisionST(160, 12, 10, 15, 0, 1000); // lock in to get goal
chassis.drive_max_voltage = 12;
chassis.drive_min_voltage = 10;
chassis.drive_distance(-22); //get goal fast
chassis.drive_max_voltage = 4;
chassis.drive_min_voltage = 0;
chassis.drive_distance(-12); ///get goal slower

backClaw.open(); // close back claw

chassis.drive_max_voltage = 12; 
chassis.drive_distance(8); // drive foward to 1st red ring stack 4.1
scanF(300, 6);  //scan right for red ring
FrontturnVisionST(250, 12, 10, 25, 0, 2000); // lock in doinkerR for red ring
dRexit=true;          // put doinder down when within 4 inch error
chassis.drive_distance(12); // drive to 1st ring

chassis.drive_max_voltage = 12; //slow down for back up

//doinkR.open();

//wait(200, msec);

chassis.drive_distance(-10); //drive backwards slower

dRexit=false; 
chassis.drive_max_voltage = 12;

chassis.turn_max_voltage = 12;

chassis.turn_min_voltage = 3;

chassis.turn_to_angle(70); 

chassis.turn_min_voltage = 0;

chassis.turn_to_angle(74);

doinkR.close();  //close doinker

chassis.turn_max_voltage = 12;

FrontturnVisionST(165, 12, 10, 25, 0, 1500); // lock in to get 1st ring

intake.spin(reverse,100,pct);
chassis.drive_distance(14);  //get ring


intake.spin(reverse, 100, pct);
earlyexit = true;
FrontstraightVisionST(1000, 170, 12, 0, 5, 0, 2000); //go to first ring


//chassis.turn_settle_time = 300; //accuate turn
chassis.turn_max_voltage = 8;
chassis.turn_to_angle(235); //turn to go across field
chassis.turn_max_voltage = 12;

task::stop(autoclamp); 
backClaw.close();            //open claw to drop
intake.spin(fwd, 100, pct);
wait(0.5,sec);
intake.spin(reverse, 100, pct);

chassis.drive_distance(48);  
chassis.turn_to_angle(125);
intake.stop();
task t716241(autoclamp); 
scanB(300, 6);
//BackturnVisionST(165, 12, 10, 10, 100, 1000);
BackturnVisionST(160, 12, 10, 15, 0, 1000); // lock in to get goal
chassis.drive_max_voltage = 12;
chassis.drive_min_voltage = 10;
chassis.drive_distance(-18); //get goal fast
chassis.drive_max_voltage = 4;
chassis.drive_min_voltage = 0;
chassis.drive_distance(-16); ///get goal slower

backClaw.open();

chassis.turn_to_angle(270);
intake.spin(reverse, 100, pct);

scanF(300, 6);
FrontturnVisionST(165, 12, 10, 25, 0, 1500); 
frontdistanceNew(12, 270, 12, 0, 1, 100, 3000); 

aspeed = 12;
adesiredValue = 150;
task t64674(armPID);            //LB for 1st ring
g=0;
L=0;
frontdistanceNew(60, 265, 12, 0, 1, 100, 3000); 

wait(300000000, sec);



frontdistanceNew(5, 49.5, 12, 0, 0.5, 300, 3000); //drive wall stake

intake.stop();

task::stop(armPID); 

T1.clear();
 while(rotationARM.position(degrees)<=150 && T1.value()<1)             // 2nd ring on stake
      {
        ringliftL.spin(fwd, 100, pct);
        ringliftR.spin(fwd, 100, pct);
        printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
      }
      ringliftL.stop(hold);
      ringliftR.stop(hold);


chassis.drive_max_voltage = 12;

chassis.drive_distance(-16); //fast backwards from wall stake

chassis.turn_settle_time = 0;
chassis.turn_to_angle(290); //turn to bar

chassis.drive_distance(29); //run into bar




/*

//$$$$$$$$$$$$$$$$$$$$$$$$$$$$$OLD
task t71621(autoclamp); 

//chassis.turn_to_angle(113);
scanB(300, 6);
BackturnVisionST(165, 12, 10, 5, 100, 1000); // lock in
chassis.drive_max_voltage = 12;
chassis.drive_min_voltage = 10;
chassis.drive_distance(-22);
chassis.drive_max_voltage = 4;
chassis.drive_min_voltage = 0;
chassis.drive_distance(-12); ///get goal

backClaw.open();

chassis.drive_max_voltage = 12;
chassis.drive_distance(4);
//chassis.turn_to_angle(125);
scanF(300, 6);
FrontturnVisionST(255, 12, 10, 5, 100, 2000); // $$$$$$$$measure lock in
chassis.drive_distance(12); // drive to 1st ring

chassis.drive_max_voltage = 6;

doinkR.open();

wait(500, msec);

chassis.drive_distance(-18);

chassis.drive_max_voltage = 12;

chassis.turn_max_voltage = 10;

chassis.turn_to_angle(90);

doinkR.close();

wait(300, msec);

chassis.turn_max_voltage = 12;

// chassis.turn_to_angle(90);

scanF(300, 6);
FrontturnVisionST(170, 12, 10, 5, 100, 1000); // lock in to get ring


// intake.spin(reverse, 100, pct);

// chassis.drive_distance(24);

aspeed = 12;
adesiredValue = 31;
task t64674(armPID);                                  //LB for 2nd ring
g=0;
L=0;
task t61617531(intakeringLB);

chassis.drive_distance(14);  //get ring

//chassis.turn_to_angle(354);

//scanF(300, -6);


T1.clear();                        //wait for 2nd ring
while(L==0 && T1.value()<2)
{

}

task::stop(intakeringLB);
intake.stop();
*/
/*
FrontturnVisionST(55, 10, 10, 5, 100, 1000); // lock in to get ring

chassis.drive_distance(5);

doinkL.open();

wait(400, msec);

chassis.turn_to_angle(120);

doinkL.close();

wait(200, msec);
*/
//chassis.turn_to_angle(335);

//scanF(300, -5);
//(170, 12, 10, 5, 100, 1000); // lock in to get ring

/*
intake.spin(reverse, 100, pct);

//chassis.drive_distance(6);

chassis.turn_to_angle(90);
frontdistanceNew(12, 90, 12, 0, 1, 100, 3000);
frontdistanceNew(19.5, 90, 12, 0, 1, 100, 3000);

chassis.turn_settle_time = 300;
chassis.turn_to_angle(50);

//chassis.drive_distance(24);
frontdistanceNew(4.5, 50, 12, 0, 0.5, 300, 3000);

intake.stop();

task::stop(armPID); 

T1.clear();
 while(rotationARM.position(degrees)<=150 && T1.value()<1)             // 2nd ring on stake
      {
        ringliftL.spin(fwd, 100, pct);
        ringliftR.spin(fwd, 100, pct);
        printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
      }
      ringliftL.stop(hold);
      ringliftR.stop(hold);


chassis.drive_max_voltage = 12;

chassis.drive_distance(-16);

chassis.turn_settle_time = 0;
chassis.turn_to_angle(290);

chassis.drive_distance(29);


wait(300000000000, sec);

*/

}

void RedSafe() {
    Inertial20.setHeading(128, deg); // 160 inertial, 1500 back distance
chassis.set_coordinates(0, 0, 128);  

greengoalb=true;
//redringb = true;
redring = true;
redringi = true;
blueringc=true;

greenb = true;
g=0;
intake.setPosition(0, degrees);
T2.clear();

earlyexit = true;

lineexit = false;
AWBB();
AWB();

while(rotationARM.position(degrees)<=150)             // 3rd ring on stake
      {
        ringliftL.spin(fwd, 100, pct);
        ringliftR.spin(fwd, 100, pct);
        printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
      }
      ringliftL.stop(hold);
      ringliftR.stop(hold); 
wait(300, msec);
aspeed = 12;
adesiredValue = 0;
task t64161474(armPID);


v=0;

task t71621(autoclamp); 

chassis.turn_to_angle(113); //turn to goal
scanB(300, 5);
BackturnVisionST(172, 10, 10, 5, 100, 1000); // lock in
chassis.drive_max_voltage = 10; 
chassis.drive_min_voltage = 8;
chassis.drive_distance(-24); //drive fast for a bit
chassis.drive_max_voltage = 5;
chassis.drive_min_voltage = 0;
chassis.drive_distance(-10); //drive slower for a bit

backClaw.open();
chassis.drive_max_voltage = 10;
chassis.drive_distance(4);
chassis.turn_to_angle(125);
scanF(300, 5);
FrontturnVisionST(185, 10, 10, 5, 100, 1000); // $$$$$$$$measure lock in
chassis.drive_distance(11.5); // drive to 1st ring

chassis.drive_max_voltage = 6;

doinkR.open(); // doinkR down

wait(500, msec);

chassis.drive_distance(-6); // back up a bit

chassis.drive_max_voltage = 12;

chassis.turn_max_voltage = 8;

chassis.turn_to_angle(330);

doinkR.close();    //doinkR up

wait(300, msec);

chassis.turn_max_voltage = 10;

chassis.turn_to_angle(335);  //turn toward ring

scanF(300, 5);
FrontturnVisionST(170, 10, 10, 5, 100, 1000); // lock in to get ring


intake.spin(reverse, 100, pct);

// chassis.drive_distance(24);

chassis.drive_distance(14);  //get 1st ring

chassis.turn_to_angle(335);  //turn to 2nd ring
scanF(300, 5);
//FrontturnVisionST(155, 10, 10, 5, 100, 1000); // $$$$$$measurelock in
FrontturnVisionST(170, 10, 10, 5, 100, 1000);
intake.spin(reverse, 100, pct);

chassis.drive_distance(12);  //get 2nd ring

//chassis.turn_to_angle(337);  //turn toward 2nd ring
/*
chassis.drive_distance(-4);  //back up a bit

//adesiredValue = 70;

chassis.turn_to_angle(354);  //turn to 2nd ring
scanF(300, 5);
FrontturnVisionST(155, 10, 10, 5, 100, 1000); // $$$$$$measurelock in

chassis.drive_distance(5); //go forward a bit

doinkL.open(); //left down

wait(400, msec);

chassis.turn_to_angle(45); //kick off blue ring

doinkL.close(); //left up

wait(200, msec);

chassis.turn_to_angle(335); //turn to get 2nd ring
scanF(300, 5);
FrontturnVisionST(170, 10, 10, 5, 100, 1000); // $$$$$$measurelock in


intake.spin(reverse, 100, pct);

chassis.drive_distance(11);
*/
aspeed = 12;
adesiredValue = 147;
task t64674(armPID);                                  //LB for 2nd ring
g=0;
L=0;

chassis.turn_to_angle(180);

chassis.drive_distance(29, 200);



}

void RedKindaSafe() {
Inertial20.setHeading(128, deg); // 160 inertial, 1500 back distance
chassis.set_coordinates(0, 0, 128);  

greengoalb=true;
//redringb = true;
redring = true;
redringi = true;
blueringc=true;

greenb = true;
g=0;
intake.setPosition(0, degrees);
T2.clear();

earlyexit = true;

lineexit = false;
AWBB();
AWB();

while(rotationARM.position(degrees)<=150)             // 3rd ring on stake
      {
        ringliftL.spin(fwd, 100, pct);
        ringliftR.spin(fwd, 100, pct);
        printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
      }
      ringliftL.stop(hold);
      ringliftR.stop(hold); 
wait(300, msec);
aspeed = 12;
adesiredValue = 0;
task t64161474(armPID);


v=0;

task t71621(autoclamp); 

chassis.turn_to_angle(113);
scanB(300, 5);
BackturnVisionST(172, 10, 10, 5, 100, 1000); // lock in

chassis.drive_max_voltage = 10;
chassis.drive_min_voltage = 8;
chassis.drive_distance(-24);
chassis.drive_max_voltage = 5;
chassis.drive_min_voltage = 0;
chassis.drive_distance(-10);

backClaw.open();
chassis.drive_max_voltage = 10;
chassis.drive_distance(4);
chassis.turn_to_angle(125);
scanF(300, 5);
FrontturnVisionST(185, 10, 10, 5, 100, 1000); // $$$$$$$$measure lock in
chassis.drive_distance(11.5); // drive to 1st ring

chassis.drive_max_voltage = 6;

doinkR.open();

wait(500, msec);

chassis.drive_distance(-6);

chassis.drive_max_voltage = 12;

chassis.turn_max_voltage = 8;

chassis.turn_to_angle(330);

doinkR.close();

wait(300, msec);

chassis.turn_max_voltage = 10;

chassis.turn_to_angle(335);

scanF(300, 5);
FrontturnVisionST(170, 10, 10, 5, 100, 1000); // lock in to get ring


intake.spin(reverse, 100, pct);

// chassis.drive_distance(24);

chassis.drive_distance(14);

chassis.turn_to_angle(335);  //turn to 2nd ring
scanF(300, 5);
//FrontturnVisionST(155, 10, 10, 5, 100, 1000); // $$$$$$measurelock in
FrontturnVisionST(170, 10, 10, 5, 100, 1000);
intake.spin(reverse, 100, pct);

chassis.drive_distance(12);  //get 2nd ring


//chassis.turn_to_angle(337);

//chassis.drive_distance(-4);

//adesiredValue = 70;
/*
chassis.turn_to_angle(354);
chassis.drive_distance(5);

doinkL.open();

wait(400, msec);

chassis.turn_to_angle(45);

doinkL.close();

wait(200, msec);

chassis.turn_to_angle(335);

chassis.drive_distance(11); // gets stack bottom ring
*/

chassis.turn_to_angle(205);

chassis.drive_distance(20, 214);

scanF(300, 5);
//FrontturnVisionST(155, 10, 10, 5, 100, 1000); // $$$$$$measurelock in
FrontturnVisionST(185, 10, 10, 5, 100, 1000);

chassis.drive_distance(12);

doinkR.open();

wait(300, msec);

chassis.drive_distance(-24);

//chassis.turn_to_angle(205);


doinkR.close();

wait(100, msec);

chassis.turn_to_angle(210);
scanF(300, 5);
//FrontturnVisionST(155, 10, 10, 5, 100, 1000); // $$$$$$measurelock in
FrontturnVisionST(170, 10, 10, 5, 100, 1000);

chassis.drive_distance(15);

aspeed = 12;
adesiredValue = 147;
task t64674(armPID);                                  //LB for 2nd ring
g=0;
L=0;





}


void AWPBlue()
{
Inertial20.setHeading(147, deg); //100
chassis.set_coordinates(147, 0, 100);  


greengoalb=true;
//redringb = true;
bluering = true;
redringi = true;
redringc=true;

greenb = true;

  g=0;
  intake.setPosition(0, degrees);
  T2.clear();
  
  earlyexit = false;
  
  lineexit = false;
  AWBB();
  AWB();
  
  
  
  while(rotationARM.position(degrees)<=150)             // 3rd ring on stake
        {
          ringliftL.spin(fwd, 100, pct);
          ringliftR.spin(fwd, 100, pct);
          printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
        }
        ringliftL.stop(hold);
        ringliftR.stop(hold); 
  wait(300, msec);
  aspeed = 12;
  adesiredValue = 0;
  task t64161474(armPID);
  
  v=0;
  
  task t71621(autoclamp); 
  
  //scanB(300, 6);
  //BackturnVisionST(160, 12, 10, 15, 0, 1000); // lock in to get goal
  breakout=true;
  breakdistance = -100;
  BackstraightVisionST(-1500, 160, 10, 0, 10, 0, 2000); 
  breakout=false;
  chassis.drive_max_voltage = 4;
  chassis.drive_min_voltage = 0;
  chassis.drive_distance(-12); ///get goal slower
  
  backClaw.open(); // close back claw
  
  chassis.drive_max_voltage = 12; 
  //chassis.drive_distance(8); // drive foward to 1st red ring stack 4.1
  scanF(300, 6);  //scan right for red ring
  breakout=true;
  breakdistance = 100;
  FrontstraightVisionST(800, 250, 10, 0, 5, 0, 2000);
  //FrontturnVisionST(250, 12, 10, 25, 0, 2000); // lock in doinkerR for red ring
  dRexit=true;
  breakout=false;          // put doinder down when within 4 inch error
  chassis.drive_distance(5.5); // drive to 1st ring
  
  
  //doinkR.open();
  
  //wait(200, msec);
  
  chassis.drive_distance(-10); //drive backwards with ring
  
  dRexit=false; 
  chassis.drive_max_voltage = 12;
  
  chassis.turn_max_voltage = 12;
  
  chassis.turn_min_voltage = 0;
  
  chassis.turn_to_angle(275); 
  
  
  doinkR.close();  //close doinker
  
  
  intake.spin(reverse,100,pct);
  FrontstraightVisionST(1100, 165, 8, 0, 5, 0, 2000); // get both rings
  chassis.drive_distance(6.5); 

  
  //chassis.turn_settle_time = 300; //accurate turn
  chassis.turn_max_voltage = 8;
  chassis.turn_to_angle(125); //turn to go across field
  chassis.turn_max_voltage = 12;
  
  task::stop(autoclamp); 
  backClaw.close();            //open claw to drop
  intake.spin(fwd, 100, pct);
  wait(0.5,sec);
  intake.spin(reverse, 100, pct);
  
  chassis.drive_distance(48);  
  chassis.turn_to_angle(230);
  intake.stop();
  task t716241(autoclamp); 
  scanB(350, 6);
  breakout=true;
  breakdistance = -100;
  BackstraightVisionST(-1400, 160, 12, 0, 5, 0, 2000); 
  breakout=false;
  chassis.drive_max_voltage = 4;
  chassis.drive_min_voltage = 0;
  chassis.drive_distance(-12); ///get goal slower
  
  backClaw.open();
  
  chassis.turn_to_angle(90);
  intake.spin(reverse, 100, pct);
  chassis.drive_max_voltage = 12;
  scanF(300, 6);
  earlyexit=true;
  breakout=false;
  FrontstraightVisionST(1200, 250, 12, 0, 5, 0, 2000);
  chassis.drive_distance(6);
  //frontdistanceNew(12, 270, 12, 0, 1, 100, 3000); 
  
  aspeed = 12;
  adesiredValue = 150;
  task t64674(armPID);            //LB for 1st ring
  g=0;
  L=0;
  frontdistanceNew(60, 100, 12, 0, 1, 100, 3000); 
  
  wait(300000000, sec);
}






void BlueSafe()
{


    Inertial20.setHeading(0, deg); // 300 inertial, 1500 back distance
chassis.set_coordinates(0, 0, 0);  // 232

greengoalb=true;
//redringb = true;
redring = true;
redringi = true;
blueringc=true;

greenb = true;
g=0;
intake.setPosition(0, degrees);
T2.clear();

earlyexit = true;

lineexit = false;
AWBB();
AWB();



while(rotationARM.position(degrees)<=150)             // 3rd ring on stake
      {
        ringliftL.spin(fwd, 100, pct);
        ringliftR.spin(fwd, 100, pct);
        printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
      }
      ringliftL.stop(hold);
      ringliftR.stop(hold); 
wait(300, msec);
aspeed = 12;
adesiredValue = 0;
task t64161474(armPID);


 //wait(0.5, sec);
// task t108(autoclamp);

//test$$$$$$$$$$$$$$$$$$$$$$$
//FrontYVisionST(200, 220, 8, 0, 5, 0, 3000); //new
  
//wait(300000000000, sec);
//scanB(500, 5); 
v=0;

task t71621(autoclamp); 

chassis.turn_to_angle(293); //247

scanB(300, 5);
BackturnVisionST(172, 10, 10, 5, 100, 1000); // lock in

chassis.drive_max_voltage = 10;
chassis.drive_min_voltage = 8;
chassis.drive_distance(-24);
chassis.drive_max_voltage = 5;
chassis.drive_min_voltage = 0;
chassis.drive_distance(-10);

backClaw.open();
chassis.drive_max_voltage = 10;
chassis.drive_distance(4);
chassis.turn_to_angle(-14.5);
scanF(300, 5);
FrontturnVisionST(155, 10, 10, 5, 100, 1000); // $$$$$$$$measure lock in
chassis.drive_distance(12);

chassis.drive_max_voltage = 6;

doinkL.open();

wait(500, msec);

chassis.drive_distance(-6);

chassis.drive_max_voltage = 12;

chassis.turn_max_voltage = 8;

chassis.turn_to_angle(160);

doinkL.close();

wait(300, msec);

chassis.turn_max_voltage = 10;

chassis.turn_to_angle(155);

scanF(300, 5);
FrontturnVisionST(170, 10, 10, 5, 100, 1000); // lock in to get ring


intake.spin(reverse, 100, pct);

// chassis.drive_distance(24);

chassis.drive_distance(14);

chassis.turn_to_angle(165);
scanF(300, 5);
//FrontturnVisionST(155, 10, 10, 5, 100, 1000); // $$$$$$measurelock in
FrontturnVisionST(170, 10, 10, 5, 100, 1000);

chassis.drive_distance(15);
/*
chassis.drive_distance(-4);

//adesiredValue = 70;

chassis.turn_to_angle(183);
chassis.drive_distance(6);

doinkL.open();

wait(400, msec);

chassis.turn_to_angle(225);

doinkL.close();

wait(200, msec);

chassis.turn_to_angle(165);

intake.spin(reverse, 100, pct);

chassis.drive_distance(13);
*/
aspeed = 12;
adesiredValue = 147;
task t64674(armPID);                                  //LB for 2nd ring
g=0;
L=0;

chassis.turn_to_angle(0);

chassis.drive_distance(29, 20);



}


void RedRush()
{

  Inertial20.setHeading(32, deg); // 160 inertial, 1500 back distance
  chassis.set_coordinates(0, 0, 32);  

  greengoalb=true;
  bluering = false;
  redring = true;
  redringi = true;
  blueringc=true;
  redringc=false;
  greenb = true;

  g=0;
  intake.setPosition(0, degrees);
  ringliftL.setPosition(0, degrees);
  backClaw.open();
  lbp2.close();
  T2.clear();

  earlyexit = false;

  lineexit = false;
  AWBB();
  AWB();
  AWBI();


  

  aspeed = 12;
  adesiredValue = 110;
  task t64561474(armPID);               //lift arm

  wait(300, msec);

  intake.spin(reverse, 100, pct);       //put ring in intake
  wait(0.3, sec); //.25
  

  //L=1;
  intake.spin(fwd, 80, pct);           //let ring go
  wait(.15, sec);
  intake.stop(coast); 
  
  aspeed = 6;                          //lift arm a bit
  adesiredValue = 170;
  wait(0.1, sec);
  lbp2.open();                         //close piston
  intake.stop();
  task::stop(armPID);

  while(ringliftL.position(degrees)<=600)      //put ring on stack
  {
    ringliftL.spin(fwd, 100, pct);
    ringliftR.spin(fwd, 100, pct);
    printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
  }
  ringliftL.stop(hold);
  ringliftR.stop(hold); 
  AWBI();                                     //auto white balance
  wait(300, msec);
  

  chassis.drive_distance(-10); 

  aspeed = 12;
  adesiredValue = 0;
  task t64161474(armPID);


  chassis.turn_to_angle(70);
  scanB(300, -6);
  doinkL.open();
  
  BackstraightVisionST(-1100, 160, 11, 2, 5, 0, 2000);    //get goal
  chassis.drive_max_voltage=11;
  chassis.drive_distance(-10);
  doinkL.close();
  
  task t61010(colorsortAuto);
  backClaw.close();
  lbp2.close();
  wait(300, msec);


  chassis.turn_to_angle(270);
  backdistanceNew(55, 270, 10, 8, 1, 0, 2000); 
  chassis.turn_to_angle(180);
  frontdistanceNew(12, 180, 7, 6, 1, 0, 2000); 
  frontdistanceNew(24, 180, 10, 8, 1, 0, 2000); 
  chassis.turn_to_angle(110);

  
  earlyexit = true;
  ee=2;
  FrontstraightVisionST(950, 165, 10, 8, 5, 0, 3000); 
  //FrontdistanceVisionST(1, 165, 10, 0, 1, 0, 3000);   //$$$$$$$$1st ring
  //doinkR.open();                                      //right doinker down
  earlyexit = false; 
  //waitforring = true;                                 //wait for ring to come in
  //chassis.drive_distance(4);                          //a bit further
  //waitforring = false;
  chassis.turn_to_angle(260);                         //turn left
  
  backdistanceNew(24, 260, 10, 8, 1, 0, 2000);        //back up to wall
  task::stop(colorsortAuto);
  intake.spin(fwd, 100, pct);                         //reverse intake
  chassis.turn_to_angle(140);                          //turn to face corner ring stack
  doinkR.close();                                     //right doinker up
  scanF(300, 5);
 
  
  task t610910(colorsortAuto);                        //start colorsort
  earlyexit = true;                                   
  chassis.drive_timeout = 1200;
  ee = 4;                                             //this changes distance for early exit                     
  FrontstraightVisionST(1400, 165, 7, 5, 5, 0, 3000); //go towards red rings in stack
  waitforring = true;                                 //wait for the ring to come in while moving backwards
  chassis.drive_max_voltage = 7;
  chassis.drive_distance(-14);
  waitforring = false;

  ee = 2;
  FrontstraightVisionST(1400, 165, 7, 5, 5, 0, 2000); 
  waitforring = true;
  
  chassis.drive_distance(-14);
  waitforring = false;
  
  FrontstraightVisionST(1400, 165, 7, 5, 5, 0, 2000); 
  waitforring = true;
  
  chassis.drive_distance(-14);
  waitforring = false;

  FrontstraightVisionST(1400, 165, 7, 5, 5, 0, 2000); 
  waitforring = true;
  
  chassis.drive_distance(-14);
  waitforring = false;

  earlyexit = false;                                                 // colorsort on to go to wall stake
 
  chassis.drive_max_voltage = 12;
  frontdistanceNew(30, 135, 10, 8, 1, 0, 2000);                         //back up a bit
  chassis.turn_to_angle(315);                            //turn to go to ladder

  aspeed = 12;                                           // arm up to contact ladder
  adesiredValue = 500;
  task t645474(armPID);

  //backdistanceNew(30, 315, 12, 0, 1, 0, 2000); 
  chassis.drive_distance(24, 315);














  odom_constants();
  default_constants();
  lBase2.setPosition(0, degrees);
rBase2.setPosition(0, degrees);
lBase1.setPosition(0, degrees);
rBase1.setPosition(0, degrees);
lBase3.setPosition(0, degrees);
rBase3.setPosition(0, degrees);
rotations.setPosition(0, degrees);
backClaw.close();
lbp.close();
doinkR.close();
doinkL.close();
g=0;

//Inertial20.setHeading(180, deg);
//chassis.set_coordinates(0, 0, 180);
greengoalb=true;
greenb = true;
bluering = true;
redringc = true;

chassis.drive_distance(24);
chassis.drive_distance(12, 315);
doinkR.open();
BackdistanceVisionST(85, 150, 7, 5, 5, 0, 2000);
z = Inertial20.heading();
driveStraightInertialST(-700, z, 8, 0, 4, 100, 2000);


 //wait(0.5, sec);
 task t108(autoclamp);
 
 BackdistanceVisionST(85, 150, 7, 5, 5, 0, 2000);
 task::stop(armPID);
z = Inertial20.heading();
driveStraightInertialST(-700, z, 8, 0, 4, 100, 2000);

 chassis.turn_to_angle(185);
 
 task t518(colorsortAuto);
 intake.spin(reverse, 100, pct);
 FrontstraightVisionST(200, 175, 7, 4, 5, 0, 3000);
 z = Inertial20.heading();
 driveStraightInertialST(1000, z, 8, 5, 3, 0, 3000);

 chassis.turn_to_angle(230);

 chassis.drive_min_voltage = 5;

 chassis.drive_timeout = 1000;

 chassis.drive_distance(20);

 doinkR.open();

 chassis.drive_min_voltage = 5;

 chassis.drive_distance(20, 260);

 chassis.turn_max_voltage = 5;

 chassis.turn_to_angle(335);

 doinkR.close();

 chassis.drive_max_voltage = 5;

 //chassis.drive_distance(5);

 kMI = 1.6;
 lBase2.setPosition(0, deg);
 driveStraightInertialST(2450, 340, 5, 0, 5, 0, 3000);

 kMI = 0.4;

 chassis.drive_max_voltage = 12;

 chassis.turn_max_voltage = 12;

 chassis.turn_to_angle(55);

 chassis.drive_distance(6);

 doinkR.open();

 chassis.turn_max_voltage = 5;

 chassis.turn_to_angle(125);

 doinkR.close();

 chassis.turn_to_angle(90);

 chassis.drive_distance(22, 45);

task::stop(colorsortAuto);
intake.stop();



}


void SoloAWPRed() {

  Inertial20.setHeading(150, deg); // 160 inertial, 1500 back distance
  chassis.set_coordinates(0, 0, 150);  

  greengoalb=true;
  redring = true;
  redringi = true;
  blueringc=true;
  redringc=false;
  greenb = true;

  g=0;
  intake.setPosition(0, degrees);
  ringliftL.setPosition(0, degrees);
  backClaw.open();
  lbp2.close();
  T2.clear();

  earlyexit = true;

  lineexit = false;
  AWBB();
  AWB();
  AWBI();

 
 
 
  aspeed = 12;                      //get ring on alliance stake
  adesiredValue = 110;
  task t645474(armPID);

  wait(300, msec);

  intake.spin(reverse, 100, pct); 
  wait(0.3, sec); //.25
  

  //L=1;
  intake.spin(fwd, 80, pct); 
  wait(.15, sec);
  intake.stop(coast); 
  
  aspeed = 6;
  adesiredValue = 170;
  wait(0.1, sec);
  lbp2.open();
  intake.stop();
  task::stop(armPID);                      

  while(ringliftL.position(degrees)<=600)             // ring on stake
  {
    ringliftL.spin(fwd, 100, pct);
    ringliftR.spin(fwd, 100, pct);
    printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
  }
  ringliftL.stop(hold);
  ringliftR.stop(hold); 
  AWBI();
  //wait(300, msec);
  


  chassis.drive_distance(-10);

  aspeed = 12;
  adesiredValue = 0;
  task t64474(armPID);

  chassis.turn_to_angle(110);
  scanB(300, -6);

  BackstraightVisionST(-1250, 160, 11, 6, 5, 0, 2000);    //get goal
  chassis.drive_max_voltage=11;
  chassis.drive_distance(-6);
  task t6110(colorsortAuto);
  backClaw.close();
  lbp2.close();
  wait(300, msec);


  chassis.turn_to_angle(0);

  breakdistance = 350;
  breakout = true;
  FrontstraightVisionST(750, 165, 7, 5, 5, 0, 2000); //$$$$$$$1string
  breakout = false;
  earlyexit = true;
  ee=2;
  FrontstraightVisionST(950, 165, 10, 8, 5, 0, 3000); 
  //FrontdistanceVisionST(1, 165, 10, 0, 1, 0, 2000);   //$$$$$$$$1st ring
  //doinkR.open();                                      //right doinker down
  earlyexit = false; 
  //waitforring = true;                                 //wait for ring to come in
  //chassis.drive_distance(4);                          //a bit further
  //allMtrsStop();
  //waitforring = false;
  chassis.turn_max_voltage=7;
  chassis.turn_to_angle(280);                         //turn left
      
  backdistanceNew(24, 280, 10, 8, 1, 0, 2000);        //back up to wall
  task::stop(colorsortAuto);
  intake.spin(fwd, 100, pct);
  chassis.turn_max_voltage=11;
  chassis.turn_to_angle(40);                          //turn to face corner ring stack
  task t61910(colorsortAuto);
  doinkR.close();                                     //right doinker up
  scanF(300, 5);

  earlyexit = true;
  chassis.drive_timeout = 1000;
  ee = 5;
  FrontstraightVisionST(1400, 165, 7, 5, 5, 0, 2000);  //get ring
  waitforring = true;
  chassis.drive_max_voltage = 5;
  chassis.drive_distance(-12);                        //back up to get ring
  waitforring = false;

  chassis.turn_max_voltage=7;
  chassis.turn_to_angle(358);                          //turn to angle slightly left of 0

  frontdistanceNew(30, 358, 10, 8, 1, 0, 2000); 

  doinkL.open();                                        //left doinker down to turn left
  lbp.open(); 
  
  task::stop(colorsortAuto);
  task t6101000(intakering2);
  chassis.turn_max_voltage=11;
  chassis.turn_to_angle(181);                           //turn left and clear any rings in front of you
  backClaw.open(); 
  doinkL.close();                                       //left doinker up

  
  ee = 3.5;
  earlyexit = true;
  FrontstraightVisionST(1200, 165, 10, 0, 5, 0, 3000);
  //FrontdistanceVisionST(3.5, 165, 10, 0, 1, 0, 2000);      //$$4th ring on stack
  allMtrsStop();

chassis.turn_to_angle(45);
scanB(300, 6);
BackstraightVisionST(-1000, 160, 11, 6, 5, 0, 2000);   //get goal
  chassis.drive_max_voltage=11;
  chassis.drive_distance(-8);
  backClaw.close();
  wait(300, msec);
  T1.clear();                        //wait for 2nd LB ring to go into LB
while(L==0 && T1.value()<2)  
{

}
task::stop(intakering2); 
task t6107170(colorsortAuto);
adesiredValue = 500;
chassis.turn_to_angle(315);
chassis.drive_distance(3);

wait(1000000, sec);







  chassis.turn_max_voltage = 12;
  task::stop(autoclamp);
  backClaw.open();

  //chassis.drive_distance(13);
  doinkR.open();
  chassis.turn_to_angle(180);
  doinkR.close();
  
  
  



  chassis.drive_distance(24);
  lbp.open();
  

  FrontdistanceVisionST(3.5, 160, 7, 0, 1, 0, 3000);
  allMtrsStop();
  T1.clear();                        //wait for 2nd LB ring to go into LB
while(L==0 && T1.value()<2)  
{

}
task::stop(intakering2);
goalexit=true;
task t971621(autoclamp); 
chassis.turn_to_angle(45);
scanB(300, 6);
BackstraightVisionST(-1900, 160, 5, 3, 5, 0, 2000); 
task t610170(colorsortAuto);
chassis.turn_to_angle(315);
adesiredValue = 500;


  wait(1000000, sec);

  chassis.turn_to_angle(110);

  scanF(300, 5);
  FrontturnVisionST(155, 10, 10, 5, 100, 2000); // lock into first ring

  intake.spin(reverse, 100, pct);

  chassis.drive_max_voltage = 12;

  chassis.drive_distance(13);

  chassis.drive_distance(-1);

  chassis.turn_to_angle(245); // turn in general direction of second ring

  chassis.drive_distance(20);

  scanF(300, -5);
  FrontturnVisionST(155, 10, 10, 5, 100, 1000); // lock into second ring, need to find offset of angle

  intake.stop();

  chassis.drive_distance(3);

  doinkR.open(); //get second ring in doinker

  chassis.turn_max_voltage = 4;
  chassis.turn_min_voltage = 2;

  chassis.turn_to_angle(285); // get ring off stack

  chassis.turn_max_voltage = 12;
  chassis.turn_min_voltage = 0;

  chassis.turn_to_angle(60); //turn backwards into stack

  chassis.drive_distance(-22); //drive to wall area

  doinkR.close();

  chassis.turn_to_angle(108); //turn to pick up ring

  intake.spin(reverse,100, pct);

  chassis.drive_distance(5); //grab ring

  chassis.drive_distance(-6);

  chassis.turn_to_angle(340);

  chassis.drive_max_voltage = 4;

  chassis.drive_distance(6); //push other bot off line

  backClaw.close(); //drop first goal

  intake.spin(fwd, 100, pct);

  chassis.drive_max_voltage = 12;

  chassis.drive_distance(-4);

  chassis.turn_to_angle(270); //start getting around pushed robot

  chassis.drive_distance(10);

  chassis.turn_to_angle(0); 

  chassis.drive_distance(14);

  scanF(300, -5);
  FrontturnVisionST(155, 10, 10, 5, 100, 1000); // lock into third ring

  task t198981(intakering2);

  chassis.drive_distance(4);

  T2.clear();

  while(L==0 && T2 < 2) {

  }

  chassis.turn_to_angle(270);

  task t71821(autoclamp); 

  scanB(300, 6);
  BackturnVisionST(165, 12, 10, 5, 100, 1000); // lock in to get 2nd goal
  chassis.drive_max_voltage = 12;
  chassis.drive_min_voltage = 10;
  chassis.drive_distance(-22); //get goal fast
  chassis.drive_max_voltage = 4;
  chassis.drive_min_voltage = 0;
  chassis.drive_distance(-12); ///get goal slower

  backClaw.open(); // close back claw

  intake.spin(reverse, 100, pct); //flip ring from intake onto goal

  while(rotationARM.position(degrees)<=150)             // 3rd ring on stake
      {
        ringliftL.spin(fwd, 100, pct);
        ringliftR.spin(fwd, 100, pct);
        printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
      }
      ringliftL.stop(hold);
      ringliftR.stop(hold); 

  chassis.drive_distance(-20, 225); //go touch bar






}

void SoloAWPBlue() {

  Inertial20.setHeading(150, deg); // 160 inertial, 1500 back distance
  chassis.set_coordinates(0, 0, 150);  
  greengoalb=true;
  bluering = true;
  redring = false;
  redringi = false;
  blueringc= false;
  redringc= true;
  greenb = true;
  /*
  greengoalb=true;
  redring = true;
  redringi = true;
  blueringc=true;
  redringc=false;
  greenb = true;*/

  g=0;
  intake.setPosition(0, degrees);
  ringliftL.setPosition(0, degrees);
  backClaw.open();
  lbp2.close();
  T2.clear();

  earlyexit = true;

  lineexit = false;
  AWBB();
  AWB();
  AWBI();

 
 
 
  aspeed = 12;                      //get ring on alliance stake
  adesiredValue = 110;
  task t645474(armPID);

  wait(300, msec);

  intake.spin(reverse, 100, pct); 
  wait(0.3, sec); //.25
  

  //L=1;
  intake.spin(fwd, 80, pct); 
  wait(.15, sec);
  intake.stop(coast); 
  
  aspeed = 6;
  adesiredValue = 170;
  wait(0.1, sec);
  lbp2.open();
  intake.stop();
  task::stop(armPID);                      

  while(ringliftL.position(degrees)<=600)             // ring on stake
  {
    ringliftL.spin(fwd, 100, pct);
    ringliftR.spin(fwd, 100, pct);
    printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
  }
  ringliftL.stop(hold);
  ringliftR.stop(hold); 
  AWBI();
  //wait(300, msec);
  


  chassis.drive_distance(-10);

  aspeed = 12;
  adesiredValue = 0;
  task t64474(armPID);

  chassis.turn_to_angle(110);
  scanB(300, -6);

  BackstraightVisionST(-1250, 160, 11, 6, 5, 0, 2000);    //get goal
  chassis.drive_max_voltage=11;
  chassis.drive_distance(-6);
  task t6110(colorsortAuto);
  backClaw.close();
  lbp2.close();
  wait(300, msec);


  chassis.turn_to_angle(0);

  breakdistance = 350;
  breakout = true;
  FrontstraightVisionST(750, 165, 7, 5, 5, 0, 2000); //$$$$$$$1string
  breakout = false;
  earlyexit = true;
  ee=2;
  FrontstraightVisionST(950, 165, 10, 8, 5, 0, 3000); 
  //FrontdistanceVisionST(1, 165, 10, 0, 1, 0, 2000);   //$$$$$$$$1st ring
  //doinkR.open();                                      //right doinker down
  earlyexit = false; 
  //waitforring = true;                                 //wait for ring to come in
  //chassis.drive_distance(4);                          //a bit further
  //allMtrsStop();
  //waitforring = false;
  chassis.turn_max_voltage=7;
  chassis.turn_to_angle(280);                         //turn left
      
  backdistanceNew(24, 280, 10, 8, 1, 0, 2000);        //back up to wall
  task::stop(colorsortAuto);
  intake.spin(fwd, 100, pct);
  chassis.turn_max_voltage=11;
  chassis.turn_to_angle(40);                          //turn to face corner ring stack
  task t61910(colorsortAuto);
  doinkR.close();                                     //right doinker up
  scanF(300, 5);

  earlyexit = true;
  chassis.drive_timeout = 1000;
  ee = 5;
  FrontstraightVisionST(1400, 165, 7, 5, 5, 0, 2000);  //get ring
  waitforring = true;
  chassis.drive_max_voltage = 5;
  chassis.drive_distance(-12);                        //back up to get ring
  waitforring = false;

  chassis.turn_max_voltage=7;
  chassis.turn_to_angle(358);                          //turn to angle slightly left of 0

  frontdistanceNew(30, 358, 10, 8, 1, 0, 2000); 

  doinkL.open();                                        //left doinker down to turn left
  lbp.open(); 
  
  task::stop(colorsortAuto);
  task t6101000(intakering2);
  chassis.turn_max_voltage=11;
  chassis.turn_to_angle(181);                           //turn left and clear any rings in front of you
  backClaw.open(); 
  doinkL.close();                                       //left doinker up

  
  ee = 3.5;
  earlyexit = true;
  FrontstraightVisionST(1200, 165, 10, 0, 5, 0, 3000);
  //FrontdistanceVisionST(3.5, 165, 10, 0, 1, 0, 2000);      //$$4th ring on stack
  allMtrsStop();

chassis.turn_to_angle(45);
scanB(300, 6);
BackstraightVisionST(-1000, 160, 11, 6, 5, 0, 2000);   //get goal
  chassis.drive_max_voltage=11;
  chassis.drive_distance(-6);
  backClaw.close();
  wait(300, msec);
  T1.clear();                        //wait for 2nd LB ring to go into LB
while(L==0 && T1.value()<2)  
{

}
task::stop(intakering2); 
task t6107170(colorsortAuto);
adesiredValue = 500;
chassis.turn_to_angle(315);
chassis.drive_distance(3);

wait(1000000, sec);
}

void RedPostive()
{

  Inertial20.setHeading(150, deg); // 160 inertial, 1500 back distance
  chassis.set_coordinates(0, 0, 150);  

  greengoalb=true;
  bluering = false;
  redring = true;
  redringi = true;
  blueringc=true;
  redringc=false;
  greenb = true;

  g=0;
  intake.setPosition(0, degrees);
  ringliftL.setPosition(0, degrees);
  backClaw.open();
  lbp2.close();
  T2.clear();

  earlyexit = false;

  lineexit = false;
  AWBB();
  AWB();
  AWBI();


  

  aspeed = 12;
  adesiredValue = 110;
  task t64561474(armPID);               //lift arm

  wait(300, msec);

  intake.spin(reverse, 100, pct);       //put ring in intake
  wait(0.3, sec); //.25
  

  //L=1;
  intake.spin(fwd, 80, pct);           //let ring go
  wait(.15, sec);
  intake.stop(coast); 
  
  aspeed = 6;                          //lift arm a bit
  adesiredValue = 170;
  wait(0.1, sec);
  lbp2.open();                         //close piston
  intake.stop();
  task::stop(armPID);

  while(ringliftL.position(degrees)<=600)      //put ring on stack
  {
    ringliftL.spin(fwd, 100, pct);
    ringliftR.spin(fwd, 100, pct);
    printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
  }
  ringliftL.stop(hold);
  ringliftR.stop(hold); 
  AWBI();                                     //auto white balance
  wait(300, msec);
  

  chassis.drive_distance(-10); 

  aspeed = 12;
  adesiredValue = 0;
  task t64161474(armPID);


  chassis.turn_to_angle(110);
  scanB(300, -6);
  doinkL.open();
  
  BackstraightVisionST(-1100, 160, 11, 2, 5, 0, 2000);    //get goal
  chassis.drive_max_voltage=11;
  chassis.drive_distance(-6);
  doinkL.close();


  task t61010(colorsortAuto);
  backClaw.close();
  lbp2.close();
  wait(300, msec);


  chassis.turn_to_angle(0);

  breakdistance = 350;
  breakout = true;
  FrontstraightVisionST(950, 165, 7, 5, 5, 0, 3000); //$$$$$$$1string
  breakout = false;
  earlyexit = true;
  ee = 2;
  FrontstraightVisionST(950, 165, 10, 8, 5, 0, 3000); 
  //FrontdistanceVisionST(1, 165, 10, 0, 1, 0, 3000);   //$$$$$$$$1st ring
  //doinkR.open();                                      //right doinker down
  earlyexit = false; 
  //waitforring = true;                                 //wait for ring to come in
  //chassis.drive_distance(4);                          //a bit further
  //waitforring = false;
  chassis.turn_to_angle(280);                         //turn left
  backdistanceNew(24, 280, 10, 8, 1, 0, 2000);        //back up to wall
  task::stop(colorsortAuto); 
  intake.spin(fwd, 100, pct);                         //reverse intake
  chassis.turn_to_angle(40);                          //turn to face corner ring stack
  doinkR.close();                                     //right doinker up
  scanF(300, 5);
 
  
  aspeed = 12;
  adesiredValue = 110;
  task t67694(armPID);      //LB ring
  g=0;
  L=0;
  task t606101(intakeringLB);
  
  earlyexit = true;
  chassis.drive_timeout = 1000;
  ee = 4;
  FrontstraightVisionST(1400, 165, 7, 5, 5, 0, 3000);  //get ring
  waitforring = true;
  chassis.drive_max_voltage = 5;
  chassis.drive_distance(-12);                        //back up to get ring
  waitforring = false;
  T1.clear();                                         //wait for LB ring
  while(L==0 && T1.value()<3)  
  {
  
  }
  task::stop(intakeringLB);                           
  adesiredValue = 400;                                //arm up high
  task t70610(colorsortAuto);                         // colorsort on to go to wall stake
 
  chassis.turn_to_angle(90);                          // go to wall stake
  frontdistanceNew(50, 90, 8, 0, 0.5, 100, 2000); 
  doinkL.open();
  chassis.turn_to_angle(0);
  frontdistanceNew(18, 0, 8, 0, 0.5, 100, 2000); 


  chassis.turn_max_voltage = 10;
  task::stop(autoclamp);
  backClaw.open();
  chassis.drive_timeout = 2000;
  chassis.turn_settle_time = 100;
  chassis.turn_to_angle(316);
  doinkL.close();
  chassis.drive_max_voltage = 4;
  chassis.drive_distance(16);




wait(3000000000, sec);





  //frontdistanceNew(24, 0, 12, 0, 1, 0, 2000);

  chassis.turn_to_angle(60);
  //task t619010(colorsortAuto);
  chassis.drive_distance(16);
  redring = true;
  bluering = false;
  //allMtrsStop();
  //wait(1, sec);

  
  breakdistance = 350;
  breakout = true;
  FrontstraightVisionST(1350, 165, 8, 6, 5, 0, 3000); //$$$$$$$1string
  breakout = false;
  //allMtrsStop();
  //wait(1, sec);

  task::stop(colorsortAuto); 

aspeed = 12;
adesiredValue = 110;
task t64794(armPID);      //1st LB ring
g=0;
L=0;
task t6101(intakeringLB);
  //waitforring = true;
  //FrontdistanceVisionST(6, 165, 12, 8, 1, 0, 3000);
  //waitforring = false;
  //allMtrsStop();
  //wait(1, sec);
  chassis.turn_max_voltage = 8;
  chassis.drive_timeout = 700;
  chassis.drive_distance(20, 40);
  
  //chassis.drive_timeout = 2000;
  chassis.drive_timeout = 500;
  chassis.drive_distance(-10, 40);
  T1.clear();                        //wait for 2nd LB ring
  while(L==0 && T1.value()<3)  
  {
  
  }
  
  /*
  task t617010(colorsortAuto);
  chassis.drive_timeout = 600;
  chassis.drive_distance(16,45);
  chassis.drive_timeout = 400;
  chassis.drive_distance(-16);
  chassis.drive_timeout = 600;
  chassis.drive_distance(16,45);
  chassis.drive_timeout = 400;
  chassis.drive_distance(-16);
  chassis.drive_timeout = 600;
  chassis.drive_distance(16,45);
  chassis.drive_timeout = 400;
  chassis.drive_distance(-16);
  chassis.turn_max_voltage = 5;
*/
  chassis.turn_to_angle(90);
  frontdistanceNew(50, 90, 8, 0, 0.5, 100, 2000); 
  chassis.turn_to_angle(0);
  frontdistanceNew(18, 0, 8, 0, 0.5, 100, 2000); 

  task::stop(intakeringLB); 
  intake.spin(reverse, 100, pct);

  chassis.turn_max_voltage = 10;
  task::stop(autoclamp);
  backClaw.open();
  chassis.drive_timeout = 2000;
  chassis.turn_settle_time = 100;
  chassis.turn_to_angle(316);
  chassis.drive_max_voltage = 4;
  chassis.drive_distance(16);
  

/*
  //chassis.drive_distance(13);
  doinkR.open();
  chassis.turn_to_angle(180);
  doinkR.close();

  



  chassis.drive_distance(24);
  lbp.open();
  task::stop(colorsortAuto);
  task t610100(intakering2);

  FrontdistanceVisionST(3.5, 160, 7, 0, 1, 0, 3000);
  allMtrsStop();
  T1.clear();                        //wait for 2nd LB ring to go into LB
while(L==0 && T1.value()<2)  
{

}
task::stop(intakering2);
goalexit=true;
task t971621(autoclamp); 
chassis.turn_to_angle(45);
scanB(300, 6);
BackstraightVisionST(-1900, 160, 5, 3, 5, 0, 2000); 
task t610170(colorsortAuto);
chassis.turn_to_angle(315);
adesiredValue = 500;*/

  wait(30000000000000000, sec);


}

void RedNegativeWorlds()
{

  Inertial20.setHeading(32, deg); // 160 inertial, 1500 back distance
  chassis.set_coordinates(0, 0, 32);  

  greengoalb=true;
  bluering = false;
  redring = true;
  redringi = true;
  blueringc=true;
  redringc=false;
  greenb = true;

  g=0;
  intake.setPosition(0, degrees);
  ringliftL.setPosition(0, degrees);
  backClaw.open();
  lbp2.close();
  T2.clear();

  earlyexit = false;

  lineexit = false;
  AWBB();
  AWB();
  AWBI();


  

  aspeed = 12;
  adesiredValue = 110;
  task t64561474(armPID);               //lift arm

  wait(300, msec);

  intake.spin(reverse, 100, pct);       //put ring in intake
  wait(0.3, sec); //.25
  

  //L=1;
  intake.spin(fwd, 80, pct);           //let ring go
  wait(.15, sec);
  intake.stop(coast); 
  
  aspeed = 6;                          //lift arm a bit
  adesiredValue = 170;
  wait(0.1, sec);
  lbp2.open();                         //close piston
  intake.stop();
  task::stop(armPID);

  while(ringliftL.position(degrees)<=600)      //put ring on stack
  {
    ringliftL.spin(fwd, 100, pct);
    ringliftR.spin(fwd, 100, pct);
    printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
  }
  ringliftL.stop(hold);
  ringliftR.stop(hold); 
  AWBI();                                     //auto white balance
  wait(300, msec);
  

  chassis.drive_distance(-10); 

  aspeed = 12;
  adesiredValue = 0;
  task t64161474(armPID);


  chassis.turn_to_angle(70);
  scanB(300, -6);
  doinkL.open();
  
  BackstraightVisionST(-1100, 160, 11, 2, 5, 0, 2000);    //get goal
  chassis.drive_max_voltage=11;
  chassis.drive_distance(-6);
  doinkL.close();
  
  task t61010(colorsortAuto);
  backClaw.close();
  lbp2.close();
  wait(300, msec);


  chassis.turn_to_angle(180);

  breakdistance = 350;
  breakout = true;
  FrontstraightVisionST(950, 165, 7, 5, 5, 0, 3000); //$$$$$$$1string
  breakout = false;
  earlyexit = true;
  ee=2;
  FrontstraightVisionST(950, 165, 10, 8, 5, 0, 3000); 
  //FrontdistanceVisionST(1, 165, 10, 0, 1, 0, 3000);   //$$$$$$$$1st ring
  //doinkR.open();                                      //right doinker down
  earlyexit = false; 
  //waitforring = true;                                 //wait for ring to come in
  //chassis.drive_distance(4);                          //a bit further
  //waitforring = false;
  chassis.turn_to_angle(260);                         //turn left
  
  backdistanceNew(24, 260, 10, 8, 1, 0, 2000);        //back up to wall
  task::stop(colorsortAuto);
  intake.spin(fwd, 100, pct);                         //reverse intake
  chassis.turn_to_angle(140);                          //turn to face corner ring stack
  doinkR.close();                                     //right doinker up
  scanF(300, 5);
 
  
  aspeed = 12;
  adesiredValue = 110;
  task t67694(armPID);      //LB ring
  g=0;
  L=0;
  task t606101(intakeringLB);
  
  earlyexit = true;
  chassis.drive_timeout = 1000;
  ee = 4;
  FrontstraightVisionST(1400, 165, 7, 5, 5, 0, 3000);  //get ring
  waitforring = true;
  chassis.drive_max_voltage = 5;
  chassis.drive_distance(-12);                        //back up to get ring
  waitforring = false;
  T1.clear();                                         //wait for LB ring
  while(L==0 && T1.value()<3)  
  {
  
  }
  task::stop(intakeringLB);                           
  adesiredValue = 400;                                //arm up high
  task t70610(colorsortAuto);                         // colorsort on to go to wall stake
 
  chassis.turn_to_angle(90);                          // go to wall stake
  frontdistanceNew(50, 90, 8, 0, 0.5, 100, 2000); 
  doinkR.open();
  chassis.turn_to_angle(180);
  frontdistanceNew(18, 180, 8, 0, 0.5, 100, 2000); 


  chassis.turn_max_voltage = 10;
  task::stop(autoclamp);
  backClaw.open();
  chassis.drive_timeout = 2000;
  chassis.turn_settle_time = 100;
  chassis.turn_to_angle(220);
  doinkR.close();
  chassis.drive_max_voltage = 4;
  chassis.drive_distance(15);




wait(3000000000, sec);
}

void BlueNegativeWorlds()
{

  Inertial20.setHeading(150, deg); // 160 inertial, 1500 back distance
  chassis.set_coordinates(0, 0, 150);  
  greengoalb=true;
  bluering = true;
  redring = false;
  redringi = false;
  blueringc= false;
  redringc= true;
  greenb = true;
  /*greengoalb=true;
  bluering = false;
  redring = true;
  redringi = true;
  blueringc=true;
  redringc=false;
  greenb = true;*/

  g=0;
  intake.setPosition(0, degrees);
  ringliftL.setPosition(0, degrees);
  backClaw.open();
  lbp2.close();
  T2.clear();

  earlyexit = false;

  lineexit = false;
  AWBB();
  AWB();
  AWBI();


  

  aspeed = 12;
  adesiredValue = 110;
  task t64561474(armPID);               //lift arm

  wait(300, msec);

  intake.spin(reverse, 100, pct);       //put ring in intake
  wait(0.3, sec); //.25
  

  //L=1;
  intake.spin(fwd, 80, pct);           //let ring go
  wait(.15, sec);
  intake.stop(coast); 
  
  aspeed = 6;                          //lift arm a bit
  adesiredValue = 170;
  wait(0.1, sec);
  lbp2.open();                         //close piston
  intake.stop();
  task::stop(armPID);

  while(ringliftL.position(degrees)<=600)      //put ring on stack
  {
    ringliftL.spin(fwd, 100, pct);
    ringliftR.spin(fwd, 100, pct);
    printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
  }
  ringliftL.stop(hold);
  ringliftR.stop(hold); 
  AWBI();                                     //auto white balance
  wait(300, msec);
  

  chassis.drive_distance(-10); 

  aspeed = 12;
  adesiredValue = 0;
  task t64161474(armPID);


  chassis.turn_to_angle(110);
  scanB(300, -6);
  doinkL.open();
  
  BackstraightVisionST(-1100, 160, 11, 2, 5, 0, 2000);    //get goal
  chassis.drive_max_voltage=11;
  chassis.drive_distance(-6);
  doinkL.close();
  
  task t61010(colorsortAuto);
  backClaw.close();
  lbp2.close();
  wait(300, msec);


  chassis.turn_to_angle(0);

  breakdistance = 350;
  breakout = true;
  FrontstraightVisionST(950, 165, 7, 5, 5, 0, 3000); //$$$$$$$1string
  breakout = false;
  earlyexit = true;
  ee=2;
  FrontstraightVisionST(950, 165, 10, 8, 5, 0, 3000); 
  //FrontdistanceVisionST(1, 165, 10, 0, 1, 0, 3000);   //$$$$$$$$1st ring
  //doinkR.open();                                      //right doinker down
  earlyexit = false; 
  //waitforring = true;                                 //wait for ring to come in
  //chassis.drive_distance(4);                          //a bit further
  //waitforring = false;
  chassis.turn_to_angle(280);                         //turn left
  
  backdistanceNew(24, 280, 10, 8, 1, 0, 2000);        //back up to wall
  task::stop(colorsortAuto);                          //turn off intake and colorsort
  intake.spin(fwd, 100, pct);                         //reverse intake
  chassis.turn_to_angle(40);                          //turn to face corner ring stack
  doinkR.close();                                     //right doinker up
  scanF(300, 5);
 
  
  aspeed = 12;
  adesiredValue = 110;
  task t67694(armPID);      //LB ring
  g=0;
  L=0;
  task t606101(intakeringLB);
  
  earlyexit = true;
  chassis.drive_timeout = 1000;
  ee = 4;
  FrontstraightVisionST(1400, 165, 7, 5, 5, 0, 3000);  //get ring
  waitforring = true;
  chassis.drive_max_voltage = 5;
  chassis.drive_distance(-12);                        //back up to get ring
  waitforring = false;
  T1.clear();                                         //wait for LB ring
  while(L==0 && T1.value()<3)  
  {
  
  }
  task::stop(intakeringLB);                           
  adesiredValue = 400;                                //arm up high
  task t70610(colorsortAuto);                         // colorsort on to go to wall stake
 
  chassis.turn_to_angle(90);                          // go to wall stake
  frontdistanceNew(50, 90, 8, 0, 0.5, 100, 2000); 
  doinkL.open();
  chassis.turn_to_angle(0);
  frontdistanceNew(18, 0, 8, 0, 0.5, 100, 2000); 


  chassis.turn_max_voltage = 10;
  task::stop(autoclamp);
  backClaw.open();
  chassis.drive_timeout = 2000;
  chassis.turn_settle_time = 100;
  chassis.turn_to_angle(316);
  doinkL.close();
  chassis.drive_max_voltage = 4;
  chassis.drive_distance(16);




wait(3000000000, sec);
}

void BluePostiveWorlds()
{

  Inertial20.setHeading(32, deg); // 160 inertial, 1500 back distance
  chassis.set_coordinates(0, 0, 32);  
  
  greengoalb=true;
  bluering = true;
  redring = false;
  redringi = false;
  blueringc= false;
  redringc= true;
  greenb = true;

/*
  greengoalb=true;
  bluering = false;
  redring = true;
  redringi = true;
  blueringc=true;
  redringc=false;
  greenb = true;*/

  g=0;
  intake.setPosition(0, degrees);
  ringliftL.setPosition(0, degrees);
  backClaw.open();
  lbp2.close();
  T2.clear();

  earlyexit = false;

  lineexit = false;
  AWBB();
  AWB();
  AWBI();


  

  aspeed = 12;
  adesiredValue = 110;
  task t64561474(armPID);               //lift arm

  wait(300, msec);

  intake.spin(reverse, 100, pct);       //put ring in intake
  wait(0.3, sec); //.25
  

  //L=1;
  intake.spin(fwd, 80, pct);           //let ring go
  wait(.15, sec);
  intake.stop(coast); 
  
  aspeed = 6;                          //lift arm a bit
  adesiredValue = 170;
  wait(0.1, sec);
  lbp2.open();                         //close piston
  intake.stop();
  task::stop(armPID);

  while(ringliftL.position(degrees)<=600)      //put ring on stack
  {
    ringliftL.spin(fwd, 100, pct);
    ringliftR.spin(fwd, 100, pct);
    printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
  }
  ringliftL.stop(hold);
  ringliftR.stop(hold); 
  AWBI();                                     //auto white balance
  wait(300, msec);
  

  chassis.drive_distance(-10); 

  aspeed = 12;
  adesiredValue = 0;
  task t64161474(armPID);


  chassis.turn_to_angle(70);
  scanB(300, -6);
  doinkL.open();
  
  BackstraightVisionST(-1100, 160, 11, 2, 5, 0, 2000);    //get goal
  chassis.drive_max_voltage=11;
  chassis.drive_distance(-6);
  doinkL.close();
  
  task t61010(colorsortAuto);
  backClaw.close();
  lbp2.close();
  wait(300, msec);


  chassis.turn_to_angle(180);

  breakdistance = 350;
  breakout = true;
  FrontstraightVisionST(950, 165, 7, 5, 5, 0, 3000); //$$$$$$$1string
  breakout = false;
  earlyexit = true;
  ee=2;
  FrontstraightVisionST(950, 165, 10, 8, 5, 0, 3000); 
  //FrontdistanceVisionST(1, 165, 10, 0, 1, 0, 3000);   //$$$$$$$$1st ring
  //doinkR.open();                                      //right doinker down
  earlyexit = false; 
  //waitforring = true;                                 //wait for ring to come in
  //chassis.drive_distance(4);                          //a bit further
  //waitforring = false;
  chassis.turn_to_angle(260);                         //turn left
  
  backdistanceNew(24, 260, 10, 8, 1, 0, 2000);        //back up to wall
  task::stop(colorsortAuto);                          //turn off intake and colorsort
  intake.spin(fwd, 100, pct);                         //reverse intake
  chassis.turn_to_angle(140);                          //turn to face corner ring stack
  doinkR.close();                                     //right doinker up
  scanF(300, 5);
 
  
  aspeed = 12;
  adesiredValue = 110;
  task t67694(armPID);      //LB ring
  g=0;
  L=0;
  task t606101(intakeringLB);
  
  earlyexit = true;
  chassis.drive_timeout = 1000;
  ee = 4;
  FrontstraightVisionST(1400, 165, 7, 5, 5, 0, 3000);  //get ring
  waitforring = true;
  chassis.drive_max_voltage = 5;
  chassis.drive_distance(-12);                        //back up to get ring
  waitforring = false;
  T1.clear();                                         //wait for LB ring
  while(L==0 && T1.value()<3)  
  {
  
  }
  task::stop(intakeringLB);                           
  adesiredValue = 400;                                //arm up high
  task t70610(colorsortAuto);                         // colorsort on to go to wall stake
 
  chassis.turn_to_angle(90);                          // go to wall stake
  frontdistanceNew(50, 90, 8, 0, 0.5, 100, 2000); 
  doinkR.open();
  chassis.turn_to_angle(180);
  frontdistanceNew(18, 180, 8, 0, 0.5, 100, 2000); 


  chassis.turn_max_voltage = 10;
  task::stop(autoclamp);
  backClaw.open();
  chassis.drive_timeout = 2000;
  chassis.turn_settle_time = 100;
  chassis.turn_to_angle(220);
  doinkR.close();
  chassis.drive_max_voltage = 4;
  chassis.drive_distance(15);




wait(3000000000, sec);
}

void Skills()
{

g=0;
intake.setPosition(0, degrees);
T2.clear();
AWB();
AWBB();
AWBI();

Inertial20.setHeading(270, deg); // 56, 140
chassis.set_coordinates(0, 0, 270);  
frontdistanceNew(6, 270, 10, 0, 1, 50000, 50000); 



wait(3000000000000, sec);



//$$$$$$$$$$$$$$$NewRouteBark
//chassis.set_coordinates(xl, yb, Inertial20.heading());
Inertial20.setHeading(140, deg); // 56, 140
chassis.set_coordinates(0, 0, 140);  
greengoalb=true;
greengoal = true;
redringi = true;
blueringc=true;
redringc=false;
greenb = true;
g=0;
intake.setPosition(0, degrees);
T2.clear();
AWB();
AWBB();
AWBI();
earlyexit = false;
distanceexit = false;

//FrontstraightVisionST(1200, 165, 12, 0, 5, 50000, 50000);
//wait(3000000000,sec);
backClaw.open();
while(ringliftL.position(degrees)<=600 )             // 3rd ring on stake
      {
        ringliftL.spin(fwd, 100, pct);
        ringliftR.spin(fwd, 100, pct);
        printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
      }
      ringliftL.stop(hold);
      ringliftR.stop(hold); 
wait(300, msec);
aspeed = 12;
adesiredValue = 0;
task t641600174(armPID);


task t71621(autoclamp); 

goalexit = false;
BackstraightVisionST(-1800, 160, 6, 3, 5, 0, 2000);  // 1st goal
wait(0.5, sec);
task::stop(armPID); 

task t716211(antijam);  //intake antijam


chassis.turn_to_angle(240);      //turn to 1st ring 290
scanF(500, 5);         //scan 1st ring

//earlyexit = true;
breakdistance = 350;
breakout = true;
FrontstraightVisionST(1000, 165, 12, 8, 5, 0, 3000); //$$$$$$$1st ring
breakout = false;
FrontdistanceVisionST(2, 165, 12, 8, 1, 0, 3000);//$$$$$ 1st ring

chassis.drive_min_voltage = 5;
chassis.drive_distance(4);       //after grabbing 1st ring$$$$$$$$


chassis.turn_to_angle(315); //turn to go to 2nd ring 215


chassis.drive_min_voltage = 5;
chassis.drive_max_voltage = 12;
chassis.drive_distance(18);  //drive forward a bit
chassis.turn_to_angle(310); //240



multipleobjectsL = true;
multipleobjectsR = false;
breakdistance = 350;
breakout = true;
FrontstraightVisionST(1800, 165, 12, 8, 5, 0, 3000); //$$$$$$$2nd ring
breakout = false;
FrontdistanceVisionST(2, 165, 12, 8, 1, 0, 3000);
chassis.drive_max_voltage = 8;
waitforring = true;
chassis.drive_distance(4);
waitforring = false;
chassis.turn_to_angle(315);     //turn towards 1st LB ring 225
//allMtrsStop();



//task t6461704(colorsortAuto);

multipleobjectsR = true;
multipleobjectsL = false;
task::stop(antijam); 
aspeed = 12;
adesiredValue = 110;
task t64794(armPID);      //1st LB ring
g=0;
L=0;
task t6101(intakeLBcombo);
//g=0;
//FrontstraightVisionST(2500, 165, 6, 0, 5, 0, 2000); //$$$$$$$2nd ring
FrontdistanceVisionST(2, 165, 12, 8, 1, 0, 3000);  //$$$$$$$2nd ring 
 

frontdistanceNew(22, 270, 5, 0, 1, 0, 3000);      
frontdistanceNew(24, 270, 5, 3, 1, 0, 3000); 
chassis.turn_to_angle(317); //221
frontdistanceNew(27, 317, 10, 5, 2, 0, 3000); //back out 221, 34
chassis.turn_to_angle(270);
//task::stop(colorsortAuto);


backdistanceNew(70, 270, 10, 0, 1, 200, 3000); //get into position wall stake 66
/*
T1.clear();                        //wait for 1st ring
while(L==0 && T1.value()<2)  
{

}
task::stop(intakeringLB); 
intake.stop();

L=0;
g=0;
task t67631(intakering2);  //hold 2nd LB ring in intake
*/
chassis.turn_to_angle(0);         // turn towards wallstake 180

//g=0;
//earlyexit = true;
multipleobjectsR = false;
//frontdistanceNew(10, 0, 8, 0, 1, 0, 3000);  //drive toward wall stake
FrontdistanceVisionST(2, 165, 12, 8, 1, 0, 3000); //drive toward wall stake

T1.clear();                        //wait for 2nd LB ring
while(L==0 && T1.value()<3)  
{

}
task::stop(intakeLBcombo); 
intake.stop();

chassis.drive_timeout = 600;
chassis.drive_distance(20,0);  //drive into wall stake
task::stop(armPID);
T1.clear();
while(ringliftL.position(degrees)<=600 && T1.value()<1.5)   // 1st LB ring on stake
      {
        ringliftL.spin(fwd, 100, pct);
        ringliftR.spin(fwd, 100, pct);
        printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
      }
      ringliftL.stop(hold);
      ringliftR.stop(hold); 
      lbp2.close();

wait(100, msec);
aspeed = 12;
adesiredValue = 110;
task t641674(armPID);

wait(0.75, sec);
L=0;
g=0;
task t611031(intakeringLB2);
T1.clear();                        //wait for 2nd LB ring to go into LB
while(L==0 && T1.value()<2)  
{

}
task::stop(intakeringLB2);
intake.stop(); 
chassis.drive_timeout = 2000;
task::stop(armPID); 


T1.clear();
 while(ringliftL.position(degrees)<=600 && T1.value()<1.5)   // 4th ring on stake
      {
        ringliftL.spin(fwd, 100, pct);
        ringliftR.spin(fwd, 100, pct);
        printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
      }
      ringliftL.stop(hold);
      ringliftR.stop(hold);
      lbp2.close();

      frontdistanceNew(17.5, 0, 12, 8, 1, 0, 2000); //back up a bit 180 
      task t64161074(antijam);  
      
      aspeed = 12;
      adesiredValue = 0;
      task t6416174(armPID);              //arm back down
      //chassis.turn_settle_time = 100;
      chassis.turn_to_angle(90); 
      multipleobjectsR = true;
      FrontdistanceVisionWall(15, 165, 8, 6, 0.5, 0, 3000); 
      multipleobjectsR = false;
      //waitforring = true;
      frontdistanceNew(8, 90, 12, 0, 1, 0, 2000);
       
      
      
      /*
      //g=0; 
      //earlyexit = false;  
      FrontstraightVisionST(2100, 170, 12, 7, 5, 0, 2000);  
      //FrontdistanceVisionST(4, 170, 12, 8, 1, 0, 3000);
      //g=0;
      //earlyexit = true;
      //FrontdistanceVisionST(1, 170, 12, 8, 1, 0, 3000);  
      frontdistanceNew(5, 90, 7, 0, 1, 0, 2000);  //$$$$$5th and 6th
      */
      
      
      ////$$$$$$$$$$$$$$$$$$$$$$test
      waitforring = true;
      //FrontdistanceVisionST(0.5, 170, 12, 8, 0.5, 0, 3000);  
      //FrontdistanceVisionST(0.5, 170, 12, 8, 0.5, 0, 3000); 
      //FrontdistanceVisionST(0.5, 170, 12, 8, 0.5, 0, 3000); 
      //frontdistanceNew(5, 90, 7, 0, 1, 0, 2000);  //$$$$$5th and 6th
      
      
      chassis.turn_settle_time = 0;
      chassis.turn_timeout = 2000;
      chassis.turn_max_voltage = 6;
      chassis.turn_to_angle(325); //215
      task::stop(armPID);
      
      //g=0;
      earlyexit = true;
      FrontstraightVisionST(1000, 165, 12, 6, 5, 0, 2000);  //$$$$$$7th ring
      
      chassis.drive_timeout = 500;
      chassis.drive_min_voltage = 5;
      chassis.drive_distance(4);       //go a bit further to 7th
      chassis.turn_timeout = 1200;
      chassis.turn_max_voltage = 12;
      chassis.turn_to_angle(215);   //turn to drop off goal 325
      chassis.drive_timeout = 1000;
      chassis.drive_distance(-24);  // back up to drop off goal
      
      task::stop(autoclamp); 
      
      backClaw.open();            //open claw to drop
      task::stop(antijam);
      intake.spin(fwd, 100, pct);
      wait(0.5,sec);
      task t61079531(antijam);
      
      
      chassis.drive_timeout = 2000;
      chassis.drive_min_voltage = 8;
      chassis.drive_max_voltage = 12;
      chassis.drive_distance(70,260); //drive to far point on the field 46
      task::stop(antijam);
      intake.stop();
      
      aspeed = 12;
      adesiredValue = 110;
      task t6497224(armPID);      //LB for 1st ring
      g=0;
      L=0;
      task t617531(intakeringLB);
      
      //g=0;
      //earlyexit = true;
      waitforring = false;
      FrontdistanceVisionST(2, 165, 6, 3, 1, 0, 3000); 
      allMtrsStop();
      wait(0.5, sec);
      frontdistanceNew(26, 270, 7, 0, 1, 0, 2000);
      chassis.turn_to_angle(45);
      
      task t61075341(autoclamp);
      chassis.drive_min_voltage = 0;
      scanB(300, 5);
      BackstraightVisionST(-1900, 160, 6, 5, 5, 0, 2000); //$$$goal
      chassis.drive_distance(-4);
      chassis.turn_to_angle(0);
      T1.clear();                        //wait for 1st LB ring to go into LB
      while(L==0 && T1.value()<2)  
      {
      
      }
      task::stop(intakeringLB);
      intake.stop(); 
      L=0;
      g=0;
      task t6110(intakedecide); //avoids blue rings and keeps going till red in intake
      
      FrontstraightVisionST(1500, 165, 8, 6, 5, 0, 2000);  //$$$$$$2nd LB intake
      T1.clear();                        //wait for 2nd LB ring to go into intake
      while(L==0 && T1.value()<2)  
      {
      
      }
      doinkL.open(); //donker down
      frontdistanceNew(16, 355, 10, 0, 1, 0, 2000);  //drive forward to sweep
      
      chassis.turn_to_angle(140);    //sweep
      chassis.drive_timeout = 1000;
      chassis.drive_distance(-24);  // back up to drop off goal
      
      task::stop(autoclamp); 
      
      backClaw.close();            //open claw to drop
      task::stop(intakedecide);
      intake.spin(fwd, 100, pct);
      wait(0.1,sec);
      intake.stop();
      
      chassis.drive_distance(26); 
      chassis.turn_to_angle(0);
      goalexit=true;
      task t7161(autoclamp); 
      scanB(300, -5);
      //BackturnVisionST(172, 10, 10, 10, 100, 1000);
      BackstraightVisionST(-1900, 165, 6, 3, 5, 0, 2000); //$$$2ndgoal
      chassis.turn_to_angle(0);
      backdistanceNew(68, 0, 9, 0, 1, 200, 2000); // back into postition
      chassis.turn_to_angle(270); //turn into alliance stake
      frontdistanceNew(14, 270, 8, 0, 1, 0, 3000);  // drive towards alliance stake
      
      //chassis.drive_timeout = 600;
      //chassis.drive_distance(20); 
      task::stop(armPID);
      T1.clear();
      while(ringliftL.position(degrees)<=600 && T1.value()<1)             // 3rd ring on stake
            {
              ringliftL.spin(fwd, 100, pct);
              ringliftR.spin(fwd, 100, pct);
              printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
            }
            ringliftL.stop(hold);
            ringliftR.stop(hold); 
            lbp2.close();
            
      wait(300, msec);
      aspeed = 12;
      adesiredValue = 110;
      task t64174(armPID);
      wait(0.5, sec);
      L=0;
      g=0;
      task t61031(intakeringLB2);
      T1.clear();                        //wait for 2nd ring into LB
      while(L==0 && T1.value()<2)  
      {
      
      }
      task::stop(intakeringLB2);
      intake.stop(); 
      chassis.drive_timeout = 2000;
      task::stop(armPID); 
      
      
      T1.clear();
       while(ringliftL.position(degrees)<=600 && T1.value()<1)   // 2nd ring on stake
            {
              ringliftL.spin(fwd, 100, pct);
              ringliftR.spin(fwd, 100, pct);
              printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
            }
            ringliftL.stop(hold);
            ringliftR.stop(hold);
            lbp2.close();
      intake.spin(reverse, 100, pct);
      
      frontdistanceNew(17.5, 270, 12, 8, 1, 0, 2000); //back up a bit
      



//wait(3000000000000, sec);


frontdistanceNew(17.5, 270, 12, 8, 1, 0, 2000); //back up a bit

aspeed = 12;
adesiredValue = 0;
task t67194(armPID);              //arm back down
chassis.turn_to_angle(30);    //85turn toward 4th ring
scanF(500, 5);
//task t3141(antijam);
task t641974(intakeRung);

breakdistance = 350;
breakout = true;
FrontstraightVisionST(1100, 165, 12, 8, 5, 0, 3000); //$$$$$$$1string
breakout = false;
FrontdistanceVisionST(2, 165, 12, 8, 1, 0, 3000);
chassis.drive_max_voltage = 8;
chassis.drive_distance(4);

//allMtrsStop(); //take out
//wait(2, sec); //take out

chassis.turn_max_voltage = 5;
chassis.turn_to_angle(125);      // turn to go under bar
T1.clear();                        //wait for 2nd LB ring to get into intake
while(L==0 && T1.value()<3)  
{
      
}
chassis.drive_max_voltage = 12;
task::stop(armPID); 
task::stop(intakeRung);              //stop intake
intake.stop();


//breakdistance = 350;
//breakout = true;
//FrontstraightVisionST(1000, 170, 12, 8, 5, 0, 3000); //$$$$$$$2nd ring under bar push
breakout = false;
FrontdistanceVisionST(6, 165, 12, 8, 1, 0, 3000);
chassis.drive_min_voltage = 5;
task t6414(intakeRung);
chassis.drive_distance(12, 125);
//allMtrsStop(); //take out
//wait(2, sec); //take out
chassis.drive_distance(6, 125);
//allMtrsStop(); //take out
//wait(2, sec); //take out
T1.clear();                        //wait for 2nd LB ring to get into intake
while(L==0 && T1.value()<3)  
{
      
}
 
//allMtrsStop(); //take out
//wait(2, sec); //take out
//breakdistance = 350;
//breakout = true;
//waitforring = false;
//FrontstraightVisionST(1000, 170, 12, 8, 5, 0, 3000); //$$$$$$$1string
//breakout = false;
task::stop(intakeRung); 

FrontdistanceVisionST(5, 165, 12, 8, 1, 0, 3000);
task t3181(antijam);
waitforring = true;
chassis.drive_distance(8, 125);
//allMtrsStop(); //take out
//wait(2, sec); //take out

//multipleobjectsF = true;
//FrontstraightVisionST(2000, 170, 12, 8, 5, 0, 3000); 
//allMtrsStop(); //take out
//wait(2, sec); //take out

breakdistance = 350;
breakout = true;
waitforring = false;
FrontstraightVisionST(1000, 165, 12, 8, 5, 0, 3000); //$$$$$$$1string
breakout = false;

FrontdistanceVisionST(2, 165, 12, 8, 1, 0, 3000);
//allMtrsStop(); //take out
//wait(2, sec); //take out
//g=0;
//FrontstraightVisionST(1700, 170, 6, 5, 5, 0, 4000);
//allMtrsStop(); //take out
//wait(2, sec); //take out

//multipleobjectsF = false;
//waitforring = true;
//FrontdistanceVisionST(1, 170, 12, 8, 1, 0, 3000);
//allMtrsStop(); //take out
//wait(2, sec); //take out
chassis.turn_to_angle(95); 

multipleobjectsL = true;
FrontdistanceVisionWall(18, 165, 8, 6, 0.5, 0, 3000); 
multipleobjectsR = false;
//waitforring = true;
frontdistanceNew(8, 90, 12, 0, 1, 0, 2000); //$$$$$5th and 6th


//wait(1, sec); //take out
chassis.turn_settle_time = 0;
chassis.turn_timeout = 2000;
chassis.turn_max_voltage = 6;
chassis.turn_to_angle(200); //215
task::stop(armPID);

//g=0;
earlyexit = true;
FrontstraightVisionST(1000, 165, 12, 6, 5, 0, 2000);  //$$$$$$7th ring

chassis.drive_timeout = 500;
chassis.drive_min_voltage = 5;
waitforring = true;
chassis.drive_distance(4);       //go a bit further to 7th
waitforring = false;
chassis.turn_timeout = 1200;
chassis.turn_max_voltage = 10;
chassis.turn_to_angle(325);   //turn to drop off goal 325
chassis.drive_timeout = 1000;
chassis.drive_distance(-24);  // back up to drop off goal

task::stop(autoclamp); 

backClaw.open();            //open claw to drop
task::stop(antijam);
intake.spin(fwd, 100, pct);
wait(0.5,sec);
intake.stop();




//backClaw.open(); 
//wait(1, sec);
chassis.turn_to_angle(325);
chassis.turn_max_voltage = 12;
chassis.turn_timeout = 2000;
chassis.drive_timeout = 2000;
chassis.drive_min_voltage = 8;
chassis.drive_max_voltage = 12;
chassis.drive_distance(4, 325); //bee line away turning at same time
chassis.turn_to_angle(180); 


chassis.turn_settle_time = 0;


goalexit=true;
task t710941(autoclamp); 
scanB(300, 5);
//BackturnVisionST(172, 10, 10, 10, 100, 1000);
BackstraightVisionST(-1900, 160, 6, 3, 10, 0, 2000); //$$$2ndgoal
frontdistanceNew(40, 180, 9, 5, 1, 0, 2000);
wait(.25, sec);

aspeed = 12;
adesiredValue = 110;
task t47494(armPID);      //1st LB ring
g=0;
L=0;
task t614301(intakeLBcombo); 

chassis.turn_settle_time = 0;
chassis.turn_to_angle(215);
//scanF(300, 5);
//waitforring=true;
//breakdistance = 350;
//breakout = true;
//FrontstraightVisionST(750, 170, 12, 8, 5, 0, 3000); //$$$$$$$1st ring
//breakout = false;
FrontdistanceVisionST(2, 165, 12, 0, 1, 0, 3000);//$$$$$ 1st ring


chassis.turn_to_angle(230);     //turn towards 2nd ring 225
T1.clear();                        //wait for 2nd LB ring to get into intake
while(L==0 && T1.value()<3)  
{
      
}

FrontdistanceVisionST(2, 165, 12, 8, 1, 0, 3000);
chassis.drive_distance(4);
chassis.drive_distance(-8);

//frontdistanceNew(8, 180, 12, 8, 1, 0, 2000);
//chassis.turn_to_angle(270);
//chassis.drive_distance(12);

//FrontdistanceVisionST(2, 165, 12, 8, 1, 0, 3000);
//chassis.turn_to_angle(300); 
//chassis.drive_distance(8);
chassis.turn_to_angle(270); 
backdistanceNew(67.5, 270, 12, 0, 0.5, 100, 2000);
//task::stop(intakeringLB); 
//intake.stop();
chassis.turn_to_angle(180);


//adesiredValue = 170;
//FrontdistanceVisionWall(10, 165, 12, 8, 1, 0, 3000);
//chassis.left_swing_to_angle(180);
chassis.drive_timeout = 600;
chassis.drive_distance(20,180); 
allMtrsStop();

T1.clear();                        //wait for 2nd LB ring to get into intake
while(L==0 && T1.value()<3)  
{
      
}
task::stop(intakeLBcombo);
intake.stop();
task::stop(armPID);

T1.clear();
while(ringliftL.position(degrees)<=600 && T1.value()<1.5)   // 1st LB ring on stake
      {
        ringliftL.spin(fwd, 100, pct);
        ringliftR.spin(fwd, 100, pct);
        //intake.spin(fwd, 30, pct);
        printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
      }
      ringliftL.stop(hold);
      ringliftR.stop(hold);
      //intake.stop(coast); 
      lbp2.close();
      

wait(100, msec);
aspeed = 12;
adesiredValue = 110;
task t65574(armPID);

wait(0.75, sec);


L=0;
g=0;
task t64131(intakeringLB2);
T1.clear();                        //wait for 2nd LB ring to go into LB
while(L==0 && T1.value()<2)  
{

}
task::stop(intakeringLB2); 
intake.stop(); 
chassis.drive_timeout = 2000;
task::stop(armPID); 


T1.clear();
 while(ringliftL.position(degrees)<=600 && T1.value()<1.5)   // 4th ring on stake
      {
        ringliftL.spin(fwd, 100, pct);
        ringliftR.spin(fwd, 100, pct);
        intake.spin(fwd, 30, pct);
        printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
      }
      ringliftL.stop(hold);
      ringliftR.stop(hold);
      intake.stop(coast);
      lbp2.close();



//frontdistanceNew(17.5, 180, 12, 8, 1, 0, 2000); //back up a bit 180 

task t61010(colorsortAuto);
frontdistanceNew(16, 180, 12, 8, 1, 0, 2000); //back up a bit 180
aspeed = 12;
adesiredValue = 1;
task t0174(armPID); 
chassis.turn_to_angle(250); 
AWB();
FrontdistanceVisionST(2, 160, 8, 6, 1, 0, 3000);
waitforring = true;
chassis.drive_distance(4);     // 1st
//allMtrsStop(); //take out
//wait(2, sec); //take out
allMtrsStop();
multipleobjectsL = true;

FrontdistanceVisionST(2, 160, 8, 6, 1, 0, 3000);
waitforring = true;
chassis.drive_distance(4);    //2nd
waitforring = false;
//allMtrsStop(); //take out
//wait(2, sec); //take out
multipleobjectsL = false;
chassis.turn_to_angle(270);
frontdistanceNew(28, 270, 12, 8, 1, 0, 2000); 
chassis.turn_to_angle(295);
FrontdistanceVisionST(2, 160, 8, 6, 1, 0, 3000); //3rd
waitforring = true;
chassis.drive_distance(4); 
waitforring = false;
//allMtrsStop(); //take out
//wait(2, sec); //take out
//FrontdistanceVisionWall(12, 160, 6, 5, 1, 0, 3000); //4th
scanF(500, -6);
FrontdistanceVisionST(2, 160, 8, 6, 1, 0, 3000); //4th
waitforring = true;
chassis.drive_distance(4); 
waitforring = false;
//allMtrsStop(); //take out
//wait(2, sec); //take out
chassis.turn_to_angle(270);
frontdistanceNew(28, 270, 12, 8, 1, 0, 2000);
//chassis.drive_distance(-10); 
chassis.turn_to_angle(0);
scanF(500, 5); 
FrontdistanceVisionST(2, 160, 8, 6, 1, 0, 3000); //5th
waitforring = true;
chassis.drive_distance(4); 
waitforring = false;
chassis.drive_max_voltage = 8;
chassis.drive_distance(-12); 
//allMtrsStop(); //take out
//wait(2, sec); //take out
//chassis.drive_max_voltage = 5;
chassis.turn_to_angle(250);
//FrontdistanceVisionST(1, 170, 8, 6, 1, 0, 3000);
chassis.drive_distance(30); 


wait(3000000000, sec);




//frontdistanceNew(16, 180, 10, 8, 1, 0, 3000); 
//intake.spin(reverse, 100, pct);
//FrontdistanceVisionST(2, 160, 10, 0, 1, 0, 3000);
//allMtrsStop();
//task t617010(colorsortAuto);
//wait(30000000000, sec);
/*
chassis.drive_distance(4);
chassis.turn_to_angle(90);

allMtrsStop();
//task t616010(colorsortAuto);
wait(30000000000, sec);



aspeed = 12;
adesiredValue = 130;
task t47494(armPID);      //1st LB ring
g=0;
L=0;
task t614301(intakeLBcombo); 
*/
//chassis.drive_distance(96);
//chassis.turn_to_angle(90);
//(170, 12, 5, 5, 50000, 50000);
//intake.spin(reverse, 100, pct);

//FrontstraightVisionST(3800, 160, 12, 8, 5, 0, 3000);
//FrontdistanceVisionWall(12, 170, 12, 8, 1, 0, 3000);
//FrontdistanceVisionST(2, 170, 12, 8, 1, 0, 3000);
//backClaw.open();
//wait(0.5, sec);
//goalexit=false;
//task t710941(autoclamp); 
//scanB(300, 5);
//BackturnVisionST(172, 10, 10, 10, 50000, 50000);

//BackstraightVisionST(-1900, 160, 6, 3, 5, 0, 2000); //$$$2ndgoal
//wait(3, sec);
//backClaw.close();
//backdistanceNew(20, 270, 12, 0, 1, 50000, 50000);
//wait(30000000000, sec);

/*
frontdistanceNew(17.5, 270, 12, 8, 1, 0, 2000); //back up a bit

aspeed = 12;
adesiredValue = 1;
task t67194(armPID);              //arm back down
chassis.turn_to_angle(50);    //85turn toward 4th ring
//task t3141(antijam);
task t641974(intakeRung);

breakdistance = 350;
breakout = true;
FrontstraightVisionST(1350, 170, 12, 8, 5, 0, 3000); //$$$$$$$1string
breakout = false;
FrontdistanceVisionST(1, 170, 12, 8, 1, 0, 3000);
chassis.drive_max_voltage = 8;
waitforring = true;
chassis.drive_distance(1);
waitforring = false;

chassis.turn_max_voltage = 5;
chassis.turn_to_angle(125);      // turn to go under bar
chassis.drive_max_voltage = 12;
task::stop(armPID); 
task::stop(intakeRung);              //stop intake
intake.stop();


//breakdistance = 350;
//breakout = true;
//FrontstraightVisionST(1000, 170, 12, 8, 5, 0, 3000); //$$$$$$$2nd ring under bar push
breakout = false;
FrontdistanceVisionST(6, 170, 12, 8, 1, 0, 3000);
chassis.drive_min_voltage = 5;
chassis.drive_distance(16, 125);
task t6414(intakeRung);
waitforring = true;
chassis.drive_distance(6, 125);
waitforring = false;
 
//allMtrsStop(); //take out
//wait(2, sec); //take out
//breakdistance = 350;
//breakout = true;
//waitforring = false;
//FrontstraightVisionST(1000, 170, 12, 8, 5, 0, 3000); //$$$$$$$1string
//breakout = false;
task::stop(intakeRung); 

FrontdistanceVisionST(5, 170, 12, 8, 1, 0, 3000);
task t3181(antijam);
waitforring = true;
chassis.drive_distance(8, 125);

//multipleobjectsF = true;
//FrontstraightVisionST(2000, 170, 12, 8, 5, 0, 3000); 
//allMtrsStop(); //take out
//wait(2, sec); //take out

breakdistance = 350;
breakout = true;
waitforring = false;
FrontstraightVisionST(1000, 170, 12, 8, 5, 0, 3000); //$$$$$$$1string
breakout = false;

FrontdistanceVisionST(1, 170, 12, 8, 1, 0, 3000);

//g=0;
//FrontstraightVisionST(1700, 170, 6, 5, 5, 0, 4000);
//allMtrsStop(); //take out
//wait(2, sec); //take out

//multipleobjectsF = false;
//waitforring = true;
//FrontdistanceVisionST(1, 170, 12, 8, 1, 0, 3000);
//allMtrsStop(); //take out
//wait(2, sec); //take out
chassis.turn_to_angle(95); 

multipleobjectsL = true;
FrontdistanceVisionWall(15, 170, 8, 6, 0.5, 0, 3000); 
multipleobjectsR = false;
//waitforring = true;
frontdistanceNew(8, 90, 12, 0, 1, 0, 2000); //$$$$$5th and 6th


wait(1, sec); //take out
chassis.turn_settle_time = 0;
chassis.turn_timeout = 2000;
chassis.turn_max_voltage = 6;
chassis.turn_to_angle(215); //215
task::stop(armPID);

//g=0;
earlyexit = true;
FrontstraightVisionST(1000, 170, 12, 6, 5, 0, 2000);  //$$$$$$7th ring

chassis.drive_timeout = 500;
chassis.drive_min_voltage = 5;
chassis.drive_distance(4);       //go a bit further to 7th
chassis.turn_timeout = 1200;
chassis.turn_max_voltage = 12;
chassis.turn_to_angle(325);   //turn to drop off goal 325
chassis.drive_timeout = 1000;
chassis.drive_distance(-24);  // back up to drop off goal

task::stop(autoclamp); 

backClaw.close();            //open claw to drop
task::stop(antijam);
intake.spin(fwd, 100, pct);
wait(0.5,sec);
intake.stop();


//wait(3000000000, sec);

//FrontdistanceVisionST(4, 170, 12, 8, 1, 0, 3000);
//FrontdistanceVisionST(1, 170, 12, 8, 1, 0, 3000);


//wait(30000000000, sec);

chassis.turn_to_angle(325); 
chassis.turn_max_voltage = 12;
chassis.turn_timeout = 2000;
chassis.drive_timeout = 2000;
chassis.drive_min_voltage = 8;
chassis.drive_max_voltage = 12;
chassis.drive_distance(4, 325); //bee line away turning at same time
chassis.turn_to_angle(180); 


chassis.turn_settle_time = 0;


goalexit=true;
task t710941(autoclamp); 
scanB(300, 5);
//BackturnVisionST(172, 10, 10, 10, 100, 1000);
BackstraightVisionST(-1900, 100, 6, 3, 5, 0, 2000); //$$$2ndgoal
frontdistanceNew(40, 180, 9, 5, 1, 0, 2000);
//wait(1, sec);

aspeed = 12;
adesiredValue = 40;
task t47494(armPID);      //1st LB ring
g=0;
L=0;
task t614301(intakeLBcombo); 

chassis.turn_settle_time = 0;
chassis.turn_to_angle(215);
//scanF(300, 5);
//waitforring=false;
//breakdistance = 350;
//breakout = true;
//FrontstraightVisionST(750, 170, 12, 8, 5, 0, 3000); //$$$$$$$1st ring
//breakout = false;
FrontdistanceVisionST(1, 170, 12, 8, 1, 0, 3000);//$$$$$ 1st ring

//chassis.drive_distance(8);
chassis.turn_to_angle(180);     //turn towards 2nd ring 225
//allMtrsStop();
frontdistanceNew(10, 180, 12, 8, 1, 0, 2000);
chassis.turn_to_angle(270);
FrontdistanceVisionST(1, 170, 12, 8, 1, 0, 3000);
backdistanceNew(64, 270, 12, 8, 2, 300, 2000);
//task::stop(intakeringLB); 
//intake.stop();
chassis.turn_to_angle(180);

//chassis.left_swing_to_angle(180);
chassis.drive_timeout = 600;
chassis.drive_distance(20,180); 
T1.clear();                        //wait for 2nd LB ring to get into intake
while(L==0 && T1.value()<3)  
{
      
}
task::stop(intakeLBcombo);
intake.stop();
task::stop(armPID);

while(rotationARM.position(degrees)<=180 && T1.value()<1.5)   // 1st LB ring on stake
      {
        ringliftL.spin(fwd, 100, pct);
        ringliftR.spin(fwd, 100, pct);
        printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
      }
      ringliftL.stop(hold);
      ringliftR.stop(hold); 
      

wait(100, msec);
aspeed = 12;
adesiredValue = 40;
task t66574(armPID);

wait(0.8, sec);
L=0;
g=0;
task t64131(intakeringLB2);
T1.clear();                        //wait for 2nd LB ring to go into LB
while(L==0 && T1.value()<2)  
{

}
task::stop(intakeringLB2);
intake.stop(); 
chassis.drive_timeout = 2000;
task::stop(armPID); 


T1.clear();
 while(rotationARM.position(degrees)<=180 && T1.value()<1.5)   // 4th ring on stake
      {
        ringliftL.spin(fwd, 100, pct);
        ringliftR.spin(fwd, 100, pct);
        printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
      }
      ringliftL.stop(hold);
      ringliftR.stop(hold);



frontdistanceNew(17.5, 180, 12, 8, 1, 0, 2000); //back up a bit 180 
wait(30000000000000,sec);
*/


/*

while(rotationARM.position(degrees)<=180)             // 3rd ring on stake
      {
        ringliftL.spin(fwd, 100, pct);
        ringliftR.spin(fwd, 100, pct);
        printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
      }
      ringliftL.stop(hold);
      ringliftR.stop(hold); 
wait(300, msec);
aspeed = 12;
adesiredValue = 1;
task t641600174(armPID);


task t71621(autoclamp); 

goalexit = false;
BackstraightVisionST(-2000, 100, 6, 3, 5, 0, 2000);  // 1st goal
wait(0.5, sec);
task::stop(armPID); 

task t716211(antijam);  //intake antijam


chassis.turn_to_angle(270);      //turn to 1st ring 290
scanF(500, 5);         //scan 1st ring

//earlyexit = true;
breakdistance = 350;
breakout = true;
FrontstraightVisionST(1000, 170, 12, 8, 5, 0, 3000); //$$$$$$$1st ring
breakout = false;
FrontdistanceVisionST(1, 170, 12, 8, 1, 0, 3000);//$$$$$ 1st ring

chassis.drive_min_voltage = 5;
chassis.drive_distance(2);       //after grabbing 1st ring$$$$$$$$


chassis.turn_to_angle(315); //turn to go to 2nd ring 215


chassis.drive_min_voltage = 5;
chassis.drive_max_voltage = 12;
chassis.drive_distance(18);  //drive forward a bit
chassis.turn_to_angle(310); //240



multipleobjectsL = true;
multipleobjectsR = false;
breakdistance = 350;
breakout = true;
FrontstraightVisionST(1800, 170, 12, 8, 5, 0, 3000); //$$$$$$$2nd ring
breakout = false;
FrontdistanceVisionST(1, 170, 12, 8, 1, 0, 3000);
chassis.drive_max_voltage = 8;
chassis.drive_distance(1);
chassis.turn_to_angle(315);     //turn towards 1st LB ring 225
//allMtrsStop();



//task t6461704(colorsortAuto);

multipleobjectsR = true;
multipleobjectsL = false;

//g=0;
FrontstraightVisionST(2500, 170, 6, 0, 5, 0, 2000); //$$$$$$$2nd ring
FrontdistanceVisionST(1, 170, 12, 8, 1, 0, 3000);  //$$$$$$$2nd ring 
task::stop(antijam); 
aspeed = 12;
adesiredValue = 40;
task t64794(armPID);      //1st LB ring
g=0;
L=0;
task t6101(intakeringLB); 

frontdistanceNew(22, 270, 5, 0, 1, 0, 3000);      
frontdistanceNew(24, 270, 5, 3, 1, 0, 3000); 
chassis.turn_to_angle(317); //221
frontdistanceNew(27, 317, 10, 5, 2, 0, 3000); //back out 221, 34
chassis.turn_to_angle(270);
//task::stop(colorsortAuto);


backdistanceNew(70, 270, 10, 0, 1, 200, 3000); //get into position wall stake 66
T1.clear();                        //wait for 1st ring
while(L==0 && T1.value()<2)  
{

}
task::stop(intakeringLB); 
intake.stop();

L=0;
g=0;
task t67631(intakering2);  //hold 2nd LB ring in intake
chassis.turn_to_angle(0);         // turn towards wallstake 180

//g=0;
//earlyexit = true;
multipleobjectsR = false;
//frontdistanceNew(10, 0, 8, 0, 1, 0, 3000);  //drive toward wall stake
FrontdistanceVisionST(1, 170, 12, 8, 1, 0, 3000); //drive toward wall stake
*/

/*
T1.clear();                        //wait for 2nd LB ring
while(L==0 && T1.value()<3)  
{

}
*/
/*
chassis.drive_timeout = 600;
chassis.drive_distance(20,0);  //drive into wall stake
task::stop(armPID);
T1.clear();
while(rotationARM.position(degrees)<=180 && T1.value()<1.5)   // 1st LB ring on stake
      {
        ringliftL.spin(fwd, 100, pct);
        ringliftR.spin(fwd, 100, pct);
        printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
      }
      ringliftL.stop(hold);
      ringliftR.stop(hold); 
      

wait(100, msec);
aspeed = 12;
adesiredValue = 40;
task t641674(armPID);
T1.clear();                        //wait for 2nd LB ring to get into intake
while(L==0 && T1.value()<3)  
{
      
}
task::stop(intakering2);
intake.stop(); 
wait(0.8, sec);
L=0;
g=0;
task t611031(intakeringLB2);
T1.clear();                        //wait for 2nd LB ring to go into LB
while(L==0 && T1.value()<2)  
{

}
task::stop(intakeringLB2);
intake.stop(); 
chassis.drive_timeout = 2000;
task::stop(armPID); 


T1.clear();
 while(rotationARM.position(degrees)<=180 && T1.value()<1.5)   // 4th ring on stake
      {
        ringliftL.spin(fwd, 100, pct);
        ringliftR.spin(fwd, 100, pct);
        printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
      }
      ringliftL.stop(hold);
      ringliftR.stop(hold);



frontdistanceNew(17.5, 0, 12, 8, 1, 0, 2000); //back up a bit 180 
task t64161074(antijam);  

aspeed = 12;
adesiredValue = 1;
task t6416174(armPID);              //arm back down
//chassis.turn_settle_time = 100;
chassis.turn_to_angle(90); 
multipleobjectsR = true;
FrontdistanceVisionWall(15, 170, 8, 6, 0.5, 0, 3000); 
multipleobjectsR = false;
//waitforring = true;
frontdistanceNew(8, 90, 12, 0, 1, 0, 2000);
 
*/

/*
//g=0; 
//earlyexit = false;  
FrontstraightVisionST(2100, 170, 12, 7, 5, 0, 2000);  
//FrontdistanceVisionST(4, 170, 12, 8, 1, 0, 3000);
//g=0;
//earlyexit = true;
//FrontdistanceVisionST(1, 170, 12, 8, 1, 0, 3000);  
frontdistanceNew(5, 90, 7, 0, 1, 0, 2000);  //$$$$$5th and 6th
*/

/*
////$$$$$$$$$$$$$$$$$$$$$$test
waitforring = true;
//FrontdistanceVisionST(0.5, 170, 12, 8, 0.5, 0, 3000);  
//FrontdistanceVisionST(0.5, 170, 12, 8, 0.5, 0, 3000); 
//FrontdistanceVisionST(0.5, 170, 12, 8, 0.5, 0, 3000); 
//frontdistanceNew(5, 90, 7, 0, 1, 0, 2000);  //$$$$$5th and 6th


chassis.turn_settle_time = 0;
chassis.turn_timeout = 2000;
chassis.turn_max_voltage = 6;
chassis.turn_to_angle(325); //215
task::stop(armPID);

//g=0;
earlyexit = true;
FrontstraightVisionST(1000, 170, 12, 6, 5, 0, 2000);  //$$$$$$7th ring

chassis.drive_timeout = 500;
chassis.drive_min_voltage = 5;
chassis.drive_distance(4);       //go a bit further to 7th
chassis.turn_timeout = 1200;
chassis.turn_max_voltage = 12;
chassis.turn_to_angle(215);   //turn to drop off goal 325
chassis.drive_timeout = 1000;
chassis.drive_distance(-24);  // back up to drop off goal

task::stop(autoclamp); 

backClaw.close();            //open claw to drop
task::stop(antijam);
intake.spin(fwd, 100, pct);
wait(0.5,sec);
task t61079531(antijam);


chassis.drive_timeout = 2000;
chassis.drive_min_voltage = 8;
chassis.drive_max_voltage = 12;
chassis.drive_distance(70,260); //drive to far point on the field 46
task::stop(antijam);
intake.stop();

aspeed = 12;
adesiredValue = 40;
task t6497224(armPID);      //LB for 1st ring
g=0;
L=0;
task t617531(intakeringLB);

//g=0;
//earlyexit = true;
waitforring = false;
FrontdistanceVisionST(1, 170, 6, 3, 1, 0, 3000); 
allMtrsStop();
wait(0.5, sec);
frontdistanceNew(26, 270, 7, 0, 1, 0, 2000);
chassis.turn_to_angle(45);

task t61075341(autoclamp);
chassis.drive_min_voltage = 0;
scanB(300, 5);
BackstraightVisionST(-1900, 100, 6, 5, 5, 0, 2000); //$$$goal
chassis.drive_distance(-4);
chassis.turn_to_angle(0);
T1.clear();                        //wait for 1st LB ring to go into LB
while(L==0 && T1.value()<2)  
{

}
task::stop(intakeringLB);
intake.stop(); 
L=0;
g=0;
task t6110(intakedecide); //avoids blue rings and keeps going till red in intake

FrontstraightVisionST(1500, 170, 8, 6, 5, 0, 2000);  //$$$$$$2nd LB intake
T1.clear();                        //wait for 2nd LB ring to go into intake
while(L==0 && T1.value()<2)  
{

}
doinkL.open(); //donker down
frontdistanceNew(16, 355, 10, 0, 1, 0, 2000);  //drive forward to sweep

chassis.turn_to_angle(140);    //sweep
chassis.drive_timeout = 1000;
chassis.drive_distance(-24);  // back up to drop off goal

task::stop(autoclamp); 

backClaw.close();            //open claw to drop
task::stop(intakedecide);
intake.spin(fwd, 100, pct);
wait(0.1,sec);
intake.stop();

chassis.drive_distance(26); 
chassis.turn_to_angle(0);
goalexit=true;
task t7161(autoclamp); 
scanB(300, -5);
//BackturnVisionST(172, 10, 10, 10, 100, 1000);
BackstraightVisionST(-1900, 100, 6, 3, 5, 0, 2000); //$$$2ndgoal
chassis.turn_to_angle(0);
backdistanceNew(68, 0, 9, 0, 1, 200, 2000); // back into postition
chassis.turn_to_angle(270); //turn into alliance stake
frontdistanceNew(14, 270, 8, 0, 1, 0, 3000);  // drive towards alliance stake

//chassis.drive_timeout = 600;
//chassis.drive_distance(20); 
task::stop(armPID);
T1.clear();
while(rotationARM.position(degrees)<=190 && T1.value()<1)             // 3rd ring on stake
      {
        ringliftL.spin(fwd, 100, pct);
        ringliftR.spin(fwd, 100, pct);
        printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
      }
      ringliftL.stop(hold);
      ringliftR.stop(hold); 
      
wait(300, msec);
aspeed = 12;
adesiredValue = 40;
task t64174(armPID);
wait(0.5, sec);
L=0;
g=0;
task t61031(intakeringLB2);
T1.clear();                        //wait for 2nd ring into LB
while(L==0 && T1.value()<2)  
{

}
task::stop(intakeringLB2);
intake.stop(); 
chassis.drive_timeout = 2000;
task::stop(armPID); 


T1.clear();
 while(rotationARM.position(degrees)<=190 && T1.value()<1)   // 2nd ring on stake
      {
        ringliftL.spin(fwd, 100, pct);
        ringliftR.spin(fwd, 100, pct);
        printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
      }
      ringliftL.stop(hold);
      ringliftR.stop(hold);

intake.spin(reverse, 100, pct);

frontdistanceNew(17.5, 270, 12, 8, 1, 0, 2000); //back up a bit

aspeed = 12;
adesiredValue = 1;
task t6799194(armPID);              //arm back down
chassis.turn_to_angle(50);    //85turn toward 4th ring
//task t3141(antijam);
task t647004(intakeRung);

breakdistance = 350;
breakout = true;
FrontstraightVisionST(1350, 170, 12, 8, 5, 0, 3000); //$$$$$$$1string
breakout = false;
FrontdistanceVisionST(1, 170, 12, 8, 1, 0, 3000);
chassis.drive_max_voltage = 8;
waitforring = true;
chassis.drive_distance(1);
waitforring = false;

chassis.turn_max_voltage = 5;
chassis.turn_to_angle(125);      // turn to go under bar
chassis.drive_max_voltage = 12;
task::stop(armPID); 
task::stop(intakeRung);              //stop intake
intake.stop();


//breakdistance = 350;
//breakout = true;
//FrontstraightVisionST(1000, 170, 12, 8, 5, 0, 3000); //$$$$$$$2nd ring under bar push
breakout = false;
FrontdistanceVisionST(6, 170, 12, 8, 1, 0, 3000);
chassis.drive_min_voltage = 5;
chassis.drive_distance(16, 125);
task t614(intakeRung);
waitforring = true;
chassis.drive_distance(6, 125);
waitforring = false;
 
//allMtrsStop(); //take out
//wait(2, sec); //take out
//breakdistance = 350;
//breakout = true;
//waitforring = false;
//FrontstraightVisionST(1000, 170, 12, 8, 5, 0, 3000); //$$$$$$$1string
//breakout = false;
task::stop(intakeRung); 

FrontdistanceVisionST(5, 170, 12, 8, 1, 0, 3000);
task t381(antijam);
waitforring = true;
chassis.drive_distance(8, 125);

//multipleobjectsF = true;
//FrontstraightVisionST(2000, 170, 12, 8, 5, 0, 3000); 
//allMtrsStop(); //take out
//wait(2, sec); //take out

breakdistance = 350;
breakout = true;
waitforring = false;
FrontstraightVisionST(1000, 170, 12, 8, 5, 0, 3000); //$$$$$$$1string
breakout = false;

FrontdistanceVisionST(1, 170, 12, 8, 1, 0, 3000);

//g=0;
//FrontstraightVisionST(1700, 170, 6, 5, 5, 0, 4000);
//allMtrsStop(); //take out
//wait(2, sec); //take out

//multipleobjectsF = false;
//waitforring = true;
//FrontdistanceVisionST(1, 170, 12, 8, 1, 0, 3000);
//allMtrsStop(); //take out
//wait(2, sec); //take out
chassis.turn_to_angle(95); 

multipleobjectsL = true;
FrontdistanceVisionWall(15, 170, 8, 6, 0.5, 0, 3000); 
multipleobjectsR = false;
//waitforring = true;
frontdistanceNew(8, 90, 12, 0, 1, 0, 2000); //$$$$$5th and 6th


wait(1, sec); //take out
chassis.turn_settle_time = 0;
chassis.turn_timeout = 2000;
chassis.turn_max_voltage = 6;
chassis.turn_to_angle(215); //215
task::stop(armPID);

//g=0;
earlyexit = true;
FrontstraightVisionST(1000, 170, 12, 6, 5, 0, 2000);  //$$$$$$7th ring

chassis.drive_timeout = 500;
chassis.drive_min_voltage = 5;
chassis.drive_distance(4);       //go a bit further to 7th
chassis.turn_timeout = 1200;
chassis.turn_max_voltage = 12;
chassis.turn_to_angle(325);   //turn to drop off goal 325
chassis.drive_timeout = 1000;
chassis.drive_distance(-24);  // back up to drop off goal

task::stop(autoclamp); 

backClaw.close();            //open claw to drop
task::stop(antijam);
intake.spin(fwd, 100, pct);
wait(0.5,sec);
intake.stop();

//wait(30000000000,sec);

chassis.turn_max_voltage = 12;
chassis.turn_timeout = 2000;
chassis.drive_timeout = 2000;
chassis.drive_min_voltage = 8;
chassis.drive_max_voltage = 12;
chassis.drive_distance(5.5, 325); //bee line away turning at same time
chassis.turn_to_angle(180); 


chassis.turn_settle_time = 0;


goalexit=true;
task t71091(autoclamp); 
scanB(300, 5);
//BackturnVisionST(172, 10, 10, 10, 100, 1000);
BackstraightVisionST(-1900, 100, 6, 3, 5, 0, 2000); //$$$2ndgoal
frontdistanceNew(40, 180, 9, 5, 1, 0, 2000);
//wait(0.25, sec);

aspeed = 12;
adesiredValue = 40;
task t4794(armPID);      //1st LB ring
g=0;
L=0;
task t61301(intakeringLB); 

chassis.turn_settle_time = 0;
chassis.turn_to_angle(225);
scanF(300, 5);
//breakdistance = 350;
//breakout = true;
//FrontstraightVisionST(1000, 170, 12, 8, 5, 0, 3000); //$$$$$$$1st ring
//breakout = false;
FrontdistanceVisionST(1, 170, 12, 8, 1, 0, 3000);//$$$$$ 1st ring

//chassis.drive_distance(8);
chassis.turn_to_angle(240);     //turn towards 2nd ring 225
allMtrsStop();

T1.clear();                        //wait for 1st ring
while(L==0 && T1.value()<2)  
{

}
task::stop(intakeringLB); 
intake.stop();

L=0;
g=0;
task t65631(intakering2);
scanF(300, 5);
FrontdistanceVisionST(1, 170, 12, 8, 1, 0, 3000);//$$$$$ 2nd ring
chassis.left_swing_to_angle(180);
chassis.drive_timeout = 600;
chassis.drive_distance(20,180); 

task::stop(armPID);
T1.clear();
while(rotationARM.position(degrees)<=180 && T1.value()<1.5)   // 1st LB ring on stake
      {
        ringliftL.spin(fwd, 100, pct);
        ringliftR.spin(fwd, 100, pct);
        printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
      }
      ringliftL.stop(hold);
      ringliftR.stop(hold); 
      

wait(100, msec);
aspeed = 12;
adesiredValue = 40;
task t6674(armPID);
T1.clear();                        //wait for 2nd LB ring to get into intake
while(L==0 && T1.value()<3)  
{
      
}
task::stop(intakering2);
intake.stop(); 
wait(0.8, sec);
L=0;
g=0;
task t6131(intakeringLB2);
T1.clear();                        //wait for 2nd LB ring to go into LB
while(L==0 && T1.value()<2)  
{

}
task::stop(intakeringLB2);
intake.stop(); 
chassis.drive_timeout = 2000;
task::stop(armPID); 


T1.clear();
 while(rotationARM.position(degrees)<=180 && T1.value()<1.5)   // 4th ring on stake
      {
        ringliftL.spin(fwd, 100, pct);
        ringliftR.spin(fwd, 100, pct);
        printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
      }
      ringliftL.stop(hold);
      ringliftR.stop(hold);



frontdistanceNew(17.5, 0, 12, 8, 1, 0, 2000); //back up a bit 180 

wait(3000000000000, sec);
////$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$/mirror
g=0;
h=0;
task t7160091(intakex); 

chassis.turn_settle_time = 0;
chassis.turn_to_angle(250);      //turn to 1st ring
scanF(500, -5);


earlyexit = true;
breakdistance = 350;
breakout = true;
FrontstraightVisionST(1000, 170, 12, 8, 5, 0, 3000); //$$$$$$$1st ring
breakout = false;
FrontdistanceVisionST(1, 170, 12, 8, 1, 0, 3000);//$$$$$ 1st ring

chassis.drive_min_voltage = 5;
chassis.drive_distance(2);       //after grabbing 1st ring$$$$$$$$


chassis.turn_to_angle(315); //turn to go to 2nd ring


chassis.drive_min_voltage = 5;
chassis.drive_max_voltage = 12;
chassis.drive_distance(18); 
task::stop(intakex);
chassis.turn_to_angle(310); 


aspeed = 12;
adesiredValue = 40;
task t64767194(armPID);      //LB for 2nd ring
g=0;
L=0;
task t61171301(intakeringLB); 

multipleobjectsL = true;
multipleobjectsR = false;
breakdistance = 350;
breakout = true;
FrontstraightVisionST(1800, 170, 12, 8, 5, 0, 3000); //$$$$$$$2nd ring
breakout = false;
FrontdistanceVisionST(1, 170, 12, 8, 1, 0, 3000);
chassis.drive_max_voltage = 8;
chassis.drive_distance(1);
lBase1.stop(hold);
lBase2.stop(hold);
lBase3.stop(hold);
rBase1.stop(hold);
rBase2.stop(hold);
rBase3.stop(hold);

//wait(0.5, sec);

T1.clear();                        //wait for 2nd ring
while(L==0 && T1.value()<2)  
{

}
task::stop(intakeringLB);
task t64611704(colorsortAuto);

multipleobjectsR = true;
multipleobjectsL = false;

g=0;
FrontstraightVisionST(2500, 170, 6, 0, 5, 0, 2000); //$$$$$$$2nd ring
//chassis.drive_max_voltage = 3;
frontdistanceNew(22, 270, 5, 0, 1, 0, 3000);
frontdistanceNew(24, 270, 5, 3, 1, 0, 3000); 
chassis.turn_to_angle(319);
frontdistanceNew(24, 319, 10, 5, 2, 0, 3000); //24
chassis.turn_to_angle(270);
backdistanceNew(70, 270, 10, 0, 1, 200, 3000);
chassis.turn_to_angle(0);
task::stop(colorsortAuto);
L=0;
g=0;
task t6117631(intakering2);
frontdistanceNew(10, 0, 8, 0, 1, 0, 3000);  //drive toward wall stake

T1.clear();                        //wait for 2nd ring
while(L==0 && T1.value()<4)  
{

}

chassis.drive_timeout = 600;
chassis.drive_distance(20); 
task::stop(armPID);
T1.clear();
while(rotationARM.position(degrees)<=160 && T1.value()<1)             // 3rd ring on stake
      {
        ringliftL.spin(fwd, 100, pct);
        ringliftR.spin(fwd, 100, pct);
        printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
      }
      ringliftL.stop(hold);
      ringliftR.stop(hold); 
      task::stop(intakering2);
wait(300, msec);
aspeed = 12;
adesiredValue = 40;
task t64116174(armPID);
wait(0.5, sec);
L=0;
g=0;
task t6117031(intakeringLB);
T1.clear();                        //wait for 2nd ring
while(L==0 && T1.value()<4)  
{

}
task::stop(intakeringLB);
intake.stop(); 
chassis.drive_timeout = 2000;
task::stop(armPID); 


T1.clear();
 while(rotationARM.position(degrees)<=160 && T1.value()<1)   // 3rd ring on stake
      {
        ringliftL.spin(fwd, 100, pct);
        ringliftR.spin(fwd, 100, pct);
        printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
      }
      ringliftL.stop(hold);
      ringliftR.stop(hold);

 lbp.close();  

//intake.spin(fwd, 100, pct);
frontdistanceNew(17.5, 0, 12, 8, 1, 0, 2000); //back up a bit



task::stop(armNoPID);
aspeed = 12;
adesiredValue = 0;
task t641174(armPID);              //arm back down
chassis.turn_to_angle(85);    //85turn toward 4th ring

g=0;
task t64074(intakex); 

scanF(300, 5);
//FrontturnVisionST(170, 10, 10, 10, 0, 1000); // $$$$$$$$measure lock in
g=0;
FrontstraightVisionST(2500, 200, 10, 6, 5, 0, 2000); //$$$4th ring

frontdistanceNew(20, 85, 12, 10, 1, 0, 1500);
frontdistanceNew(6, 85, 5, 0, 1, 0, 2000); //$$5th and 6th
wait(0.5, sec);
chassis.turn_max_voltage = 6;
chassis.turn_to_angle(325); 
task::stop(armPID);


g=0;
FrontstraightVisionST(1000, 200, 12, 6, 5, 0, 2000); //$$7th ring

chassis.turn_max_voltage = 12;
chassis.drive_timeout = 500;
chassis.drive_min_voltage = 5;
chassis.drive_distance(4);       //go a bit further to 7th


chassis.turn_to_angle(215);   //turn to drop off goal
chassis.drive_timeout = 1000;
chassis.drive_distance(-24);  // back up to drop off goal

task::stop(autoclamp); 

backClaw.close();            //open claw to drop
task::stop(intakex);
intake.spin(fwd, 100, pct);
wait(0.5,sec);
task t6107531(intakex);



//$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$mirror end


//begin far side

chassis.drive_timeout = 2000;
chassis.drive_min_voltage = 8;
chassis.drive_max_voltage = 12;
chassis.drive_distance(45,260); //drive to far point on the field
task::stop(intakex);
intake.stop();

aspeed = 12;
adesiredValue = 40;
task t6497114(armPID);      //LB for 1st ring
g=0;
L=0;
task t6167531(intakeringLB);

chassis.drive_distance(12,220); // $$$$1 far side ring 

earlyexit = true;                   
FrontstraightVisionST(2000, 200, 10, 6, 5, 0, 2000); // $$$$1 far side ring
chassis.drive_min_voltage = 0;
chassis.drive_distance(1);  


task t761621(autoclamp);

chassis.turn_to_angle(45); //turn around to face goal

T1.clear();                        //wait for 1st ring
while(L==0 && T1.value()<1)
{

}

task::stop(intakeringLB);

scanB(300, 5);
BackstraightVisionST(-1800, 100, 6, 5, 5, 0, 2000); //$$$goal

chassis.drive_distance(-4);


chassis.turn_max_voltage = 10;
chassis.turn_to_angle(120); // turn to ring $$$$$$2
adesiredValue = 160;       //arm all the way up


g=0;
L=0;

task t66209(intakeProceed2);
FrontstraightVisionST(3000, 200, 12, 6, 5, 0, 2000); // $$$$2 far side ring
chassis.drive_min_voltage = 5;
chassis.drive_distance(-1); 

chassis.turn_to_angle(190);
scanF(300, 5);

T1.clear();                        //wait for 2nd ring
while(L==0 && T1.value()<1)
{

}
task::stop(intakeProceed2);

g=0;
L=0;
task t669209(intakeProceed2);
FrontstraightVisionST(3000, 200, 12, 6, 5, 0, 2000);  //$$$$$$3rd

chassis.turn_max_voltage = 12;
chassis.turn_to_angle(220); // turn to ring $$$$$$3
chassis.drive_distance(6); 
scanF(300, 5);

T1.clear();                        //wait for 3rd ring
while(L==0 && T1.value()<1)
{

}
task::stop(intakeProceed2);
g=0;
L=0;
task t6692079(intakeProceed2);
FrontstraightVisionST(3000, 200, 8, 6, 5, 0, 2000); // $$$$4th ring
frontdistanceNew(32, 270, 12, 0, 1, 0, 1500); //back up from 4th ring, was 16

T1.clear();                        //wait for 4th ring
while(L==0 && T1.value()<1.5)
{

}
task::stop(intakeProceed2);

scanF(500, 5);
g=0;
L=0;
task t66972079(intakeProceed2);
FrontstraightVisionST(3000, 200, 8, 6, 5, 0, 2000); // $$$$4th ring
frontdistanceNew(16, 270, 12, 0, 1, 0, 1500); //back up from 4th ring, was 16


chassis.turn_to_angle(200);  //turn to start sweep
task::stop(intakeProceed2);
intake.stop();
doinkR.open(); //donker down
doinkL.open();
chassis.drive_timeout = 750;
chassis.drive_distance(8, 250); 

chassis.turn_min_voltage = 6;
chassis.turn_to_angle(350);
chassis.turn_min_voltage = 0;
chassis.turn_to_angle(65); //sweep



chassis.turn_to_angle(50); //sweep 40
backClaw.close();         //drop goal
doinkL.close(); //donker up
doinkR.close(); //donker up
intake.stop();

adesiredValue = 31;     //bring lb down
lbp.close();  
L=0;
task t60169(intakeTime);  //start ring down into intake

chassis.drive_max_voltage = 8;
chassis.drive_timeout = 700;
chassis.drive_distance(-24);  //shove goal
chassis.drive_distance(10, 40);  //come back out
task::stop(autoclamp);
backClaw.open();                //close claw
chassis.drive_max_voltage = 7;
chassis.drive_timeout = 700;
chassis.drive_distance(-24);  //shove goal

chassis.drive_timeout = 2000;
chassis.drive_max_voltage = 8;
chassis.drive_min_voltage = 4;
chassis.drive_distance(18, 40);  //drive out


chassis.turn_to_angle(325); // turn to blue stake


distanceexit = false;
chassis.drive_distance(10);; //go a bit further to blue
chassis.turn_to_angle(0); 
adesiredValue = 0; //lb all the way down
task::stop(intakeTime);
intake.stop();
backdistanceNew(66, 0, 8, 0, 0.8, 300, 3000); // $$blue lineup

chassis.drive_max_voltage = 8;
chassis.turn_to_angle(85); 
backdistanceNew(4, 85, 8, 0, 1, 100, 3000); //$$ blue linup

intake.spin(reverse, 100, pct);  //$$ ring onto blue
wait(0.8, sec);

chassis.drive_min_voltage = 8;
chassis.drive_max_voltage = 12;

chassis.drive_distance(6); //drive out a bit
chassis.turn_to_angle(340); // turn to 4th goal
chassis.drive_timeout = 1200;
intake.stop();
chassis.drive_distance(67, 340); // shove 4th
intake.spin(fwd, 100, pct);
chassis.turn_to_angle(310); //turn to bar
adesiredValue = 150;  //lb all the way up
chassis.drive_max_voltage = 12;
chassis.drive_distance(-38); // bar
intake.stop();
chassis.drive_max_voltage = 2;
chassis.drive_distance(-20); //bar slower
chassis.drive_max_voltage = 3;
chassis.drive_distance(4); //
adesiredValue = 60;  //lb all the way up

 


wait(30000000,sec); 
////$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$new end







//$$$$$$$$$$$NewSkills

Inertial20.setHeading(150, deg);
chassis.set_coordinates(0, 0, 150);  
greengoalb=true;
redring = true;
redringi = true;
g=0;
intake.setPosition(0, degrees);


//test
earlyexit = true;
g=0;

intake.spin(reverse, 100, pct);
wait(0.5, sec);            //red stake

task t7121(autoclamp); 
chassis.left_swing_to_angle(359);

BackdistanceVisionST(85, 150, 8, 7, 5, 0, 3000); //$$$goal
distanceBackInertialST(850, 0, 10, 5, 0, 3000); 
wait(0.25, sec);

g=0;
task t61469(intakeRung); 

chassis.turn_to_angle(300);      //turn to 1st ring

lBase2.setPosition(0, degrees);
earlyexit = true;
FrontstraightVisionST(1800, 190, 12, 0, 5, 0, 3000); //1500 to first ring
z = Inertial20.heading();
if(lBase2.position(degrees)>=1790)  //failsafe if early exit too late
 {
  driveStraightInertialST(1600, z, 8, 4, 3, 0, 3000); //backup
  
 }
chassis.drive_min_voltage = 8; 
chassis.left_swing_to_angle(325);//possibly swing
*/
/*
T1.clear();
while(g==0 && T1.value()<2);
{

}
*/



lBase2.setPosition(0, degrees);
earlyexit = false;
FrontstraightVisionST(600, 190, 10, 7, 5, 0, 3000); //under rung
task::stop(intakeRung); 
g=0;
intake.spin(reverse, 100, pct);
task t71446(intakeRung);

earlyexit = true; 
lBase2.setPosition(0, degrees);
FrontstraightVisionST(1000, 190, 12, 0, 5, 0, 3000); //2nd ring
z = Inertial20.heading();
if(lBase2.position(degrees)>=610)  //failsafe if early exit too late
 {
  driveStraightInertialST(600, z, 8, 4, 3, 0, 3000); //backup
 }

 chassis.drive_min_voltage = 8; 
 chassis.turn_to_angle(225); //turn to 3rd

 lBase2.setPosition(0, degrees);
 earlyexit = false; 
 FrontstraightVisionST(1000, 190, 10, 7, 5, 0, 3000); //under rung 1300
 task::stop(intakeRung); 
 intake.spin(reverse, 100, pct);

 lBase2.setPosition(0, degrees);
 earlyexit = true;
 FrontstraightVisionST(800, 190, 10, 7, 5, 0, 3000); //3rd ring 600
 if (ring.objectDistance(mm)>0 && ring.objectDistance(mm)<=90)
 {
  wait(1, sec);
 }
 chassis.turn_to_angle(170);

 speed = 12;
 desiredValue = 35;
 task t641741(armPID);                                  //LB
 g=0;
 task t611331(intakeringLB);
 lBase2.setPosition(0, degrees);
 earlyexit = false;
 FrontstraightVisionST(1000, 190, 10, 7, 5, 0, 3000);  // $$$ 4th ring LB
 distanceFrontInertialST(120, 180, 10, 3, 0, 3000);  //get into postition
 distanceFrontInertialST(175, 180, 10, 3, 0, 3000);  //get into postition
 chassis.turn_to_angle(90);

 task::stop(intakeringLB);
 lbp.open();
 desiredValue = 60;  // move arm up

 g=0;                                                //reset escape varialbe
 task t619941(intakering);    // stop 5th ring at distance sensor

 lBase2.setPosition(0, degrees);
 FrontstraightVisionST(1200, 190, 10, 7, 5, 0, 3000);  // $$$ 5th ring LB
 chassis.turn_to_angle(90);
 distanceFrontInertialST(1690, 90, 10, 3, 100, 3000);  //get into postition
 chassis.turn_to_angle(180); //turn toward wall stake
                            
 distanceFrontInertialST(240, 180, 10, 3, 100, 3000);  // drive to stake
 task::stop(armPID); 
 while(rotationARM.position(degrees)<=150)             // 4th ring on stake
      {
        ringliftL.spin(fwd, 100, pct);
        ringliftR.spin(fwd, 100, pct);
        printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
      }
      ringliftL.spin(fwd, 0, pct);
      ringliftR.spin(fwd, 0, pct);
 task::stop(intakering); 
 lbp.close();  
 desiredValue = 35;
 task t69831(armPID);                                   //5th ring LB
 
 wait(0.5, sec);
 g=0;
 task t619731(intakeringLB);
 wait(0.5, sec);
 lbp.open();

 task::stop(intakeringLB);
 task::stop(armPID); 
 while(rotationARM.position(degrees)<=150)            //5th ring stake
      {
        ringliftL.spin(fwd, 100, pct);
        ringliftR.spin(fwd, 100, pct);
        printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
      }
      ringliftL.spin(fwd, 0, pct);
      ringliftR.spin(fwd, 0, pct);
      lbp.close();
 task t619631(armPID);                                   // arm back to starting pos
 desiredValue = 0;

wait(30000000, sec);

//$$$$$$$$$$$$$$$End




Inertial20.setHeading(270, deg);
chassis.set_coordinates(0, 0, 270);  
greengoalb=true;
redring = true;

g=0;
intake.setPosition(0, degrees);
task t736(intakestop);
intake.spin(reverse, 100, pct);

wait(0.5, sec);

 //chassis.turn_to_angle(0);
 task t721(autoclamp); 
 chassis.left_swing_to_angle(359);
 //distanceBackInertialST(650, 0, 8, 5, 100, 3000); //$$$$goal
 BackdistanceVisionST(85, 150, 8, 6, 5, 0, 3000); //$$$goal
 distanceBackInertialST(850, 0, 10, 5, 0, 3000); 
 wait(0.25, sec);
 //task t646(intakering);
 //driveStraightInertialST(3000, 270, 8, 4, 15, 0, 5000); // 1st ring
 chassis.turn_to_angle(270);
 FrontstraightVisionST(1500, 150, 10, 0, 5, 100, 3000);
 chassis.drive_max_voltage = 5 ;
 chassis.drive_distance(4);
 task t754(intakestop2);
 //wait(3,sec);
 FrontstraightVisionST(1300, 150, 10, 7, 5, 0, 3000); //under rung
 task::stop(intakestop2); 
 g=0;
 intake.spin(reverse, 100, pct);
 //task t744(intakestop2);
 FrontstraightVisionST(500, 150, 10, 0, 5, 100, 3000); //2nd ring
 task t7446(intakestop2);
 chassis.turn_to_angle(235); //turn to 3rd
 FrontstraightVisionST(1300, 150, 10, 7, 5, 0, 3000); //under rung
 task::stop(intakestop2); 
 intake.spin(reverse, 100, pct);
 FrontstraightVisionST(600, 150, 10, 0, 5, 100, 3000); //3rd ring
 wait(1, sec);
 chassis.turn_to_angle(180);

 speed = 12;
 desiredValue = 31;
 task t64741(armPID);                                  //LB
 g=0;
 task t61331(intakeringLB);
 FrontstraightVisionST(1200, 150, 10, 0, 5, 100, 3000);  // $$$ 4th ring LB
 wait(0.5, sec);
 lbp.open();
 
 driveStraightInertialST(-800, 125, 8, 4, 15, 0, 3000); //backup
 driveStraightInertialST(-500, 90, 8, 4, 15, 0, 3000);
 distanceBackInertialST(1620, 90, 10, 3, 100, 3000);  //get into postition
 
 task::stop(intakeringLB);
 desiredValue = 60;                                  // move arm up
 chassis.turn_to_angle(180); 
 
 g=0;                                                //reset escape varialbe
 task t69941(intakering);                              // stop 5th ring at distance sensor
 distanceFrontInertialST(200, 180, 10, 3, 100, 3000);  // drive to stake
 task::stop(armPID); 
 while(rotationARM.position(degrees)<=150)             // 4th ring on stake
      {
        ringliftL.spin(fwd, 100, pct);
        ringliftR.spin(fwd, 100, pct);
        printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
      }
      ringliftL.spin(fwd, 0, pct);
      ringliftR.spin(fwd, 0, pct);
 task::stop(intakering); 
 lbp.close();  
 desiredValue = 35.5;
 task t691831(armPID);                                   //5th ring LB
 
 wait(0.5, sec);
 g=0;
 task t69731(intakeringLB);
 wait(0.5, sec);
 lbp.open();

 task::stop(intakeringLB);
 task::stop(armPID); 
 while(rotationARM.position(degrees)<=150)            //5th ring stake
      {
        ringliftL.spin(fwd, 100, pct);
        ringliftR.spin(fwd, 100, pct);
        printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
      }
      ringliftL.spin(fwd, 0, pct);
      ringliftR.spin(fwd, 0, pct);
      lbp.close();
 task t69631(armPID);                                   // arm back to starting pos
 desiredValue = 0;








 wait(30000000, sec);
 
 chassis.drive_min_voltage = 3;
 chassis.drive_settle_error = 3;
 chassis.drive_settle_time = 0;
 chassis.drive_distance(20, 260);
 
 chassis.drive_min_voltage = 3;
 chassis.drive_settle_error = 3;
 chassis.drive_settle_time = 0;
 //driveStraightInertialST(500, 300, 8, 4, 15, 0, 5000); //drive under rung
 chassis.drive_distance(24, 350);
 task::stop(intakering); 
 intake.stop(); 
 g=0;
 task t649(intakering2);
 chassis.drive_min_voltage = 0;
 chassis.drive_settle_error = 2;
 chassis.drive_settle_time = 100;
 chassis.drive_to_point(80, 72); //$$$ 2nd ring
 chassis.turn_to_angle(225);                          //turn to 3rd ring
 task::stop(intakering2);
 intake.stop(); 
 wait(0.5, sec);
 SetToGPS();                                            //reset to GPS
 wait(30000000, sec);

 driveStraightInertialST(500, 225, 8, 4, 15, 0, 5000); //drive under rung
 intake.spin(reverse, 100, pct);
 driveStraightInertialST(1000, 225, 8, 4, 15, 0, 5000);  // $$$$ 3rd ring
               
 speed = 12;
 desiredValue = 31;
 task t6474(armPID);                                  //LB
 
 task t6133(intakeringLB);
 chassis.drive_to_point(44, 11);                     // $$$ 4th ring LB
 lbp.open();
 driveStraightInertialST(-800, 125, 8, 4, 15, 0, 3000); //backup
 driveStraightInertialST(-500, 90, 8, 4, 15, 0, 3000);
 distanceBackInertialST(1500, 90, 10, 3, 100, 3000);  //get into postition
 
 task::stop(intakeringLB);
 desiredValue = 60;                                  // move arm up
 chassis.turn_to_angle(180); 
 
 g=0;                                                //reset escape varialbe
 task t6994(intakering);                              // stop 5th ring at distance sensor
 distanceFrontInertialST(200, 180, 10, 3, 100, 3000);  // drive to stake
 task::stop(armPID); 
 while(rotationARM.position(degrees)<=150)             // 4th ring on stake
      {
        ringliftL.spin(fwd, 100, pct);
        ringliftR.spin(fwd, 100, pct);
        printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
      }
      ringliftL.spin(fwd, 0, pct);
      ringliftR.spin(fwd, 0, pct);
 task::stop(intakering); 
 lbp.close();  
 desiredValue = 35.5;
 task t6983(armPID);                                   //5th ring LB
 
 wait(0.5, sec);
 g=0;
 task t6973(intakeringLB);
 wait(0.5, sec);
 lbp.open();

 task::stop(intakeringLB);
 task::stop(armPID); 
 while(rotationARM.position(degrees)<=150)            //5th ring stake
      {
        ringliftL.spin(fwd, 100, pct);
        ringliftR.spin(fwd, 100, pct);
        printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
      }
      ringliftL.spin(fwd, 0, pct);
      ringliftR.spin(fwd, 0, pct);
      lbp.close();
 task t6963(armPID);                                   // arm back to starting pos
 desiredValue = 0;



wait(30000000, sec);













   //Inertial20.calibrate();
/*
   task t700(ledpinkj);
   wait(5, sec);
   task::stop(ledpinkj);
   task t701(ledrainbowj);
   wait(5, sec);
   task::stop(ledrainbowj);
   task t702(ledpurplej);
   wait(5, sec);
   task::stop(ledpurplej);
   task t703(bangarang);
   */
   
/*

GPS8.calibrate();
  // waits for Inertial Sensor to calibrate 
  while (Inertial20.isCalibrating()) {
    wait(100, msec);
  }
  //inertialPIDfuntionST(90, 12, 2, 0, 150000); ///$$$$$$$$$$$$$$$$$$$$
 
 // read_GPS_coordinatesOrigin();

  Inertial20.setHeading(180, deg);
  //Inertial20.setHeading(0, deg);

  chassis.set_coordinates(0, 0, 180);
  //chassis.set_coordinates(0, 0, 0);
  wait(1000, msec);
  */
/*
speed = 12;
desiredValue = 35.5;
task t620(armPID);

task t621(intakeringLB);
chassis.drive_distance(12); 
//task t622(intakering);

//task t628(intakering2);
//intake.spin(reverse, 100, pct); 
//speeds = 3;
driveStraightInertialST(3000, 180, 11, 4, 15, 0, 5000); //forward is positive desired value 
//speeds = 0;
driveStraightInertialST(3000, 225, 11, 0, 2, 100, 3000);
wait(3000000,sec);

driveStraightInertialST(-3000, 180, 11, 4, 15, 0, 5000); //backward is negative desired value, angle is always in relation to the front of the robot
//speeds = 0;
driveStraightInertialST(-3000, 125, 11, 0, 2, 100, 3000);
wait(3000000,sec);

chassis.drive_min_voltage = 6;
chassis.drive_settle_error = 10;
chassis.drive_settle_time = 0;
//chassis.drive_distance(72, 180); 
chassis.drive_to_point(GXO, 72);
//chassis.drive_distance(24, 225); 
chassis.drive_settle_time = 100;
chassis.drive_settle_error = 2;
chassis.drive_min_voltage = 0;
chassis.drive_distance(48, 225); 
//chassis.drive_to_point(48, 12);
wait (3, sec);
printf("DONE: ------------------------------------\n");
//distanceFrontInertialST(200, 0, 10, 3, 50000, 50000);
//distanceBackInertialST(200, 180, 10, 3, 100, 3000);
*/
/*
GPSAngleDistance(48,48); // 96, 48; 48, 48; 48, 96
printf("GPSAngle %0.1f\tGPSDistance %0.1f\tquality %d\tGheading %0.1f\tIheading %0.1f\n",GPSturnAngle, GPSdriveDistance, GPS8.quality(), GPS8.heading(deg), Inertial20.heading());
wait(1, sec);
chassis.drive_distance(GPSdriveDistance, GPSturnAngle); 
printf("GPSAngle %0.1f\tGPSDistance %0.1f\tquality %d\tGheading %0.1f\tIheading %0.1f\n",GPSturnAngle, GPSdriveDistance, GPS8.quality(), GPS8.heading(deg), Inertial20.heading());
wait(0.75, sec);
GPSAngleDistance(72,72);
chassis.drive_distance(GPSdriveDistance, GPSturnAngle); 
printf("GPSAngle %0.1f\tGPSDistance %0.1f\tquality %d\tGheading %0.1f\tIheading %0.1f\n",GPSturnAngle, GPSdriveDistance, GPS8.quality(), GPS8.heading(deg), Inertial20.heading());
*/
/*
g=0;
task t911(intakestop); 
intake.spin(reverse, 95, pct);
wait(3, sec);
task t912(intakestop2); 
//chassis.drive_distance(72, 180);
*/
/*
g=0;
task t118(autoclamp);
wait(1, sec);
bluering=true;
//intake.spin(reverse, 50, pct);
task t518(colorsortAuto);
//BackstraightVisionST(-800, 160, 8, 0, 3, 0, 3000);
//FrontstraightVisionST(1000, 160, 8, 0, 3, 0, 3000);
//FrontdistanceVisionST(90, 160, 8, 4, 10, 0, 3000);
//wait(0.5, sec);
//FrontstraightVisionST(1000, 160, 8, 0, 3, 0, 3000);
//FrontdistanceVisionST(90, 160, 8, 4, 10, 0, 3000);
wait(3000000, sec);

BackstraightVisionST(500, 160, 0, 0, 3, 50000, 50000);

//wait(3000000, sec);

*/
//$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
//Auton

 //FrontstraightVisionST(-1000, 160, 8, 0, 3, 100, 3000);
 //wait(3000000,sec);
 
 
 
 
 /*
 
 greengoal=true;
 
 distanceFrontInertialST(1730, 180, 12, 5, 100, 2000);  // drive to stake
 chassis.turn_to_angle(270);
 distanceBackInertialST(110, 270, 12, 5, 0, 2000);
 intake.spin(reverse, 100, pct);
 wait(.75,sec);
 intake.stop();
 
 chassis.right_swing_to_angle(100);
 //wait(0.5, sec);
 task t108(autoclamp);
 
 BackstraightVisionST(-1000, 160, 8, 0, 8, 0, 3000);
 z = Inertial20.heading();
 driveStraightInertialST(-800, z, 8, 0, 4, 100, 2000);

 chassis.turn_to_angle(180);
 redring = true;
 blueringi = true;
 task t518(colorsortAuto);
 FrontstraightVisionST(200, 160, 7, 0, 5, 0, 3000);
 z = Inertial20.heading();
 driveStraightInertialST(800, z, 8, 0, 3, 100, 3000);
 chassis.turn_to_angle(270);
 distanceBackInertialST(1445, 270, 12, 5, 300, 2000);
 distanceBackInertialST(1000, 270, 12, 5, 0, 1500);
 doinkL.open();
 chassis.drive_distance(12, 325);
 //chassis.drive_to_point(115, 50);
/*
 chassis.turn_to_angle(225);
 chassis.drive_to_point(90, 38);
 chassis.turn_to_angle(180);
 */

 wait(3000000, sec);






//$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$4
//NEW Skills Below


intake.spin(reverse, 100, pct);
 //chassis.drive_to_point(122, GYO);
 wait(0.5, sec);

 //chassis.turn_to_angle(0);
 task t711(autoclamp); 
 chassis.left_swing_to_angle(350);
 distanceBackInertialST(650, 0, 8, 5, 100, 3000); //$$$$goal
 task t636(intakering);
 //driveStraightInertialST(3000, 270, 8, 4, 15, 0, 5000); // 1st ring
 chassis.drive_min_voltage = 3;
 chassis.drive_settle_error = 3;
 chassis.drive_settle_time = 0;
 chassis.drive_distance(20, 260);
 
 chassis.drive_min_voltage = 3;
 chassis.drive_settle_error = 3;
 chassis.drive_settle_time = 0;
 //driveStraightInertialST(500, 300, 8, 4, 15, 0, 5000); //drive under rung
 chassis.drive_distance(24, 350);
 task::stop(intakering); 
 intake.stop(); 
 g=0;
 task t639(intakering2);
 chassis.drive_min_voltage = 0;
 chassis.drive_settle_error = 2;
 chassis.drive_settle_time = 100;
 chassis.drive_to_point(80, 72); //$$$ 2nd ring
 chassis.turn_to_angle(225);                          //turn to 3rd ring
 task::stop(intakering2);
 intake.stop(); 
 wait(0.5, sec);
 SetToGPS();                                            //reset to GPS
 wait(30000000, sec);

 driveStraightInertialST(500, 225, 8, 4, 15, 0, 5000); //drive under rung
 intake.spin(reverse, 100, pct);
 driveStraightInertialST(1000, 225, 8, 4, 15, 0, 5000);  // $$$$ 3rd ring
               
 speed = 12;
 desiredValue = 31;
 task t647(armPID);                                  //LB
 
 task t613(intakeringLB);
 chassis.drive_to_point(44, 11);                     // $$$ 4th ring LB
 lbp.open();
 driveStraightInertialST(-800, 125, 8, 4, 15, 0, 3000); //backup
 driveStraightInertialST(-500, 90, 8, 4, 15, 0, 3000);
 distanceBackInertialST(1500, 90, 10, 3, 100, 3000);  //get into postition
 
 task::stop(intakeringLB);
 desiredValue = 60;                                  // move arm up
 chassis.turn_to_angle(180); 
 
 g=0;                                                //reset escape varialbe
 task t699(intakering);                              // stop 5th ring at distance sensor
 distanceFrontInertialST(200, 180, 10, 3, 100, 3000);  // drive to stake
 task::stop(armPID); 
 while(rotationARM.position(degrees)<=150)             // 4th ring on stake
      {
        ringliftL.spin(fwd, 100, pct);
        ringliftR.spin(fwd, 100, pct);
        printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
      }
      ringliftL.spin(fwd, 0, pct);
      ringliftR.spin(fwd, 0, pct);
 task::stop(intakering); 
 lbp.close();  
 desiredValue = 35.5;
 task t698(armPID);                                   //5th ring LB
 
 wait(0.5, sec);
 g=0;
 task t697(intakeringLB);
 wait(0.5, sec);
 lbp.open();

 task::stop(intakeringLB);
 task::stop(armPID); 
 while(rotationARM.position(degrees)<=150)            //5th ring stake
      {
        ringliftL.spin(fwd, 100, pct);
        ringliftR.spin(fwd, 100, pct);
        printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
      }
      ringliftL.spin(fwd, 0, pct);
      ringliftR.spin(fwd, 0, pct);
      lbp.close();
 task t696(armPID);                                   // arm back to starting pos
 desiredValue = 0;



wait(30000000, sec);







//$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

intake.spin(reverse, 100, pct);
 //chassis.drive_to_point(122, GYO);
 wait(0.5, sec);

 //chassis.turn_to_angle(0);
 task t710(autoclamp); 
 chassis.left_swing_to_angle(350);
 
 chassis.set_drive_constants(8, 1, 0, 10, 0);
 chassis.drive_to_point(130, 35); //109, 37  $$$$ goal
 //SetToGPS();  
 //wait(0.25, sec);
 //chassis.drive_to_point(122, 40);
 task::stop(autoclamp); 
 chassis.set_drive_constants(8, 1, 0, 10, 0);
 //chassis.turn_to_point(96, 48); 
//chassis.right_swing_to_angle(270); 
 task t626(intakering);
 chassis.drive_to_point(100, 40); //96, 41       $$$$ 1st ring
 wait(0.5, sec);
 SetToGPS();                                   // reset to GPS

 chassis.turn_to_point(71, 64); // 63,63 
 task::stop(intakering); 
 intake.stop(); 
 intake.spin(reverse, 0, pct);
 chassis.set_drive_exit_conditions(2, 0, 500); // timed quick straight
 chassis.drive_distance(144);             // under rung
 //intake.spin(reverse, 100, pct);
 //chassis.right_swing_to_angle(225);            //swing to $$$ 2nd ring        
 g=0;
 task t629(intakering2);
 chassis.set_drive_exit_conditions(2, 0, 3000);  //back to normal
 //chassis.drive_to_point(72, 62);
 chassis.drive_distance(10); 
 

 //chassis.drive_to_point(80, 64); //78, 66
 wait(0.5, sec);
 SetToGPS();                                       //reset to GPS
 
 task::stop(intakering); 
chassis.turn_to_point(40, 36);
 intake.spin(reverse, 0, pct);
 //chassis.turn_to_point(35, 43);
 //chassis.turn_to_point(47, 55);
 chassis.set_drive_exit_conditions(2, 0, 500);      //quick straight
 chassis.drive_distance(144);                  //under rung
 //chassis.drive_to_point(48, 48);
intake.spin(reverse, 100, pct);

 chassis.set_drive_exit_conditions(2, 0, 3000);    //back to normal
 chassis.drive_to_point(40, 36); //48,48             // $$$$ 3rd ring
 wait(0.3, sec);
 
 speed = 12;
 desiredValue = 35.5;
 task t607(armPID);                                  //LB
 
 task t610(intakeringLB);
 chassis.drive_to_point(44, 11);                     // $$$ 4th ring LB
 chassis.drive_to_point(65, 16);
 lbp.open();
 task::stop(intakeringLB);
 desiredValue = 60;                                  // move arm up
 chassis.turn_to_angle(180);                         // turn to stake
  
 g=0;                                                //reset escape varialbe
 task t611(intakering);                              // stop 5th ring at distance sensor
 distanceFrontInertialST(100, 180, 10, 3, 100, 3000);  // drive to stake
 task::stop(armPID); 
 while(rotationARM.position(degrees)<=150)             // 4th ring on stake
      {
        ringliftL.spin(fwd, 100, pct);
        ringliftR.spin(fwd, 100, pct);
        printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
      }
      ringliftL.spin(fwd, 0, pct);
      ringliftR.spin(fwd, 0, pct);
 task::stop(intakering); 
 lbp.close();  
 desiredValue = 35.5;
 task t612(armPID);                                   //5th ring LB
 
 wait(0.5, sec);
 g=0;
 task t6100(intakeringLB);
 wait(0.5, sec);
 lbp.open();

 task::stop(intakeringLB);
 task::stop(armPID); 
 while(rotationARM.position(degrees)<=150)            //5th ring stake
      {
        ringliftL.spin(fwd, 100, pct);
        ringliftR.spin(fwd, 100, pct);
        printf("states %d\tfrontdistance %f\n",states, Frontdistance.objectDistance(mm));
      }
      ringliftL.spin(fwd, 0, pct);
      ringliftR.spin(fwd, 0, pct);
      lbp.close();
 task t61994(armPID);                                   // arm back to starting pos
 desiredValue = 0;

//$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

 wait(3000000,msec);
 read_GPS_coordinates();
 chassis.set_coordinates(GX, GY, Inertial20.heading());
 //chassis.right_swing_to_angle(270);
 wait(3000000, msec);
 chassis.turn_to_angle(270);
 wait(500, msec);
 read_GPS_coordinates();
 chassis.set_coordinates(GX, GY, Inertial20.heading());
 //chassis.turn_to_point(GXO, GYO, 180);
 //chassis.turn_to_point(0, 0, 180);
 chassis.drive_to_point(GXO, GYO);
 //chassis.drive_to_point(0, 0);
 chassis.turn_to_angle(270);


wait(100000, sec);
}
  // PIDlateralST(1000, 12, 0, 1000000, 100000);
  // inertialPIDfuntionST(90, 12, 1, 100, 1000000);

  //driveStraightInertialST(1000, 0, 12, 1, 100, 100000);

  /*

  distanceBackInertialST(100, 0, 4, 3, 100, 300);

  driveStraightInertialST(960, 0, 12, 1, 5, 1000);

  inertialPIDfuntionST(-55, 12, 1, 100, 500);

  driveStraightInertialST(50, -55, 12, 1, 5, 500);

  WR.open();

  wait(200, msec);

  inertialPIDfuntionST(-105, 12, 1, 100, 500);

  WR.close();

  inertialPIDfuntionST(-55, 12, 1, 100, 500);

  driveStraightInertialST(-50, -55, 12, 1, 5, 500);

  backClaw.open();

  driveStraightInertialST(-450, -57, 5, 1, 5, 1000);

  wait(200, msec);

  backClaw.close();

  wait(200, msec);

  intake.spin(fwd, 85, pct);
  intake2.spin(fwd, -85, pct);

  driveStraightInertialST(100, -57, 5, 1, 5, 500);

  inertialPIDfuntionST(-90, 12, 1, 100, 1000);

  intake.spin(fwd, -85, pct);
  intake2.spin(fwd, 85, pct);

  wait(300, msec);

  intake.spin(fwd, 85, pct);
  intake2.spin(fwd, -85, pct);

  distanceFrontInertialST(520, -90, 5, 2, 100, 1500);

  intake.spin(fwd, -85, pct);
  intake2.spin(fwd, 85, pct);

  wait(200, msec);

  intake.stop();
  intake2.stop();

  driveStraightInertialST(-100, -90, 10, 1, 5, 700);

  intake.spin(fwd, 85, pct);
  intake2.spin(fwd, -85, pct);

  wait(1500, msec);

  intake.spin(fwd, -85, pct);
  intake2.spin(fwd, 85, pct);

  wait(300, msec);

  intake.stop();
  intake2.stop();

  driveStraightInertialST(-240, -90, 5, 1, 5, 1000);

  inertialPIDfuntionST(139, 12, 1, 100, 1000);

  driveStraightInertialST(560, 139, 8, 1, 5, 1000);

 
  wait(300, msec);

  inertialPIDfuntionST(-35, 12, 1, 100, 1500);

  

  inertialPIDfuntionST(55, 12, 1, 100, 1000);

  driveStraightInertialST(150, 55, 12, 1, 5, 1000);

  

  */



  /*

  driveStraightInertialST(-300, -45, 12, 1, 5, 1000);


  intake.spin(fwd, 85, pct);
  

  driveStraightInertialST(400, -25, 12, 1, 5, 1000);

  wait(1000, msec);

  intake.spin(fwd, -85, pct);
  

  driveStraightInertialST(50, -55, 12, 1, 5, 1000);



  intake.stop();
  

*/

//chassis.set_coordinates(xl, yb, Inertial20.heading());

/*
  backClaw.open();

  inertialPIDfuntionST(225, 12, 1, 100, 1000);

  driveStraightInertialST(-450, 225, 5, 1, 5, 1000);

  backClaw.close();

  driveStraightInertialST(200, 225, 5, 1, 5, 1000);

  inertialPIDfuntionST(-90, 12, 1, 100, 1000);

  driveStraightInertialST(450, -90, 5, 1, 5, 1000);

  

*/



  //inertialPIDfuntionST(90, 12, 2, 300, 150000); ///$$$$$$$$$$$$    $$$$$$$$

 // chassis.drive_to_point(0, 52);
 //chassis.turn_to_angle(330);
 //chassis.drive_to_point(-10, 82);

  /*
 

read_distance_sensors();
chassis.set_coordinates(144 - xr, yb, 0);

//printf("frontdistance %0.2f\t\tbackdistance %0.2f\n\n\n",Frontdistance.objectDistance(inches),Backdistance.objectDistance(inches)); 
printf("backdistance %0.2f\t\trightdistance %0.2f\n\n\n",Backdistance.objectDistance(inches),Rightdistance.objectDistance(inches)); 
//wait(2, sec);
lBase2.setPosition(0, degrees);
driveStraightInertialNOPID(400, 0, 12, 2000);
driveStraightInertialNOPID(500, 350, 12, 2000);
driveStraightInertialNOPID(600, 330, 12, 2000);
//chassis.drive_to_point(132,50);
//chassis.drive_to_point(144,50);
//chassis.drive_to_point(12,37,0);
//chassis.drive_to_point(6,25,0);
//chassis.turn_to_angle(350);
//wait (3, sec);
greengoal = true;
distanceVisionST(60, 190, 12, 4, 5, 0, 3000);

wait (300, sec);



read_distance_sensors();
chassis.set_coordinates(xl, yb, Inertial20.heading());
printf("backdistance %0.2f\t\tleftdistance %0.2f\n\n\n",Backdistance.objectDistance(inches),Leftdistance.objectDistance(inches)); 

chassis.drive_to_point(120, 24);
chassis.turn_to_angle(0);

wait (30, sec);


//wait(15000, msec);
Brain.Screen.setFont(mono40);
greengoal = true;
//turnVisionST(190, 12, -12, 10, 0, 100000);
//float z; 
//z = Inertial20.heading();
//distanceFrontInertialST(40, z, 12, 5, 100000, 100000);
distanceVisionST(150, 190, 12, 4, 5, 100000, 100000);
//driveStraightInertialST(2000, 0, 12, 5, 100000, 100000);

wait (30, sec);

  
    hasBlueCallback();
    hasGreenCallback();
    hasRedCallback();
    wait(0.1, seconds);
    printf("hello\n");
  


/*

  
  chassis.set_coordinates(0, 0, 0);
  lBase2.setPosition(0, degrees);
  rBase2.setPosition(0, degrees);

 


  idrift = Inertial20.heading();

  printf("inertial drift %f\n",idrift);

  printf("inertial drift %f\n",Inertial20.heading());

  Inertial20.setHeading(idrift, deg);




  distanceBackInertialST(670, 137, 12, 5, 0, 1000);  
  /// $$$$$$$$$$$$$$$$$$$$$long staight path to wall


  distanceFrontInertialST(1000, 135, 12, 5, 0, 1000); 

  

  b = 1;

  chassis.drive_to_point(-10,20,1);
  
  chassis.drive_to_point(0,60,1);

  chassis.set_drive_exit_conditions(1, 300, 5000);

  b = 0;
  
  chassis.set_drive_exit_conditions(1, 300, 5000);
 
  chassis.drive_to_point(0,40,1);

  
  chassis.turn_to_angle(180);
  wait(50,sec);

  */




