#include "vex.h"
using namespace vex;

void GPSdriveStraightInertialST(int desiredValue, float desiredTurnValue, int speed, int speeds, float settle_error, float settle_time, float timeout) {
T1.clear();
settled = false;
time_spent_running = 0;
time_spent_settled = 0;
lBase2.setPosition(0, degrees);
rBase2.setPosition(0, degrees);

Inertial20.setHeading(GPS8.heading(), deg);

float startingX = GPS8.xPosition(mm);
float startingY = GPS8.yPosition(mm);


    
}