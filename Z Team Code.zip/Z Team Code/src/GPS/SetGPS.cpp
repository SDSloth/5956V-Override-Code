#include "vex.h"
using namespace vex;

void read_distance_sensors()
{
xl=  RTMG.objectDistance(inches) + 1;
yf =  Frontdistance.objectDistance(inches) + 7;
xr =  ring.objectDistance(inches) + 1 ;
yb =  Backdistance.objectDistance(inches) + 9.8;
}

void read_GPS_coordinatesOrigin()
{
  GXO = GPS8.xPosition(inches) + 72; 
  GYO = GPS8.yPosition(inches) + 72; 
}

void read_GPS_coordinates()
{
  GX = GPS8.xPosition(inches) + 72; 
  GY = GPS8.yPosition(inches) + 72; 
}

void SetToGPS()
{
  GX = GPS8.xPosition(inches) + 72; 
  GY = GPS8.yPosition(inches) + 72; 
  if (GPS8.quality()>=98 && GPS8.quality()<=100)
    {
      chassis.set_coordinates(GX, GY, Inertial20.heading());
    }

}

void GPSAngleDistance(float endingX, float endingY)
{
  while(!(GPS8.quality()>=99 && GPS8.quality()<=100))
  {

  }
  startingX = GPS8.xPosition(inches) + 72; 
  startingY = GPS8.yPosition(inches) + 72; 

  GPSturnAngle = atan((endingX - startingX) / (endingY - startingY)) * 180 / M_PI;
  if (endingY - startingY < 0) {
    GPSturnAngle = GPSturnAngle + 180;
  }
  
  GPSdriveDistance = sqrt(((endingX - startingX) * (endingX - startingX)) + ((endingY - startingY) * (endingY - startingY)));

}