#include "vex.h"
using namespace vex;

aivision::colordesc AIVision3__BLUEBOX(1, 84, 199, 237, 29, 0.36);
aivision::colordesc AIVision3__REDBOX(2, 243, 109, 110, 28, 0.52);
aivision::colordesc AIVision3__GREENBOX(3, 214, 254, 97, 18, 0.25);

enum gameElements {
  mobileGoal,
  redRing,
  blueRing,
};
//aivision::colordesc AIVision1__GREENBOX(3, 66, 117, 48, 10, 0.2);
// AI Vision Code Definitions
vex::aivision AIVision3(PORT10, AIVision3__BLUEBOX, AIVision3__GREENBOX, AIVision3__REDBOX);

void AWBI()
{
 
  AIVision3.startAwb();
   wait(20, msec);
}


int colorsort()
{     
while(1)
{

    if (Controller1.ButtonX.pressing()) 
    {  

    g=0;
    if (redringc)
    AIVision3.takeSnapshot(AIVision3__REDBOX);
    else if (blueringc)
    AIVision3.takeSnapshot(AIVision3__BLUEBOX);
    else if (greengoalc)
    AIVision3.takeSnapshot(AIVision3__GREENBOX);
    printf("centerX %d\tcenterY %d\tdistance%lf\n",AIVision3.objects[0].centerX, AIVision3.objects[0].centerY, intakedistance.objectDistance(mm));
    intake.spin(reverse, 100, pct);
    wait(0.15, sec); 
        //while((intakedistance.objectDistance(mm)>10 || intakedistance.objectDistance(mm)<=0) && !Controller1.ButtonR2.pressing() && !Controller1.ButtonR1.pressing())
    while(!Controller1.ButtonR2.pressing() && !Controller1.ButtonR1.pressing())
        //while(1)
        {    
          
        if (redringc)
        AIVision3.takeSnapshot(AIVision3__REDBOX);
        else if (blueringc)
        AIVision3.takeSnapshot(AIVision3__BLUEBOX);
        else if (greengoalc)
        AIVision3.takeSnapshot(AIVision3__GREENBOX);
    
        intake.spin(reverse, 100, pct);

       
        if(intake.velocity(rpm)<=10 && intake.velocity(rpm)>=0)
        {
         intake.spin(fwd, 100, pct);
         wait(0.15, sec); 
         intake.spin(reverse, 100, pct);
         wait(0.15, sec); 
         
         
        }
       
    if(AIVision3.objects[0].exists && AIVision3.objects[0].centerX >100 && AIVision3.objects[0].centerX <250 && AIVision3.objects[0].centerY <150 )
        {
                          
        //printf("centerX %d\tcenterY %d\tdistance%lf\n",AIVision3.objects[0].centerX, AIVision3.objects[0].centerY, intakedistance.objectDistance(mm));
        g=1; 
        T2.clear();
        //while((intakedistance.objectDistance(mm)>=20 || intakedistance.objectDistance(mm)<=0) && T2.value()<2)
        intake.setPosition(0, degrees);
        while(fabs(intake.position(degrees))<260 && !Controller1.ButtonR2.pressing() && !Controller1.ButtonR1.pressing())
        {
        
          intake.spin(reverse, 11, volt);

          
          if(intake.velocity(rpm)<=10 && intake.velocity(rpm)>=0)
          {
           intake.spin(fwd, 100, pct);
           wait(0.15, sec); 
           intake.spin(reverse, 100, pct);
           wait(0.15, sec); 
           
           
          }
           
          task::sleep(10);
        }
        g=1;
        wait(80, msec);   
        intake.stop(hold); 
        wait(350, msec); 
        T2.clear();
        g=0;
        }

    task::sleep(10);
    }
  }
 

    else if(Controller1.ButtonR1.pressing())
        {   
        intake.spin(reverse, 100, pct);
        }
    
    else if(Controller1.ButtonR2.pressing())
        {
        intake.spin(fwd, 100, pct);
        } 

    else
        {
        intake.stop(hold);
        }  
     task::sleep(10);
    }
    return 0;
}



int colorsortAuto()
{     
    g=0;
    if (redringc)
    AIVision3.takeSnapshot(AIVision3__REDBOX);
    else if (blueringc)
    AIVision3.takeSnapshot(AIVision3__BLUEBOX);
    else if (greengoalc)
    AIVision3.takeSnapshot(AIVision3__GREENBOX);
     printf("centerX %d\tcenterY %d\tdistance%lf\n",AIVision3.objects[0].centerX, AIVision3.objects[0].centerY, intakedistance.objectDistance(mm));
        //while((intakedistance.objectDistance(mm)>10 || intakedistance.objectDistance(mm)<=0) && !Controller1.ButtonR2.pressing() && !Controller1.ButtonR1.pressing())
        //while(g==0)
    intake.spin(reverse, 100, pct);
    wait(0.15, sec); 
    while(1)
    {    
          
        if (redringc)
        AIVision3.takeSnapshot(AIVision3__REDBOX);
        else if (blueringc)
        AIVision3.takeSnapshot(AIVision3__BLUEBOX);
        else if (greengoalc)
        AIVision3.takeSnapshot(AIVision3__GREENBOX);
    
        intake.spin(reverse, 100, pct);

       
        if(intake.velocity(rpm)<=10 && intake.velocity(rpm)>=0)
        {
         intake.spin(fwd, 100, pct);
         wait(0.1, sec); 
         intake.spin(reverse, 100, pct);
         wait(0.15, sec); 
         
         
        }
        

        //printf("centerX %d\tcenterY %d\tdistance%lf\n",AIVision3.objects[0].centerX, AIVision3.objects[0].centerY, intakedistance.objectDistance(mm));
        
            //if(intakedistance.objectDistance(mm)<10 && AIVision3.objects[0].exists)
            
    if(AIVision3.objects[0].exists && AIVision3.objects[0].centerX >100 && AIVision3.objects[0].centerX <250 && AIVision3.objects[0].centerY <150 )
        {
                          
        //printf("centerX %d\tcenterY %d\tdistance%lf\n",AIVision3.objects[0].centerX, AIVision3.objects[0].centerY, intakedistance.objectDistance(mm));
        g=1; 
        T2.clear();
        //while((intakedistance.objectDistance(mm)>=20 || intakedistance.objectDistance(mm)<=0) && T2.value()<2)
        intake.setPosition(0, degrees);
        while(fabs(intake.position(degrees))<colorEncoder && T2.value()<2) // 260 normal 200 for blue
        {
        
          intake.spin(reverse, 11, volt);

          
          if(intake.velocity(rpm)<=10 && intake.velocity(rpm)>=0)
          {
           intake.spin(fwd, 100, pct);
           wait(0.25, sec); 
           intake.spin(reverse, 100, pct);
           wait(0.15, sec); 
           
           
          }
           
          task::sleep(10);
        }
        g=1;
        wait(80, msec);   
        intake.stop(hold); 
        wait(350, msec); 
        T2.clear();
        g=0;
        intake.spin(reverse, 100, pct);
        wait(0.15, sec); 
        }

    task::sleep(10);
    }
    return 0;
}


int intakedecide() { 
    intake.spin(reverse, 100, pct);
    wait(0.1, sec);
    while(1)
    {
    while(L==0)
    {
    if (redringc)
    AIVision3.takeSnapshot(AIVision3__REDBOX);
    else if (blueringc)
    AIVision3.takeSnapshot(AIVision3__BLUEBOX);
    else if (greengoalc)
    AIVision3.takeSnapshot(AIVision3__GREENBOX); 

    intake.spin(reverse, 80, pct);
              
        if(intake.velocity(rpm)<=100 && intake.velocity(rpm)>=20)
        {
            intake.spin(fwd, 100, pct);
            wait(0.25, sec); 
            intake.spin(reverse, 100, pct);
            wait(0.15, sec);  
         
        }

        if(intakedistance.objectDistance(mm)<20 && intakedistance.objectDistance(mm)>0)
        {
        intake.stop();
        wait(0.25,sec);
        intake.spin(fwd, 50, pct); 
        wait(0.3, sec);  
        intake.stop(hold);  
        L=1;
        }
       
        
        if(AIVision3.objects[0].exists && AIVision3.objects[0].centerX >60 && AIVision3.objects[0].centerX <140)
        {
                          
        //printf("centerX %d\tcenterY %d\tdistance%lf\n",AIVision3.objects[0].centerX, AIVision3.objects[0].centerY, intakedistance.objectDistance(mm));
        g=1; 
        T2.clear();
        while((intakedistance.objectDistance(mm)>=20 || intakedistance.objectDistance(mm)<=0) && T2.value()<2 )
        //while(!Controller1.ButtonL2.pressing() && !Controller1.ButtonL1.pressing())
        {
        
          intake.spin(reverse, 11, volt);

          if(intake.velocity(rpm)<=100 && intake.velocity(rpm)>=20)
          {
              
            intake.spin(fwd, 100, pct);
            wait(0.25, sec); 
            intake.spin(reverse, 100, pct);
            wait(0.15, sec); 
           
          }
           
          task::sleep(10);
        }
        
        wait(80, msec);   
        intake.stop(); 
        wait(350, msec); 
        T2.clear();
        g=0;
        
        }

        task::sleep(10); 
    }
    task::sleep(10); 
}
return 0;
}  





int intakeVisionProceed()
{     

    if (redringi)
    AIVision3.takeSnapshot(AIVision3__REDBOX);
    else if (blueringi)
    AIVision3.takeSnapshot(AIVision3__BLUEBOX);
    else if (greengoali)
    AIVision3.takeSnapshot(AIVision3__GREENBOX);
     //printf("centerX %d\tcenterY %d\tdistance%lf\n",AIVision3.objects[0].centerX, AIVision3.objects[0].centerY, intakedistance.objectDistance(mm));
        //while((intakedistance.objectDistance(mm)>10 || intakedistance.objectDistance(mm)<=0) && !Controller1.ButtonR2.pressing() && !Controller1.ButtonR1.pressing())
        while(g==0)
        //while(1)
        {    
          
        if (redringi)
        AIVision3.takeSnapshot(AIVision3__REDBOX);
        else if (blueringi)
        AIVision3.takeSnapshot(AIVision3__BLUEBOX);
        else if (greengoali)
        AIVision3.takeSnapshot(AIVision3__GREENBOX);
    
        intake.spin(reverse, 100, pct);
        printf("centerX %d\tcenterY %d\tdistance%lf\n",AIVision3.objects[0].centerX, AIVision3.objects[0].centerY, intakedistance.objectDistance(mm));
        
            //if(intakedistance.objectDistance(mm)<10 && AIVision3.objects[0].exists)
            
    if(AIVision3.objects[0].exists && AIVision3.objects[0].centerX >120 && AIVision3.objects[0].centerX <240)
        {
                  
        printf("centerX %d\tcenterY %d\tdistance%lf\n",AIVision3.objects[0].centerX, AIVision3.objects[0].centerY, intakedistance.objectDistance(mm));
        g=1; 
        
        
        }

      
    wait(20, msec);
}
    return 1;
}



int intakeringVision() { 
    if (redringi)
    AIVision3.takeSnapshot(AIVision3__REDBOX);
    else if (blueringi)
    AIVision3.takeSnapshot(AIVision3__BLUEBOX);
    else if (greengoali)
    AIVision3.takeSnapshot(AIVision3__GREENBOX);
    
    while(g==0)
        //while(!Controller1.ButtonL2.pressing() && !Controller1.ButtonL1.pressing())
        {
          if (redringi)
          AIVision3.takeSnapshot(AIVision3__REDBOX);
          else if (blueringi)
          AIVision3.takeSnapshot(AIVision3__BLUEBOX);
          else if (greengoali)
          AIVision3.takeSnapshot(AIVision3__GREENBOX);  
        
          intake.spin(reverse, 90, pct);
          task::sleep(20);
        if(AIVision3.objects[0].exists && AIVision3.objects[0].centerX >120 && AIVision3.objects[0].centerX <240)
        {
         g=1;
         intake.stop(); 
         intake.spin(fwd, 25, pct); 
         wait(0.2, sec);
         intake.stop(); 
         
        }
        }
    return 1;
  }

void intakeVisionProceedFunction()
{     
    h=0;
    if (redringi)
    AIVision3.takeSnapshot(AIVision3__REDBOX);
    else if (blueringi)
    AIVision3.takeSnapshot(AIVision3__BLUEBOX);
    else if (greengoali)
    AIVision3.takeSnapshot(AIVision3__GREENBOX);
     //printf("centerX %d\tcenterY %d\tdistance%lf\n",AIVision3.objects[0].centerX, AIVision3.objects[0].centerY, intakedistance.objectDistance(mm));
        //while((intakedistance.objectDistance(mm)>10 || intakedistance.objectDistance(mm)<=0) && !Controller1.ButtonR2.pressing() && !Controller1.ButtonR1.pressing())
        T1.clear();
        while(h==0 && T1.value()<3)
        //while(1)
        {    
          
        if (redringi)
        AIVision3.takeSnapshot(AIVision3__REDBOX);
        else if (blueringi)
        AIVision3.takeSnapshot(AIVision3__BLUEBOX);
        else if (greengoali)
        AIVision3.takeSnapshot(AIVision3__GREENBOX);
    
        lBase1.stop(hold);
        lBase2.stop(hold);
        lBase3.stop(hold);
        rBase1.stop(hold);
        rBase2.stop(hold);
        rBase3.stop(hold);
        printf("centerX %d\tcenterY %d\tdistance%lf\n",AIVision3.objects[0].centerX, AIVision3.objects[0].centerY, intakedistance.objectDistance(mm));
        
            //if(intakedistance.objectDistance(mm)<10 && AIVision3.objects[0].exists)
            
    if(AIVision3.objects[0].exists && AIVision3.objects[0].centerX >60 && AIVision3.objects[0].centerX <140 && AIVision3.objects[0].centerY >140 && AIVision3.objects[0].centerY <160)
        {
                  
        printf("centerX %d\tcenterY %d\tdistance%lf\n",AIVision3.objects[0].centerX, AIVision3.objects[0].centerY, intakedistance.objectDistance(mm));
        h=1; 
        
        
        }

      
    wait(20, msec);
}
   
}


  /*

int colorsort()
{     
while(1)
{

    if (redringc)
    AIVision3.takeSnapshot(AIVision3__REDBOX);
    else if (blueringc)
    AIVision3.takeSnapshot(AIVision3__BLUEBOX);
    else if (greengoalc)
    AIVision3.takeSnapshot(AIVision3__GREENBOX);

    if (Controller1.ButtonX.pressing()) 
    {  
        //while((intakedistance.objectDistance(mm)>10 || intakedistance.objectDistance(mm)<=0) && !Controller1.ButtonR2.pressing() && !Controller1.ButtonR1.pressing())
        while(!Controller1.ButtonR2.pressing() && !Controller1.ButtonR1.pressing())
        //while(1)
        {    
          
        if (redringc)
        AIVision3.takeSnapshot(AIVision3__REDBOX);
         else if (blueringc)
         AIVision3.takeSnapshot(AIVision3__BLUEBOX);
         else if (greengoalc)
         AIVision3.takeSnapshot(AIVision3__GREENBOX);

          intake.spin(reverse, 12, volt);
          //printf("originY %d\tcenterY %d\tencoder%lf\n",AIVision3.objects[0].originY, AIVision3.objects[0].centerY, intake.position(degrees));
        
            //if(intakedistance.objectDistance(mm)<10 && AIVision3.objects[0].exists)

    if(AIVision3.objects[0].exists && AIVision3.objects[0].originY<=3)
        {    
        intake.setPosition(0, deg);  
        
        error = -120 - intake.position(degrees);        
        printf("$$$$$$$originY %d\tcenterY %d\tencoder%lf\terror%f\n",AIVision3.objects[0].originY, AIVision3.objects[0].centerY, intake.position(degrees), error);
          
        T3.clear();
        while(T3.value()<3  && !Controller1.ButtonR2.pressing() && !Controller1.ButtonR1.pressing())
        {     
              error = -120 - intake.position(degrees);
              derivative = error - prevError;
 
              if (fabs(error) > integralBound) {
              totalError += error; // totalError = totalError + error;
              } else {
              totalError = 0;
              }
   
              totalError = fabs(totalError) > maxIntegral? signnum_c(totalError) * maxIntegral: totalError;
   
             lateralMotorPower = error * ikP + derivative * ikD + totalError * ikI;
             /////////////////////////////////////////////////////////////////////

            if (lateralMotorPower > 12) 
            {
             lateralMotorPower = 12;
            }
            else if (lateralMotorPower < - 12) 
            {
            lateralMotorPower = -12;
            }

            intake.spin(reverse, -lateralMotorPower, voltageUnits::volt);

            prevError = error;

            
            wait(10, msec);
        }
              intake.stop(); 
              wait(500, msec); 
              printf("originY %d\tcenterY %d\tencoder%lf\terror%f\n",AIVision3.objects[0].originY, AIVision3.objects[0].centerY, intake.position(degrees), error);
               
              wait(500, msec);        
        }
        }
        
    }
     else if(Controller1.ButtonR1.pressing())
        {   
        intake.spin(reverse, 12, volt);
        hook.spin(fwd, 12, volt);
        }
    
    else if(Controller1.ButtonR2.pressing())
        {
        intake.spin(fwd, 12, volt);
        hook.spin(reverse, 12, volt);
        } 

    else
        {
        intake.stop();
        hook.stop();
        }  
     task::sleep(10);
   
}
 return 0;
}
*/

/*
int colorsortAuto()
{     

    if (redringc)
    AIVision3.takeSnapshot(AIVision3__REDBOX);
    else if (blueringc)
    AIVision3.takeSnapshot(AIVision3__BLUEBOX);
    else if (greengoalc)
    AIVision3.takeSnapshot(AIVision3__GREENBOX);
     //printf("centerX %d\tcenterY %d\tdistance%lf\n",AIVision3.objects[0].centerX, AIVision3.objects[0].centerY, intakedistance.objectDistance(mm));
        //while((intakedistance.objectDistance(mm)>10 || intakedistance.objectDistance(mm)<=0) && !Controller1.ButtonR2.pressing() && !Controller1.ButtonR1.pressing())
        while(1)
        //while(1)
        {    
          
        if (redringc)
        AIVision3.takeSnapshot(AIVision3__REDBOX);
        else if (blueringc)
        AIVision3.takeSnapshot(AIVision3__BLUEBOX);
        else if (greengoalc)
        AIVision3.takeSnapshot(AIVision3__GREENBOX);
    
        intake.spin(reverse, 100, pct);
        //printf("centerX %d\tcenterY %d\tdistance%lf\n",AIVision3.objects[0].centerX, AIVision3.objects[0].centerY, intakedistance.objectDistance(mm));
        
            //if(intakedistance.objectDistance(mm)<10 && AIVision3.objects[0].exists)
            
    //if(AIVision3.objects[0].exists)
   if(AIVision3.objects[0].exists && AIVision3.objects[0].centerX >120 && AIVision3.objects[0].centerX <240)
        {    
        g=1;
        
        while((intakedistance.objectDistance(mm)>40 || intakedistance.objectDistance(mm)<=0) )
        //while(!Controller1.ButtonL2.pressing() && !Controller1.ButtonL1.pressing())
        {
        
          intake.spin(reverse, 90, pct);
          task::sleep(10);
        }  
        // wait(100, msec);   
        intake.stop(); 
        wait(350, msec); 

        while(intakedistance.objectDistance(mm)<40 )
        //while(!Controller1.ButtonL2.pressing() && !Controller1.ButtonL1.pressing())
        {
        
          intake.spin(reverse, 90, pct);
          task::sleep(10);
        } 
        */
/*
        intake.setPosition(0, deg);  
        error = -65 - intake.position(degrees);        
        printf("$$$$$$$originY %d\tintakedistance %d\tencoder%lf\terror%f\n",AIVision3.objects[0].originY, intakedistance.objectDistance(mm), intake.position(degrees), error);
          
        T3.clear();
        while(T3.value()<0.75  && !Controller1.ButtonR2.pressing() && !Controller1.ButtonR1.pressing())
            {     
              error = -65 - intake.position(degrees);
              derivative = error - prevError;
 
              if (fabs(error) > integralBound) {
              totalError += error; // totalError = totalError + error;
              } else {
              totalError = 0;
              }
   
              totalError = fabs(totalError) > maxIntegral? signnum_c(totalError) * maxIntegral: totalError;
   
             lateralMotorPower = error * ikP + derivative * ikD + totalError * ikI;
             /////////////////////////////////////////////////////////////////////

            if (lateralMotorPower > 12) 
            {
             lateralMotorPower = 12;
            }
            else if (lateralMotorPower < - 12) 
            {
            lateralMotorPower = -12;
            }

            intake.spin(reverse, -lateralMotorPower, voltageUnits::volt);

            prevError = error;

            
            wait(10, msec);
            }
              intake.stop(); 
              //wait(500, msec); 
              printf("originY %d\tintakedistance %d\tencoder%lf\terror%f\n",AIVision3.objects[0].originY, intakedistance.objectDistance(mm), intake.position(degrees), error);
               
              //wait(500, msec);  
              */   
              /* 
        }
    wait(20, msec);
}
    return 1;
}

*/







/*


int colorsort()
{     
while(1)
{
    if (redringc)
    AIVision3.takeSnapshot(AIVision3__REDBOX);
    else if (blueringc)
    AIVision3.takeSnapshot(AIVision3__BLUEBOX);
    else if (greengoalc)
    AIVision3.takeSnapshot(AIVision3__GREENBOX);

        //while((intakedistance.objectDistance(mm)>10 || intakedistance.objectDistance(mm)<=0) && !Controller1.ButtonR2.pressing() && !Controller1.ButtonR1.pressing())
    while(!Controller1.ButtonR2.pressing() && !Controller1.ButtonR1.pressing())
        //while(1)
    {    
          
        if (redringc)
        AIVision3.takeSnapshot(AIVision3__REDBOX);
         else if (blueringc)
         AIVision3.takeSnapshot(AIVision3__BLUEBOX);
         else if (greengoalc)
         AIVision3.takeSnapshot(AIVision3__GREENBOX);

          intake.spin(reverse, 12, volt);
          //printf("originY %d\tcenterY %d\tencoder%lf\n",AIVision3.objects[0].originY, AIVision3.objects[0].centerY, intake.position(degrees));
        
            //if(intakedistance.objectDistance(mm)<10 && AIVision3.objects[0].exists)

    if(AIVision3.objects[0].exists && AIVision3.objects[0].originY<=3)
        {    
        intake.setPosition(0, deg);  
        
        error = -160 - intake.position(degrees);        
        printf("$$$$$$$originY %d\tcenterY %d\tencoder%lf\terror%f\n",AIVision3.objects[0].originY, AIVision3.objects[0].centerY, intake.position(degrees), error);
          
        T3.clear();
        while(T3.value()<3  && !Controller1.ButtonR2.pressing() && !Controller1.ButtonR1.pressing())
            {     
              error = -160 - intake.position(degrees);
              derivative = error - prevError;
 
              if (fabs(error) > integralBound) {
              totalError += error; // totalError = totalError + error;
              } else {
              totalError = 0;
              }
   
              totalError = fabs(totalError) > maxIntegral? signnum_c(totalError) * maxIntegral: totalError;
   
             lateralMotorPower = error * ikP + derivative * ikD + totalError * ikI;
             /////////////////////////////////////////////////////////////////////

            if (lateralMotorPower > 12) 
            {
             lateralMotorPower = 12;
            }
            else if (lateralMotorPower < - 12) 
            {
            lateralMotorPower = -12;
            }

            intake.spin(reverse, -lateralMotorPower, voltageUnits::volt);

            prevError = error;

            
            wait(10, msec);
            }
              intake.stop(); 
              wait(500, msec); 
              printf("originY %d\tcenterY %d\tencoder%lf\terror%f\n",AIVision3.objects[0].originY, AIVision3.objects[0].centerY, intake.position(degrees), error);
               
              wait(500, msec);        
        }
        task::sleep(10);
    }
         return 0;
}
}
    
 */    
   

int intakeringLBVision() { 
  
    if (redringi)
    AIVision3.takeSnapshot(AIVision3__REDBOX);
    else if (blueringi)
    AIVision3.takeSnapshot(AIVision3__BLUEBOX);
    else if (greengoali)
    AIVision3.takeSnapshot(AIVision3__GREENBOX);
while(g==0)
{
          if (redringi)
          AIVision3.takeSnapshot(AIVision3__REDBOX);
          else if (blueringi)
          AIVision3.takeSnapshot(AIVision3__BLUEBOX);
          else if (greengoali)
          AIVision3.takeSnapshot(AIVision3__GREENBOX);  
        
          intake.spin(reverse, 100, pct);
          task::sleep(10);

   if (AIVision3.objects[0].exists && AIVision3.objects[0].centerX >120 && AIVision3.objects[0].centerX <240)
        //while(!Controller1.ButtonL2.pressing() && !Controller1.ButtonL1.pressing())
        {
          g=1;
         //intake.stop();  
         //wait(.25, sec);
         intake.spin(reverse, 100, pct); 
         wait(.6, sec);
         intake.stop(); 
         lbp.open();
         intake.spin(fwd, 45, pct); 
         wait(.3, sec);
         intake.stop(); 
        }
         
}  
          
    return 1;
}




