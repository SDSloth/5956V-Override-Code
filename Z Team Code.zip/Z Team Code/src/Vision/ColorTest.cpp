
/*
#include "vex.h"
using namespace vex;

aivision::colordesc AIVision1__BLUEBOX(1, 55, 182, 227, 10, 0.2);
aivision::colordesc AIVision1__GREENBOX(3, 210, 255, 135, 10, 0.2);
aivision::colordesc AIVision1__REDBOX(2, 226, 80, 120, 10, 0.2);

enum gameElements {
  mobileGoal,
  redRing,
  blueRing,
};

//aivision::colordesc AIVision1__GREENBOX(3, 66, 117, 48, 10, 0.2);
// AI Vision Code Definitions
vex::aivision AIVision1(PORT2, AIVision1__BLUEBOX, AIVision1__GREENBOX, AIVision1__REDBOX);
//vex::aivision AIVision1(PORT1, aivision::ALL_AIOBJS, AIVision1__BLUEBOX, AIVision1__GREENBOX, AIVision1__REDBOX);
//vex::aivision AIVision1(PORT21, aivision::ALL_AIOBJS);

int FrontturnVisionREDtask() {
  if (redring)
  AIVision1.takeSnapshot(AIVision1__REDBOX);
  else if (bluering)
  AIVision1.takeSnapshot(AIVision1__BLUEBOX);
  else if (greengoal)
  AIVision1.takeSnapshot(AIVision1__GREENBOX);






while (true) {
    Brain.Screen.clearScreen();
    Brain.Screen.setCursor(1, 1);
    // Take a snapshot of all AI Classifications.
    AIVision1.takeSnapshot(aivision::ALL_AIOBJS);
    // Check to see if an AI Classification exists in this snapshot.
    if (AIVision1.objectCount > 0) {
      // Determine which AI Classification is detected.
      if (AIVision1.objects[0].id == greenRing) {
        // Conditional based on finding a greenRing.
        Brain.Screen.print("mobilegoal X %d\tY %d\tW %dH\n");
      } else if (AIVision1.objects[0].id == blueRing) {
        // Conditional based on finding a blueRing.
        Brain.Screen.print("blueRing found");
      } else if (AIVision1.objects[0].id == blueBall) {
        // Conditional based on finding a blueBall.
        Brain.Screen.print("blueBall found");
      } else {
        // Else condition will print that an AI Classification is detected but it does not match the above cases.
        Brain.Screen.print("Other Object Found");
      }
    }
    else {
      // If no AI Classifications are found in this snapshot, display a message.
      Brain.Screen.print("No Object Found");

*/