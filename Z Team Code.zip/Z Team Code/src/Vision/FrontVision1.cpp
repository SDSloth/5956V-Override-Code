/*
#include "vex.h"
using namespace vex;

aivision::colordesc AIVision1__BLUEBOX(1, 36, 69, 85, 22, 0.23);
aivision::colordesc AIVision1__REDBOX(2, 243, 109, 110, 31, 0.49);
aivision::colordesc AIVision1__GREENBOX(3, 214, 254, 97, 18, 0.25);

enum gameElements {
  mobileGoal,
  redRing,
  blueRing,
};

//aivision::colordesc AIVision1__GREENBOX(3, 66, 117, 48, 10, 0.2);
// AI Vision Code Definitions
vex::aivision AIVision1(PORT20, AIVision1__BLUEBOX, AIVision1__GREENBOX, AIVision1__REDBOX);
//vex::aivision AIVision1(PORT1, aivision::ALL_AIOBJS, AIVision1__BLUEBOX, AIVision1__GREENBOX, AIVision1__REDBOX);
//vex::aivision AIVision1(PORT21, aivision::ALL_AIOBJS);
void AWB()
{
 
  AIVision1.startAwb();
   wait(10, msec);
}

void FrontstraightVisionST(int desiredValue, float desiredTurnValue, int speed, int speeds, float settle_error, float settle_time, float timeout) 
{
T1.clear();
settled = false;
time_spent_running = 0;
time_spent_settled = 0;
//AIVision1.startAwb();

//lBase2.setPosition(0, degrees);
//rBase2.setPosition(0, degrees);

//AIVision1.takeSnapshot(AIVision1__BLUEBOX);

    if (redring)
    AIVision1.takeSnapshot(AIVision1__REDBOX);
    else if (bluering)
    AIVision1.takeSnapshot(AIVision1__BLUEBOX);
    else if (greengoal)
    AIVision1.takeSnapshot(AIVision1__GREENBOX);

//error =  lBase2.position(degrees) - desiredValue;
error = desiredValue - lBase2.position(degrees);
if (AIVision1.objects[0].exists)
{
while (!settled) {
//while(true){
    // Get the position of both motors
    int leftMotorPosition = lBase2.position(degrees);
    //int rightMotorPosition = rBase2.position(degrees);
     error = desiredValue - leftMotorPosition;
    //error =  leftMotorPosition - desiredValue; // forward with postitive encoder value
    // error = leftMotorPosition - desiredValue; //reverse with negative encoder value
    // Derivative
    derivative = error - prevError;
    // Integral
    if (fabs(error) > integralBound) {
      totalError += error; // totalError = totalError + error;
    } else {
      totalError = 0;
    }
    // This would cap the integral
    totalError = fabs(totalError) > maxIntegral? signnum_c(totalError) * maxIntegral: totalError;
   

    lateralMotorPower = error * kP + derivative * kD + totalError * kI;
    /////////////////////////////////////////////////////////////////////

    
      if (lateralMotorPower > speed) 
      {
        lateralMotorPower = speed;
      }
      else if (lateralMotorPower < - speed) 
      {
        lateralMotorPower = -speed;
      }

      if (lateralMotorPower>0 && lateralMotorPower < speeds && speeds > 0) 
      {
        lateralMotorPower = speeds;
      }
      else if (lateralMotorPower<0 && lateralMotorPower > -speeds && speeds > 0) 
      {
        lateralMotorPower = -speeds;
      }
      

    

    if (redring)
    AIVision1.takeSnapshot(AIVision1__REDBOX);
    else if (bluering)
    AIVision1.takeSnapshot(AIVision1__BLUEBOX);
    else if (greengoal)
    AIVision1.takeSnapshot(AIVision1__GREENBOX);
  
   float turnDifference1 = AIVision1.objects[0].centerX - desiredTurnValue;
      

  
      lBase1.spin(forward, lateralMotorPower + turnDifference1 * vkMI,
                 voltageUnits::volt);
      lBase2.spin(forward, lateralMotorPower + turnDifference1 * vkMI,
                 voltageUnits::volt);
      lBase3.spin(forward, lateralMotorPower + turnDifference1 * vkMI,
                 voltageUnits::volt);              
      rBase1.spin(forward, lateralMotorPower - turnDifference1 * vkMI,
                  voltageUnits::volt);
      rBase2.spin(forward, lateralMotorPower - turnDifference1 * vkMI,
                  voltageUnits::volt);
      rBase3.spin(forward, lateralMotorPower - turnDifference1 * vkMI,
                  voltageUnits::volt);
        

                  
    prevError = error;

    if(fabs(error)<settle_error){
        time_spent_settled+=10;
   }
   else { 
        time_spent_settled = 0;
   }

   time_spent_running+=10;


  if (time_spent_running>timeout && timeout != 0){
    settled = true;
  }
  else if (time_spent_settled>settle_time){
    settled = true;
  }
  else 
  settled = false;

if (earlyexit)
{
  if (ring.objectDistance(mm)>0 && ring.objectDistance(mm)<=65) //60
  break;
}

if(lineexit)
{
  if(linetrackerL.reflectivity(percent)>70)
  break;

  if(linetrackerR.reflectivity(percent)>70)
  break;
}

//$$$$$$$$$$$$$startnew

if (g==1)        
{
  while(g==1)
  {
   lBase1.spin(fwd, 0, pct);
    lBase2.spin(fwd, 0, pct);
    lBase3.spin(fwd, 0, pct);
    
    rBase1.spin(fwd, 0, pct);
    rBase2.spin(fwd, 0, pct);
    rBase3.spin(fwd, 0, pct);
  }
  
}                  
//$$$$$$$$$$$$$$$$$endnew


   //printf("error %0.1f\tlatteralpower %0.1f\tturndifference %0.1f\tInertial %0.1f\ttimespentsettled %0.1f\ttimerunning %0.1f\n",error, lateralMotorPower, turnDifference1, Inertial20.heading(), time_spent_settled, time_spent_running);
   //wait(10, msec);
   //printf("X %d\tY %d\t W %d\tH %d\terror%f\t turndifference%lf\n",AIVision1.objects[0].centerX, AIVision1.objects[0].centerY, AIVision1.objects[0].width, AIVision1.objects[0].height, error, turnDifference1);
    wait(10, msec);

  }
  //printf("error %f\tturndifference %f\tInertial %f\n",error, turnDifference1, Inertial20.heading());
   //lBase2.setPosition(0, degrees);
   //rBase2.setPosition(0, degrees);
    lBase1.spin(fwd, 0, pct);
    lBase2.spin(fwd, 0, pct);
    lBase3.spin(fwd, 0, pct);
    
    rBase1.spin(fwd, 0, pct);
    rBase2.spin(fwd, 0, pct);
    rBase3.spin(fwd, 0, pct);
    
}
}


int colorsortAuto()
{   
    g=0;
    Brain.Screen.clearScreen();
    AIVision1.installed();
    Brain.Screen.print(AIVision1.installed());
    //AIVision1.startAwb();
    wait(10, msec);
    if (redringc)
    AIVision1.takeSnapshot(AIVision1__REDBOX);
    else if (blueringc)
    AIVision1.takeSnapshot(AIVision1__BLUEBOX);
    else if (greengoalc)
    AIVision1.takeSnapshot(AIVision1__GREENBOX);
  
     //printf("centerX %d\tcenterY %d\tdistance%lf\n",AIVision3.objects[0].centerX, AIVision3.objects[0].centerY, intakedistance.objectDistance(mm));
        //while((intakedistance.objectDistance(mm)>10 || intakedistance.objectDistance(mm)<=0) && !Controller1.ButtonR2.pressing() && !Controller1.ButtonR1.pressing())
        while(1)
        //while(1)
        {    
          
        if (redringc)
        AIVision1.takeSnapshot(AIVision1__REDBOX);
        else if (blueringc)
        AIVision1.takeSnapshot(AIVision1__BLUEBOX);
        else if (greengoalc)
        AIVision1.takeSnapshot(AIVision1__GREENBOX);
    
        intake.spin(reverse, 11, volt);
        hook.spin(fwd, 11, volt);
      printf("centerX %i\tcenterY %d\tline %d\n",AIVision1.installed(), AIVision1.objects[0].centerY, linetrackerL.reflectivity(percent));
      //printf(AIVision1.installed());
            //if(intakedistance.objectDistance(mm)<10 && AIVision3.objects[0].exists)
            
    //if(AIVision3.objects[0].exists)
   if(AIVision1.objects[0].exists && AIVision1.objects[0].centerX >120 && AIVision1.objects[0].centerX <240 && AIVision1.objects[0].centerY >200)
        {    
        g=1;
        earlyexit = false;
        T2.clear();
        while(!limitSwitch.pressing() && T2.value()<2)
        //while(!Controller1.ButtonL2.pressing() && !Controller1.ButtonL1.pressing())
        {
        
          intake.spin(reverse, 11, volt);
          hook.spin(fwd, 11, volt);
          task::sleep(10);
        }  
        // wait(100, msec);   
        intake.stop(); 
        hook.stop(); 
        //wait(350, msec); 
        T2.clear();
        while(limitSwitch.pressing() && T2.value()<2)
        //while(!Controller1.ButtonL2.pressing() && !Controller1.ButtonL1.pressing())
        {
        
          intake.spin(fwd, 11, volt);
          hook.spin(fwd, 11, volt);
          task::sleep(10);
        } 
        intake.spin(fwd, 11, volt);
        hook.spin(reverse, 11, volt);
        wait(0.25, sec);
        intake.stop(); 
        hook.stop();
        g=0;
        earlyexit = true;

        }
    wait(20, msec);
}
    return 1;
}




int FrontturnVisionREDtask() {
  if (redring)
  AIVision1.takeSnapshot(AIVision1__REDBOX);
  else if (bluering)
  AIVision1.takeSnapshot(AIVision1__BLUEBOX);
  else if (greengoal)
  AIVision1.takeSnapshot(AIVision1__GREENBOX);

    ///////////////////////////////////////////
    // Turning movement PID
    wait (10, msec);

  while (enableDrivePID) {

    if (resetDriveSensors) {
      resetDriveSensors = false;
      lBase2.setPosition(0, degrees);
      rBase2.setPosition(0, degrees);
    }

    if (redring)
    AIVision1.takeSnapshot(AIVision1__REDBOX);
    else if (bluering)
    AIVision1.takeSnapshot(AIVision1__BLUEBOX);
    else if (greengoal)
    AIVision1.takeSnapshot(AIVision1__GREENBOX);

    lBase1.spin(forward, turnspeed1, voltageUnits::volt);
    lBase2.spin(forward, turnspeed1, voltageUnits::volt);
    lBase3.spin(forward, turnspeed1, voltageUnits::volt);
    rBase1.spin(forward, -turnspeed1, voltageUnits::volt);  //right
    rBase2.spin(forward, -turnspeed1, voltageUnits::volt);
    rBase3.spin(forward, -turnspeed1, voltageUnits::volt);
    ///////////////////////////////////////////
    // Turning movement PID
  if (AIVision1.objects[0].exists) {
    
    //vturnError = FrontVision.largestObject.centerX - vdesiredTurnValue; //turn error
    turnError =  AIVision1.objects[0].centerX - desiredTurnValue;

    // Derivative
    turnDerivative = turnError - turnPrevError;

    // Integral
    if (fabs(error) < integralBound) {
      turnTotalError += turnError;
    } else {
      turnTotalError = 0;
    }
    // turnTotalError = turnTotalError + turnError;

    // This would cap the integral
    turnTotalError = fabs(turnTotalError) > maxIntegral
                         ? signnum_c(turnTotalError) * maxIntegral
                         : turnTotalError;

    double turnMotorPower =
        turnError * vturnkP + turnDerivative * vturnkD + turnTotalError * vturnkI;

    
      if (turnMotorPower > turnspeed) {
        turnMotorPower = turnspeed;
      }
   
      else if (turnMotorPower < -turnspeed) {
        turnMotorPower = -turnspeed;
      }

    /////////////////////////////////////////////////////////////////////

    
      lBase1.spin(forward, turnMotorPower, voltageUnits::volt);
      lBase2.spin(forward, turnMotorPower, voltageUnits::volt);
      lBase3.spin(forward, turnMotorPower, voltageUnits::volt);
      rBase1.spin(forward, -turnMotorPower, voltageUnits::volt);  //right
      rBase2.spin(forward, -turnMotorPower, voltageUnits::volt);
      rBase3.spin(forward, -turnMotorPower, voltageUnits::volt);
    

    //printf("centerX %f\toriginX %f/tcenterY %f\t error%f\t motorpower%lf\n",AIVision1.objects[0].centerX, AIVision1.objects[0].originX, AIVision1.objects[0].centerY, turnError, turnMotorPower);
   

    turnPrevError = turnError;

     //printf("%ld\n", poten.value(mV));
    vex::task::sleep(20); // don't hog CPU. This makes all tasks run faster.
  }
  }
  redring = false;

  return 1;
}




void FrontturnVisionST(float desiredTurnValue, float turnspeed, float turnspeed1, float settle_error, float settle_time, float timeout) {
  AIVision1.startAwb();
  wait(10, msec);
  settled = false;
  time_spent_running = 0;
  time_spent_settled = 0;

 
  z = Inertial20.heading();
  
  if (redring)
  AIVision1.takeSnapshot(AIVision1__REDBOX);
  else if (bluering)
  AIVision1.takeSnapshot(AIVision1__BLUEBOX);
  else if (greengoal)
  AIVision1.takeSnapshot(AIVision1__GREENBOX);
  
   //AIVision1.takeSnapshot(aivision::ALL_AIOBJS);
  
  
    ///////////////////////////////////////////
    // Turning movement PID
    wait (10, msec);
  
 
  while (!AIVision1.objects[0].exists) {

    if (redring)
    AIVision1.takeSnapshot(AIVision1__REDBOX);
    else if (bluering)
    AIVision1.takeSnapshot(AIVision1__BLUEBOX);
    else if (greengoal)
    AIVision1.takeSnapshot(AIVision1__GREENBOX);

    lBase1.spin(forward, turnspeed1, voltageUnits::volt);
    lBase2.spin(forward, turnspeed1, voltageUnits::volt);
    lBase3.spin(forward, turnspeed1, voltageUnits::volt);
    rBase1.spin(forward, -turnspeed1, voltageUnits::volt);  //right
    rBase2.spin(forward, -turnspeed1, voltageUnits::volt);
    rBase3.spin(forward, -turnspeed1, voltageUnits::volt);
    wait(10, msec);
    ///////////////////////////////////////////
    // Turning movement PID
  }
  
  turnError =   AIVision1.objects[0].centerX - desiredTurnValue;

   
  while (!settled) {
    if (redring)
    AIVision1.takeSnapshot(AIVision1__REDBOX);
    else if (bluering)
    AIVision1.takeSnapshot(AIVision1__BLUEBOX);
    else if (greengoal)
    AIVision1.takeSnapshot(AIVision1__GREENBOX);

    turnError =   AIVision1.objects[0].centerX - desiredTurnValue;
    
    // Derivative
    turnDerivative = turnError - turnPrevError;

    // Integral
    if (fabs(error) < integralBound) {
      turnTotalError += turnError;
    } else {
      turnTotalError = 0;
    }
    // turnTotalError = turnTotalError + turnError;

    // This would cap the integral
    turnTotalError = fabs(turnTotalError) > maxIntegral
                         ? signnum_c(turnTotalError) * maxIntegral
                         : turnTotalError;

    double turnMotorPower =
        turnError * vturnkP + turnDerivative * vturnkD + turnTotalError * vturnkI;

    
      if (turnMotorPower > turnspeed) {
        turnMotorPower = turnspeed;
      }
   
      else if (turnMotorPower < -turnspeed) {
        turnMotorPower = -turnspeed;
      }
    

    /////////////////////////////////////////////////////////////////////

    
      lBase1.spin(forward, turnMotorPower, voltageUnits::volt);
      lBase2.spin(forward, turnMotorPower, voltageUnits::volt);
      lBase3.spin(forward, turnMotorPower, voltageUnits::volt);
      rBase1.spin(forward, -turnMotorPower, voltageUnits::volt);  //right
      rBase2.spin(forward, -turnMotorPower, voltageUnits::volt);
      rBase3.spin(forward, -turnMotorPower, voltageUnits::volt);
    


   turnPrevError = turnError;

   if(fabs(turnError)<settle_error){
        time_spent_settled+=10;
   }
   else { 
        time_spent_settled = 0;
   }

   time_spent_running+=10;


  if (time_spent_running>timeout && timeout != 0){
    settled = true;
  }
  else if (time_spent_settled>settle_time){
    settled = true;
  }
else
  settled = false;


    //printf("centerX %d\toriginX %d/tcenterY %d\t error%d\t motorpower%lf\n",FrontVision1.largestObject.centerX, FrontVision1.largestObject.originX, FrontVision1.largestObject.centerY, vturnError, vturnMotorPower);
   printf("centerX %d\toriginX %d\tcenterY %d\t error%f\t motorpower%lf\n",AIVision1.objects[0].centerX, AIVision1.objects[0].originX, AIVision1.objects[0].centerY, turnError, turnMotorPower);
 wait(10, msec);
    
  }
   
   lBase1.spin(fwd, 0, pct);
   lBase2.spin(fwd, 0, pct);
   lBase3.spin(fwd, 0, pct);
   rBase1.spin(fwd, 0, pct);
   rBase2.spin(fwd, 0, pct);
   rBase3.spin(fwd, 0, pct);
  }
  


void FrontdistanceVisionST(int desiredValue, float desiredTurnValue, int speed, float speeds, float settle_error, float settle_time, float timeout) {
 T1.clear();
 settled = false;
 time_spent_running = 0;
 time_spent_settled = 0;
 z = Inertial20.heading();

 //error =   desiredValue - ring.objectDistance(mm);
 error =  ring.objectDistance(mm) - desiredValue;
  while (!settled) {

    //error = desiredValue - ring.objectDistance(mm);
    error = ring.objectDistance(mm) - desiredValue;

  if (ring.objectDistance(mm)<=0 || ring.objectDistance(mm)>=5000)
    {
      error = prevError+10;
    }

    // Derivative
    derivative = error - prevError;

    // Integral
    if (fabs(error) > integralBound) {
      totalError += error; // totalError = totalError + error;
    } else {
      totalError = 0;
    }

    // This would cap the integral
    totalError = fabs(totalError) > maxIntegral? signnum_c(totalError) * maxIntegral: totalError;
    

    double lateralMotorPower = error * dkP + derivative * dkD + totalError * dkI;
    /////////////////////////////////////////////////////////////////////

    if (lateralMotorPower > speed) {
        lateralMotorPower = speed;
      }
   
      else if (lateralMotorPower < -speed) {
        lateralMotorPower = -speed;
      }

      if (lateralMotorPower>0 && lateralMotorPower < speeds && speeds > 0) 
      {
        lateralMotorPower = speeds;
      }
      else if (lateralMotorPower<0 && lateralMotorPower > -speeds && speeds > 0) 
      {
        lateralMotorPower = -speeds;
      }
  
    //int dturnDifference = leftMotorPosition - rightMotorPosition;
    
    if (redring)
    AIVision1.takeSnapshot(AIVision1__REDBOX);
    else if (bluering)
    AIVision1.takeSnapshot(AIVision1__BLUEBOX);
    else if (greengoal)
    AIVision1.takeSnapshot(AIVision1__GREENBOX);
    //else if(mobilegoal)
    
    //AIVision1.takeSnapshot(aivision::ALL_AIOBJS);
  
  //if(AIVision1.objects[0].id == mobileGoal)
  //{

   float turnDifference1 = AIVision1.objects[0].centerX - desiredTurnValue;
      

  
      lBase1.spin(forward, lateralMotorPower + turnDifference1 * vkMI,
                 voltageUnits::volt);
      lBase2.spin(forward, lateralMotorPower + turnDifference1 * vkMI,
                 voltageUnits::volt);
      lBase3.spin(forward, lateralMotorPower + turnDifference1 * vkMI,
                 voltageUnits::volt);             
      rBase1.spin(forward, lateralMotorPower - turnDifference1 * vkMI,
                  voltageUnits::volt);
      rBase2.spin(forward, lateralMotorPower - turnDifference1 * vkMI,
                  voltageUnits::volt);
      rBase3.spin(forward, lateralMotorPower - turnDifference1 * vkMI,
                  voltageUnits::volt);
     
   prevError = error;


 if(fabs(error)<settle_error){
        time_spent_settled+=10;
   }
   else { 
        time_spent_settled = 0;
   }

   time_spent_running+=10;


  if (time_spent_running>timeout && timeout != 0){
    settled = true;
  }
 else if (time_spent_settled>settle_time){
    settled = true;
  }
else
  settled = false;
*/
  /*
  if (!AIVision1.objects[0].exists)
  {
    while(AIVision1.objects[0].id != mobileGoal)
    {
    //while (!AIVision1.objects[0].exists)
    //{
    if (redring)
    AIVision1.takeSnapshot(AIVision1__REDBOX);
    else if (bluering)
    AIVision1.takeSnapshot(AIVision1__BLUEBOX);
    else if (greengoal)
    AIVision1.takeSnapshot(AIVision1__GREENBOX);
    else if (mobilegoal)
    AIVision1.takeSnapshot(aivision::ALL_AIOBJS);

      lBase1.spin(forward, turnspeed, voltageUnits::volt);
      lBase2.spin(forward, turnspeed, voltageUnits::volt);
      lBase3.spin(forward, turnspeed, voltageUnits::volt);
      rBase1.spin(forward, -turnspeed, voltageUnits::volt);  //right
      rBase2.spin(forward, -turnspeed, voltageUnits::volt);
      rBase3.spin(forward, -turnspeed, voltageUnits::volt);
    }

  }
  */
  
/*
    
    //printf("error %f\tturndifference %f\tfrontdistance %f\ttimespentsettled %f\ttimerunning %f\n", error, turnDifference1, Frontdistance.objectDistance(mm),time_spent_settled, time_spent_running);
    printf("centerX %d\toriginX %d\tcenterY %d\t error%f\t turndifference%lf\n",AIVision1.objects[0].centerX, AIVision1.objects[0].originX, AIVision1.objects[0].centerY, error, turnDifference1);
    wait(10, msec);
    
  }
   lBase2.setPosition(0, degrees);
   rBase2.setPosition(0, degrees);
   lBase1.spin(fwd, 0, pct);
   lBase2.spin(fwd, 0, pct);
   lBase3.spin(fwd, 0, pct);
   rBase1.spin(fwd, 0, pct);
   rBase2.spin(fwd, 0, pct);
   rBase3.spin(fwd, 0, pct);
  }











void FrontWidthVisionST(int desiredValue, float desiredTurnValue, int speed, int speeds, float settle_error, float settle_time, float timeout) 
{
T1.clear();
settled = false;
time_spent_running = 0;
time_spent_settled = 0;
lBase2.setPosition(0, degrees);
rBase2.setPosition(0, degrees);
constant = 0;

//AIVision1.takeSnapshot(AIVision1__BLUEBOX);

    if (redring)
    AIVision1.takeSnapshot(AIVision1__REDBOX);
    else if (bluering)
    AIVision1.takeSnapshot(AIVision1__BLUEBOX);
    else if (greengoal)
    AIVision1.takeSnapshot(AIVision1__GREENBOX);

//error =  lBase2.position(degrees) - desiredValue;
error = desiredValue - AIVision1.objects[0].centerY;
if (AIVision1.objects[0].exists)
{
while (!settled && constant ==0) {
//while(true){
    // Get the position of both motors
    int leftMotorPosition = AIVision1.objects[0].centerY;
    //int rightMotorPosition = rBase2.position(degrees);
     error = desiredValue - leftMotorPosition;
    //error =  leftMotorPosition - desiredValue; // forward with postitive encoder value
    // error = leftMotorPosition - desiredValue; //reverse with negative encoder value
    // Derivative
    derivative = error - prevError;
    // Integral
    if (fabs(error) > integralBound) {
      totalError += error; // totalError = totalError + error;
    } else {
      totalError = 0;
    }
    // This would cap the integral
    totalError = fabs(totalError) > maxIntegral? signnum_c(totalError) * maxIntegral: totalError;
   

    lateralMotorPower = error * kP + derivative * kD + totalError * kI;
    /////////////////////////////////////////////////////////////////////

    
      if (lateralMotorPower > speed) 
      {
        lateralMotorPower = speed;
      }
      else if (lateralMotorPower < - speed) 
      {
        lateralMotorPower = -speed;
      }

      if (lateralMotorPower>0 && lateralMotorPower < speeds && speeds > 0) 
      {
        lateralMotorPower = speeds;
      }
      else if (lateralMotorPower<0 && lateralMotorPower > -speeds && speeds > 0) 
      {
        lateralMotorPower = -speeds;
      }
      
    

    if (redring)
    AIVision1.takeSnapshot(AIVision1__REDBOX);
    else if (bluering)
    AIVision1.takeSnapshot(AIVision1__BLUEBOX);
    else if (greengoal)
    AIVision1.takeSnapshot(AIVision1__GREENBOX);
  
   float turnDifference1 = AIVision1.objects[0].centerX - desiredTurnValue;
      

  
      lBase1.spin(forward, lateralMotorPower + turnDifference1 * vkMI,
                 voltageUnits::volt);
      lBase2.spin(forward, lateralMotorPower + turnDifference1 * vkMI,
                 voltageUnits::volt);
      lBase3.spin(forward, lateralMotorPower + turnDifference1 * vkMI,
                 voltageUnits::volt);              
      rBase1.spin(forward, lateralMotorPower - turnDifference1 * vkMI,
                  voltageUnits::volt);
      rBase2.spin(forward, lateralMotorPower - turnDifference1 * vkMI,
                  voltageUnits::volt);
      rBase3.spin(forward, lateralMotorPower - turnDifference1 * vkMI,
                  voltageUnits::volt);
        

                  
    prevError = error;

    if(fabs(error)<settle_error){
        time_spent_settled+=10;
   }
   else { 
        time_spent_settled = 0;
   }

   time_spent_running+=10;


  if (time_spent_running>timeout && timeout != 0){
    settled = true;
  }
  else if (time_spent_settled>settle_time){
    settled = true;
  }
  else 
  settled = false;

   //printf("error %0.1f\tlatteralpower %0.1f\tturndifference %0.1f\tInertial %0.1f\ttimespentsettled %0.1f\ttimerunning %0.1f\n",error, lateralMotorPower, turnDifference1, Inertial20.heading(), time_spent_settled, time_spent_running);
   //wait(10, msec);
   printf("X %d\tY %d\t W %d\tH %d\terror%f\t turndifference%lf\n",AIVision1.objects[0].centerX, AIVision1.objects[0].centerY, AIVision1.objects[0].width, AIVision1.objects[0].height, error, turnDifference1);
    wait(10, msec);

  }
  //printf("error %f\tturndifference %f\tInertial %f\n",error, turnDifference1, Inertial20.heading());
   lBase2.setPosition(0, degrees);
   rBase2.setPosition(0, degrees);
    lBase1.spin(fwd, 0, pct);
    lBase2.spin(fwd, 0, pct);
    lBase3.spin(fwd, 0, pct);
    
    rBase1.spin(fwd, 0, pct);
    rBase2.spin(fwd, 0, pct);
    rBase3.spin(fwd, 0, pct);
    
}
}



void repeating() { 
    if (redringi)
    AIVision1.takeSnapshot(AIVision1__REDBOX);
    else if (blueringi)
    AIVision1.takeSnapshot(AIVision1__BLUEBOX);
    else if (greengoali)
    AIVision1.takeSnapshot(AIVision1__GREENBOX);
    
    if( AIVision1.objects[0].exists)
        //while(!Controller1.ButtonL2.pressing() && !Controller1.ButtonL1.pressing())
        {
         
          FrontstraightVisionST(2000, 175, 10, 6, 5, 0, 2000); // $$$$1 far side ring
          chassis.drive_min_voltage = 5;
          chassis.drive_distance(4);  
          T1.clear();                        //wait for 1st ring
          while(g==0 && T1.value()<1)
         {

         }

        }  
            
  
  }
  */

/*

int colorsortAuto()
{   
    Brain.Screen.clearScreen();
    AIVision1.installed();
    Brain.Screen.print(AIVision1.installed());
    AIVision1.startAwb();
    wait(10, msec);
    if (redringc)
    AIVision1.takeSnapshot(AIVision1__REDBOX);
    else if (blueringc)
    AIVision1.takeSnapshot(AIVision1__BLUEBOX);
    else if (greengoalc)
    AIVision1.takeSnapshot(AIVision1__GREENBOX);
  
     //printf("centerX %d\tcenterY %d\tdistance%lf\n",AIVision3.objects[0].centerX, AIVision3.objects[0].centerY, intakedistance.objectDistance(mm));
        //while((intakedistance.objectDistance(mm)>10 || intakedistance.objectDistance(mm)<=0) && !Controller1.ButtonR2.pressing() && !Controller1.ButtonR1.pressing())
        while(1)
        //while(1)
        {    
          
        if (redringc)
        AIVision1.takeSnapshot(AIVision1__REDBOX);
        else if (blueringc)
        AIVision1.takeSnapshot(AIVision1__BLUEBOX);
        else if (greengoalc)
        AIVision1.takeSnapshot(AIVision1__GREENBOX);
    
        intake.spin(reverse, 100, pct);
      printf("centerX %i\tcenterY %d\tdistance%lf\n",AIVision1.installed(), AIVision1.objects[0].centerY, intakedistance.objectDistance(mm));
      //printf(AIVision1.installed());
            //if(intakedistance.objectDistance(mm)<10 && AIVision3.objects[0].exists)
            
    //if(AIVision3.objects[0].exists)
   if(AIVision1.objects[0].exists && AIVision1.objects[0].centerX >120 && AIVision1.objects[0].centerX <240 && AIVision1.objects[0].centerY >200)
        {    
        g=1;
        
        while(!limitSwitch.pressing())
        //while(!Controller1.ButtonL2.pressing() && !Controller1.ButtonL1.pressing())
        {
        
          intake.spin(reverse, 12, volt);
          hook.spin(fwd, 12, volt);
          task::sleep(10);
        }  
        // wait(100, msec);   
        intake.stop(); 
        hook.stop(); 
        wait(350, msec); 

        while(limitSwitch.pressing())
        //while(!Controller1.ButtonL2.pressing() && !Controller1.ButtonL1.pressing())
        {
        
          intake.spin(fwd, 4, volt);
          hook.spin(reverse, 4, volt);
          task::sleep(10);
        } 
        intake.stop(); 
        hook.stop();

        }
    wait(20, msec);
}
    return 1;
}

*/

/*
int colorsort()
{     
while(1)
{

    g=0;
    if (Controller1.ButtonY.pressing()) 
    {  
        //while((intakedistance.objectDistance(mm)>10 || intakedistance.objectDistance(mm)<=0) && !Controller1.ButtonR2.pressing() && !Controller1.ButtonR1.pressing())
        while(!Controller1.ButtonR2.pressing() && !Controller1.ButtonR1.pressing() && g==0)
        //while(1)
        {    
          

          intake.spin(reverse, 12, volt);
          hook.spin(fwd, 12, volt);
          //printf("originY %d\tcenterY %d\tencoder%lf\n",AIVision3.objects[0].originY, AIVision3.objects[0].centerY, intake.position(degrees));
        
            //if(intakedistance.objectDistance(mm)<10 && AIVision3.objects[0].exists
        
        while(!limitSwitch.pressing() && !Controller1.ButtonR2.pressing() && !Controller1.ButtonR1.pressing() )
        //while(!Controller1.ButtonL2.pressing() && !Controller1.ButtonL1.pressing())
        {
        
          intake.spin(reverse, 12, volt);
          hook.spin(fwd, 12, volt);
          task::sleep(10);
        }  
        // wait(100, msec);   
        intake.stop(); 
        hook.stop(); 
        //wait(350, msec); 

        while(limitSwitch.pressing() && !Controller1.ButtonR2.pressing() && !Controller1.ButtonR1.pressing())
        //while(!Controller1.ButtonL2.pressing() && !Controller1.ButtonL1.pressing())
        {
        
          intake.spin(reverse, 5, volt);
          hook.spin(fwd, 5, volt);
          task::sleep(10);
        } 
        intake.spin(fwd, 12, volt);
        hook.spin(reverse, 12, volt);
        wait(0.25, sec);
        intake.stop(); 
        hook.stop();
        g=1;

        }
      }
    
    
     else if(Controller1.ButtonR1.pressing())
        {   
        intake.spin(reverse, 12, volt);
        hook.spin(fwd, 12, volt);
        }
    
    else if(Controller1.ButtonR2.pressing())
        {
        intake.spin(fwd, 12, volt);
        hook.spin(reverse, 12, volt);
        } 

    else
        {
        intake.stop();
        hook.stop();
        }  
        task::sleep(10);     
    }

 return 0;
}












void hasBlueCallback() {
  Brain.Screen.clearLine(1);
  Brain.Screen.setCursor(1, 1);
  AIVision1.takeSnapshot(AIVision1__BLUEBOX);
  if (AIVision1.objectCount > 0) {
    Brain.Screen.print("Blue Object Found");
  } else {
    Brain.Screen.print("No Blue Object");
  }
}

// Will check to see if there is a red object in view of the ai vision
// sensor and display the result on line 3 on the V5 Brain's screen
void hasRedCallback() {
  Brain.Screen.clearLine(3);
  Brain.Screen.setCursor(3, 1);
  AIVision1.takeSnapshot(AIVision1__REDBOX);
  if (AIVision1.objectCount > 0) {
    Brain.Screen.print("Red Object Found");
  } else {
    Brain.Screen.print("No Red Object");
  }
}

// Will check to see if there is a green object in view of the ai vision
// sensor and display the result on line 5 on the V5 Brain's screen
void hasGreenCallback() {
  Brain.Screen.clearLine(5);
  Brain.Screen.setCursor(5, 1);
  AIVision1.takeSnapshot(AIVision1__GREENBOX);
  if (AIVision1.objectCount > 0) {
    Brain.Screen.print("Green Object Found");
  } else {
    Brain.Screen.print("No Green Object");
  }
}
*/