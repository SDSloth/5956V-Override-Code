/*

#include "vex.h"
using namespace vex;

aivision::colordesc AIVision2__BLUEBOX(1, 36, 69, 85, 28, 0.23);
aivision::colordesc AIVision2__REDBOX(2, 243, 109, 110, 31, 0.49);
aivision::colordesc AIVision2__GREENBOX(3, 214, 254, 97, 39, 0.76);
//aivision::colordesc AIVision2__GREENBOX(3, 214, 254, 97, 18, 0.25);
aivision::colordesc AIVision2__Green(4, 145, 255, 151, 23, 0.2);
enum gameElements {
  mobileGoal,
  redRing,
  blueRing,
};
//aivision::colordesc AIVision1__GREENBOX(3, 66, 117, 48, 10, 0.2);
// AI Vision Code Definitions
vex::aivision AIVision2(PORT18, AIVision2__BLUEBOX, AIVision2__GREENBOX, AIVision2__REDBOX, AIVision2__Green);
//vex::aivision AIVision2(PORT21, aivision::ALL_AIOBJS);


void BackdistanceVisionST(int desiredValue, float desiredTurnValue, int speed, float speeds, float settle_error, float settle_time, float timeout) {
 T1.clear();
 AIVision2.startAwb();
 wait(10, msec);
 settled = false;
 time_spent_running = 0;
 time_spent_settled = 0;
 z = Inertial20.heading();
 if (redringb)
    AIVision2.takeSnapshot(AIVision2__REDBOX);
    else if (blueringb)
    AIVision2.takeSnapshot(AIVision2__BLUEBOX);
    else if (greengoalb)
    AIVision2.takeSnapshot(AIVision2__GREENBOX);
    else if (greenb)
    AIVision2.takeSnapshot(AIVision2__Green);

 //error =  RTMG.objectDistance(mm) - desiredValue;
 error =  desiredValue - Goaldistance.objectDistance(mm);
  while (!settled) {

    //error =  RTMG.objectDistance(mm) - desiredValue;
    error =  desiredValue - Goaldistance.objectDistance(mm);

  if (Goaldistance.objectDistance(mm)<=0 || Goaldistance.objectDistance(mm)>=5000)
    {
      error = prevError-10;
    }

    // Derivative
    derivative = error - prevError;

    // Integral
    if (fabs(error) > integralBound) {
      totalError += error; // totalError = totalError + error;
    } else {
      totalError = 0;
    }

    // This would cap the integral
    totalError = fabs(totalError) > maxIntegral? signnum_c(totalError) * maxIntegral: totalError;
    

    double lateralMotorPower = error * dkP + derivative * dkD + totalError * dkI;
    /////////////////////////////////////////////////////////////////////

    if (lateralMotorPower > speed) {
        lateralMotorPower = speed;
      }
   
      else if (lateralMotorPower < -speed) {
        lateralMotorPower = -speed;
      }

      if (lateralMotorPower>0 && lateralMotorPower < speeds && speeds > 0) 
      {
        lateralMotorPower = speeds;
      }
      else if (lateralMotorPower<0 && lateralMotorPower > -speeds && speeds > 0) 
      {
        lateralMotorPower = -speeds;
      }
  
    //int dturnDifference = leftMotorPosition - rightMotorPosition;
    if (redringb)
    AIVision2.takeSnapshot(AIVision2__REDBOX);
    else if (blueringb)
    AIVision2.takeSnapshot(AIVision2__BLUEBOX);
    else if (greengoalb)
    AIVision2.takeSnapshot(AIVision2__GREENBOX);
    else if (greenb)
    AIVision2.takeSnapshot(AIVision2__Green);
  
   float turnDifference1 = AIVision2.objects[0].centerX - desiredTurnValue;
      

  
      lBase1.spin(forward, lateralMotorPower + turnDifference1 * vkMIG,
                 voltageUnits::volt);
      lBase2.spin(forward, lateralMotorPower + turnDifference1 * vkMIG,
                 voltageUnits::volt);
      lBase3.spin(forward, lateralMotorPower + turnDifference1 * vkMIG,
                 voltageUnits::volt);             
      rBase1.spin(forward, lateralMotorPower - turnDifference1 * vkMIG,
                  voltageUnits::volt);
      rBase2.spin(forward, lateralMotorPower - turnDifference1 * vkMIG,
                  voltageUnits::volt);
      rBase3.spin(forward, lateralMotorPower - turnDifference1 * vkMIG,
                  voltageUnits::volt);
     
   prevError = error;


 if(fabs(error)<settle_error){
        time_spent_settled+=10;
   }
   else { 
        time_spent_settled = 0;
   }

   time_spent_running+=10;


  if (time_spent_running>timeout && timeout != 0){
    settled = true;
  }
 else if (time_spent_settled>settle_time){
    settled = true;
  }
else
  settled = false;

if (backClaw.value() == 1)
{
  break;
  }
  */
/*
  if (!AIVision2.objects[0].exists)
  {
    while (!AIVision2.objects[0].exists)
    {
    if (redring)
    AIVision2.takeSnapshot(AIVision2__REDBOX);
    else if (bluering)
    AIVision2.takeSnapshot(AIVision2__BLUEBOX);
    else if (greengoal)
    AIVision2.takeSnapshot(AIVision2__GREENBOX);

      lBase1.spin(forward, turnspeed, voltageUnits::volt);
      lBase2.spin(forward, turnspeed, voltageUnits::volt);
      lBase3.spin(forward, turnspeed, voltageUnits::volt);
      rBase1.spin(forward, -turnspeed, voltageUnits::volt);  //right
      rBase2.spin(forward, -turnspeed, voltageUnits::volt);
      rBase3.spin(forward, -turnspeed, voltageUnits::volt);
    }
  }
*/
    /*
    //printf("error %f\tturndifference %f\tfrontdistance %f\ttimespentsettled %f\ttimerunning %f\n", error, turnDifference1, Frontdistance.objectDistance(mm),time_spent_settled, time_spent_running);
    printf("centerX %d\tcenterY %d\terror %f\tturndifference %lf\tdistance %0.1f\n",AIVision2.objects[0].centerX, AIVision2.objects[0].centerY, error, turnDifference1, Goaldistance.objectDistance(mm));
    wait(20, msec);
    
  }
   lBase2.setPosition(0, degrees);
   rBase2.setPosition(0, degrees);
   lBase1.spin(fwd, 0, pct);
   lBase2.spin(fwd, 0, pct);
   lBase3.spin(fwd, 0, pct);
   rBase1.spin(fwd, 0, pct);
   rBase2.spin(fwd, 0, pct);
   rBase3.spin(fwd, 0, pct);

}








int BackturnVisionREDtask() {
  if (redring)
  AIVision2.takeSnapshot(AIVision2__REDBOX);
  else if (bluering)
  AIVision2.takeSnapshot(AIVision2__BLUEBOX);
  else if (greengoal)
  AIVision2.takeSnapshot(AIVision2__GREENBOX);

    ///////////////////////////////////////////
    // Turning movement PID
    wait (10, msec);

  while (enableDrivePID) {

    if (resetDriveSensors) {
      resetDriveSensors = false;
      lBase2.setPosition(0, degrees);
      rBase2.setPosition(0, degrees);
    }

    if (redring)
    AIVision2.takeSnapshot(AIVision2__REDBOX);
    else if (bluering)
    AIVision2.takeSnapshot(AIVision2__BLUEBOX);
    else if (greengoal)
    AIVision2.takeSnapshot(AIVision2__GREENBOX);

    lBase1.spin(forward, turnspeed1, voltageUnits::volt);
    lBase2.spin(forward, turnspeed1, voltageUnits::volt);
    lBase3.spin(forward, turnspeed1, voltageUnits::volt);
    rBase1.spin(forward, -turnspeed1, voltageUnits::volt);  //right
    rBase2.spin(forward, -turnspeed1, voltageUnits::volt);
    rBase3.spin(forward, -turnspeed1, voltageUnits::volt);
    ///////////////////////////////////////////
    // Turning movement PID
  if (AIVision2.objects[0].exists) {
    
    //vturnError = FrontVision.largestObject.centerX - vdesiredTurnValue; //turn error
    turnError =  AIVision2.objects[0].centerX - desiredTurnValue;

    // Derivative
    turnDerivative = turnError - turnPrevError;

    // Integral
    if (fabs(error) < integralBound) {
      turnTotalError += turnError;
    } else {
      turnTotalError = 0;
    }
    // turnTotalError = turnTotalError + turnError;

    // This would cap the integral
    turnTotalError = fabs(turnTotalError) > maxIntegral
                         ? signnum_c(turnTotalError) * maxIntegral
                         : turnTotalError;

    double turnMotorPower =
        turnError * vturnkP + turnDerivative * vturnkD + turnTotalError * vturnkI;

    
      if (turnMotorPower > turnspeed) {
        turnMotorPower = turnspeed;
      }
   
      else if (turnMotorPower < -turnspeed) {
        turnMotorPower = -turnspeed;
      }

    /////////////////////////////////////////////////////////////////////

    
      lBase1.spin(forward, turnMotorPower, voltageUnits::volt);
      lBase2.spin(forward, turnMotorPower, voltageUnits::volt);
      lBase3.spin(forward, turnMotorPower, voltageUnits::volt);
      rBase1.spin(forward, -turnMotorPower, voltageUnits::volt);  //right
      rBase2.spin(forward, -turnMotorPower, voltageUnits::volt);
      rBase3.spin(forward, -turnMotorPower, voltageUnits::volt);
    

    //printf("centerX %f\toriginX %f/tcenterY %f\t error%f\t motorpower%lf\n",AIVision1.objects[0].centerX, AIVision1.objects[0].originX, AIVision1.objects[0].centerY, turnError, turnMotorPower);
   

    turnPrevError = turnError;

     //printf("%ld\n", poten.value(mV));
    vex::task::sleep(20); // don't hog CPU. This makes all tasks run faster.
  }
  }
  redring = false;

  return 1;
}




void BackturnVisionST(float desiredTurnValue, float turnspeed, float turnspeed1, float settle_error, float settle_time, float timeout) {
  AIVision2.startAwb();
 wait(10, msec);
  settled = false;
  time_spent_running = 0;
  time_spent_settled = 0;

 
  z = Inertial20.heading();
  
  if (redringb)
  AIVision2.takeSnapshot(AIVision2__REDBOX);
  else if (blueringb)
  AIVision2.takeSnapshot(AIVision2__BLUEBOX);
  else if (greengoalb)
  AIVision2.takeSnapshot(AIVision2__GREENBOX);
  else if (greenb)
  AIVision2.takeSnapshot(AIVision2__Green);
    ///////////////////////////////////////////
    // Turning movement PID
    wait (10, msec);

  while (!AIVision2.objects[0].exists) {

  if (redringb)
  AIVision2.takeSnapshot(AIVision2__REDBOX);
  else if (blueringb)
  AIVision2.takeSnapshot(AIVision2__BLUEBOX);
  else if (greengoalb)
  AIVision2.takeSnapshot(AIVision2__GREENBOX);
  else if (greenb)
  AIVision2.takeSnapshot(AIVision2__Green);

    lBase1.spin(forward, turnspeed1, voltageUnits::volt);
    lBase2.spin(forward, turnspeed1, voltageUnits::volt);
    lBase3.spin(forward, turnspeed1, voltageUnits::volt);
    rBase1.spin(forward, -turnspeed1, voltageUnits::volt);  //right
    rBase2.spin(forward, -turnspeed1, voltageUnits::volt);
    rBase3.spin(forward, -turnspeed1, voltageUnits::volt);
    ///////////////////////////////////////////
    // Turning movement PID
  }
  
  
   turnError =   AIVision2.objects[0].centerX - desiredTurnValue;
    
   
   while (!settled) {
  if (redringb)
  AIVision2.takeSnapshot(AIVision2__REDBOX);
  else if (blueringb)
  AIVision2.takeSnapshot(AIVision2__BLUEBOX);
  else if (greengoalb)
  AIVision2.takeSnapshot(AIVision2__GREENBOX);
  else if (greenb)
  AIVision2.takeSnapshot(AIVision2__Green);

    turnError =   AIVision2.objects[0].centerX - desiredTurnValue;
    // Derivative
    turnDerivative = turnError - turnPrevError;

    // Integral
    if (fabs(error) < integralBound) {
      turnTotalError += turnError;
    } else {
      turnTotalError = 0;
    }
    // turnTotalError = turnTotalError + turnError;

    // This would cap the integral
    turnTotalError = fabs(turnTotalError) > maxIntegral
                         ? signnum_c(turnTotalError) * maxIntegral
                         : turnTotalError;

    double turnMotorPower =
        turnError * vturnkP + turnDerivative * vturnkD + turnTotalError * vturnkI;

    
      if (turnMotorPower > turnspeed) {
        turnMotorPower = turnspeed;
      }
   
      else if (turnMotorPower < -turnspeed) {
        turnMotorPower = -turnspeed;
      }
    

    /////////////////////////////////////////////////////////////////////

    
      lBase1.spin(forward, turnMotorPower, voltageUnits::volt);
      lBase2.spin(forward, turnMotorPower, voltageUnits::volt);
      lBase3.spin(forward, turnMotorPower, voltageUnits::volt);
      rBase1.spin(forward, -turnMotorPower, voltageUnits::volt);  //right
      rBase2.spin(forward, -turnMotorPower, voltageUnits::volt);
      rBase3.spin(forward, -turnMotorPower, voltageUnits::volt);
    


   turnPrevError = turnError;

   if(fabs(turnError)<settle_error){
        time_spent_settled+=10;
   }
   else { 
        time_spent_settled = 0;
   }

   time_spent_running+=10;


  if (time_spent_running>timeout && timeout != 0){
    settled = true;
  }
  else if (time_spent_settled>settle_time){
    settled = true;
  }
else
  settled = false;


    //printf("centerX %d\toriginX %d/tcenterY %d\t error%d\t motorpower%lf\n",FrontVision1.largestObject.centerX, FrontVision1.largestObject.originX, FrontVision1.largestObject.centerY, vturnError, vturnMotorPower);
   printf("centerX %d\toriginX %d\tcenterY %d\t error%f\t motorpower%lf\n",AIVision2.objects[0].centerX, AIVision2.objects[0].originX, AIVision2.objects[0].centerY, turnError, turnMotorPower);
 wait(10, msec);
    
  }
   
   lBase1.spin(fwd, 0, pct);
   lBase2.spin(fwd, 0, pct);
   lBase3.spin(fwd, 0, pct);
   rBase1.spin(fwd, 0, pct);
   rBase2.spin(fwd, 0, pct);
   rBase3.spin(fwd, 0, pct);
  }
  





void BackYVisionST(int desiredValue, float desiredTurnValue, int speed, int speeds, float settle_error, float settle_time, float timeout) {
T1.clear();
settled = false;
time_spent_running = 0;
time_spent_settled = 0;
lBase2.setPosition(0, degrees);
rBase2.setPosition(0, degrees);

//AIVision2.takeSnapshot(aivision::ALL_AIOBJS);

if (redring)
    AIVision2.takeSnapshot(AIVision2__REDBOX);
    else if (bluering)
    AIVision2.takeSnapshot(AIVision2__BLUEBOX);
    else if (greengoal)
    AIVision2.takeSnapshot(AIVision2__GREENBOX);

error = AIVision2.objects[0].centerY - desiredValue;

//if (AIVision2.objects[0].id == mobileGoal)
//{

if (AIVision2.objects[0].exists)
{

while (!settled) {
//while(true){
    // Get the position of both motors
    int leftMotorPosition = AIVision2.objects[0].centerY;
    //int rightMotorPosition = rBase2.position(degrees);

    error = leftMotorPosition - desiredValue; // forward with postitive encoder value
    // error = leftMotorPosition - desiredValue; //reverse with negative encoder value
    // Derivative
    derivative = error - prevError;
    // Integral
    if (fabs(error) > integralBound) {
      totalError += error; // totalError = totalError + error;
    } else {
      totalError = 0;
    }
    // This would cap the integral
    totalError = fabs(totalError) > maxIntegral? signnum_c(totalError) * maxIntegral: totalError;
   

    lateralMotorPower = error * kP + derivative * kD + totalError * kI;
    /////////////////////////////////////////////////////////////////////

    
      if (lateralMotorPower > speed) 
      {
        lateralMotorPower = speed;
      }
      else if (lateralMotorPower < - speed) 
      {
        lateralMotorPower = -speed;
      }

      if (lateralMotorPower>0 && lateralMotorPower < speeds && speeds > 0) 
      {
        lateralMotorPower = speeds;
      }
      else if (lateralMotorPower<0 && lateralMotorPower > -speeds && speeds > 0) 
      {
        lateralMotorPower = -speeds;
      }

    

    if (redring)
    AIVision2.takeSnapshot(AIVision2__REDBOX);
    else if (bluering)
    AIVision2.takeSnapshot(AIVision2__BLUEBOX);
    else if (greengoal)
    AIVision2.takeSnapshot(AIVision2__GREENBOX);
  
  //AIVision2.takeSnapshot(aivision::ALL_AIOBJS);

   float turnDifference1 = AIVision2.objects[0].centerX - desiredTurnValue;
      

  
      lBase1.spin(forward, lateralMotorPower + turnDifference1 * vkMIG,
                 voltageUnits::volt);
      lBase2.spin(forward, lateralMotorPower + turnDifference1 * vkMIG,
                 voltageUnits::volt);
      lBase3.spin(forward, lateralMotorPower + turnDifference1 * vkMIG,
                 voltageUnits::volt);              
      rBase1.spin(forward, lateralMotorPower - turnDifference1 * vkMIG,
                  voltageUnits::volt);
      rBase2.spin(forward, lateralMotorPower - turnDifference1 * vkMIG,
                  voltageUnits::volt);
      rBase3.spin(forward, lateralMotorPower - turnDifference1 * vkMIG,
                  voltageUnits::volt);
        

                  
    prevError = error;

    if(fabs(error)<settle_error){
        time_spent_settled+=10;
   }
   else { 
        time_spent_settled = 0;
   }

   time_spent_running+=10;


  if (time_spent_running>timeout && timeout != 0){
    settled = true;
  }
  else if (time_spent_settled>settle_time){
    settled = true;
  }
  else 
  settled = false;

   //printf("error %0.1f\tlatteralpower %0.1f\tturndifference %0.1f\tInertial %0.1f\ttimespentsettled %0.1f\ttimerunning %0.1f\n",error, lateralMotorPower, turnDifference1, Inertial20.heading(), time_spent_settled, time_spent_running);
   //wait(10, msec);
   printf("X %d\tY %d\t W %d\tH %d\terror%f\t turndifference%lf\n",AIVision2.objects[0].centerX, AIVision2.objects[0].centerY, AIVision2.objects[0].width, AIVision2.objects[0].height, error, turnDifference1);
    wait(10, msec);

  }
  //printf("error %f\tturndifference %f\tInertial %f\n",error, turnDifference1, Inertial20.heading());
   //lBase2.setPosition(0, degrees);
   //rBase2.setPosition(0, degrees);
    lBase1.spin(fwd, 0, pct);
    lBase2.spin(fwd, 0, pct);
    lBase3.spin(fwd, 0, pct);
    
    rBase1.spin(fwd, 0, pct);
    rBase2.spin(fwd, 0, pct);
    rBase3.spin(fwd, 0, pct);
    
}
}
*/

/*
void BackstraightVisionST(int desiredValue, float desiredTurnValue, int speed, int speeds, float settle_error, float settle_time, float timeout) {
T1.clear();
settled = false;
time_spent_running = 0;
time_spent_settled = 0;
lBase2.setPosition(0, degrees);
rBase2.setPosition(0, degrees);

error = desiredValue - lBase2.position(degrees);
while (!settled) {
//while(true){
    // Get the position of both motors
    int leftMotorPosition = lBase2.position(degrees);
    //int rightMotorPosition = rBase2.position(degrees);

    error = desiredValue - leftMotorPosition; // forward with postitive encoder value
    // error = leftMotorPosition - desiredValue; //reverse with negative encoder value
    // Derivative
    derivative = error - prevError;
    // Integral
    if (fabs(error) > integralBound) {
      totalError += error; // totalError = totalError + error;
    } else {
      totalError = 0;
    }
    // This would cap the integral
    totalError = fabs(totalError) > maxIntegral? signnum_c(totalError) * maxIntegral: totalError;
   

    lateralMotorPower = error * kP + derivative * kD + totalError * kI;
    /////////////////////////////////////////////////////////////////////

    
      if (lateralMotorPower > speed) 
      {
        lateralMotorPower = speed;
      }
      else if (lateralMotorPower < - speed) 
      {
        lateralMotorPower = -speed;
      }

      if (lateralMotorPower>0 && lateralMotorPower < speeds && speeds > 0) 
      {
        lateralMotorPower = speeds;
      }
      else if (lateralMotorPower<0 && lateralMotorPower > -speeds && speeds > 0) 
      {
        lateralMotorPower = -speeds;
      }
/*
      if (lateralMotorPower > -speeds && speeds > 0) 
      {
        lateralMotorPower = -speeds;
      }


      if (lateralMotorPower < speeds && speeds > 0) 
      {
        lateralMotorPower = speeds;
      }
      */
      //else if (lateralMotorPower > - speeds && speeds > 0) 
      //{
        //lateralMotorPower = -speeds;
      //}
    /*

    if (redring)
    AIVision2.takeSnapshot(AIVision2__REDBOX);
    else if (bluering)
    AIVision2.takeSnapshot(AIVision2__BLUEBOX);
    else if (greengoal)
    AIVision2.takeSnapshot(AIVision2__GREENBOX);
  
   float turnDifference1 = AIVision2.objects[0].centerX - desiredTurnValue;
      

  
      lBase1.spin(forward, lateralMotorPower + turnDifference1 * vkMI,
                 voltageUnits::volt);
      lBase2.spin(forward, lateralMotorPower + turnDifference1 * vkMI,
                 voltageUnits::volt);
      lBase3.spin(forward, lateralMotorPower + turnDifference1 * vkMI,
                 voltageUnits::volt);              
      rBase1.spin(forward, lateralMotorPower - turnDifference1 * vkMI,
                  voltageUnits::volt);
      rBase2.spin(forward, lateralMotorPower - turnDifference1 * vkMI,
                  voltageUnits::volt);
      rBase3.spin(forward, lateralMotorPower - turnDifference1 * vkMI,
                  voltageUnits::volt);
        

                  
    prevError = error;

    if(fabs(error)<settle_error){
        time_spent_settled+=10;
   }
   else { 
        time_spent_settled = 0;
   }

   time_spent_running+=10;


  if (time_spent_running>timeout && timeout != 0){
    settled = true;
  }
  else if (time_spent_settled>settle_time){
    settled = true;
  }
  else 
  settled = false;

   //printf("error %0.1f\tlatteralpower %0.1f\tturndifference %0.1f\tInertial %0.1f\ttimespentsettled %0.1f\ttimerunning %0.1f\n",error, lateralMotorPower, turnDifference1, Inertial20.heading(), time_spent_settled, time_spent_running);
   //wait(10, msec);
   printf("centerX %d\tcenterY %d\t error%f\t turndifference%lf\n",AIVision2.objects[0].centerX, AIVision2.objects[0].centerY, error, turnDifference1);
    wait(10, msec);

  }
  //printf("error %f\tturndifference %f\tInertial %f\n",error, turnDifference1, Inertial20.heading());
   //lBase2.setPosition(0, degrees);
   //rBase2.setPosition(0, degrees);
    lBase1.spin(fwd, 0, pct);
    lBase2.spin(fwd, 0, pct);
    lBase3.spin(fwd, 0, pct);
    
    rBase1.spin(fwd, 0, pct);
    rBase2.spin(fwd, 0, pct);
    rBase3.spin(fwd, 0, pct);
    
}

*/
/*

void BackdistanceVisionST2(int desiredValue, float desiredTurnValue, int speed, float speeds, float settle_error, float settle_time, float timeout) {
 T1.clear();
 settled = false;
 time_spent_running = 0;
 time_spent_settled = 0;
 z = Inertial20.heading();
 if (redringb)
    AIVision2.takeSnapshot(AIVision2__REDBOX);
    else if (blueringb)
    AIVision2.takeSnapshot(AIVision2__BLUEBOX);
    else if (greengoalb)
    AIVision2.takeSnapshot(AIVision2__GREENBOX);

 //error =  RTMG.objectDistance(mm) - desiredValue;
 error =  desiredValue - Backdistance.objectDistance(mm);
  while (!settled) {

    //error =  RTMG.objectDistance(mm) - desiredValue;
    error =  desiredValue - Backdistance.objectDistance(mm);

  if (Backdistance.objectDistance(mm)<=0 || Backdistance.objectDistance(mm)>=5000)
    {
      error = prevError-10;
    }

    // Derivative
    derivative = error - prevError;

    // Integral
    if (fabs(error) > integralBound) {
      totalError += error; // totalError = totalError + error;
    } else {
      totalError = 0;
    }

    // This would cap the integral
    totalError = fabs(totalError) > maxIntegral? signnum_c(totalError) * maxIntegral: totalError;
    

    double lateralMotorPower = error * dkP + derivative * dkD + totalError * dkI;
    /////////////////////////////////////////////////////////////////////

    if (lateralMotorPower > speed) {
        lateralMotorPower = speed;
      }
   
      else if (lateralMotorPower < -speed) {
        lateralMotorPower = -speed;
      }

      if (lateralMotorPower>0 && lateralMotorPower < speeds && speeds > 0) 
      {
        lateralMotorPower = speeds;
      }
      else if (lateralMotorPower<0 && lateralMotorPower > -speeds && speeds > 0) 
      {
        lateralMotorPower = -speeds;
      }
  
    //int dturnDifference = leftMotorPosition - rightMotorPosition;
    if (redringb)
    AIVision2.takeSnapshot(AIVision2__REDBOX);
    else if (blueringb)
    AIVision2.takeSnapshot(AIVision2__BLUEBOX);
    else if (greengoalb)
    AIVision2.takeSnapshot(AIVision2__GREENBOX);
  
   float turnDifference1 = AIVision2.objects[0].centerX - desiredTurnValue;
      

  
      lBase1.spin(forward, lateralMotorPower + turnDifference1 * vkMIG,
                 voltageUnits::volt);
      lBase2.spin(forward, lateralMotorPower + turnDifference1 * vkMIG,
                 voltageUnits::volt);
      lBase3.spin(forward, lateralMotorPower + turnDifference1 * vkMIG,
                 voltageUnits::volt);             
      rBase1.spin(forward, lateralMotorPower - turnDifference1 * vkMIG,
                  voltageUnits::volt);
      rBase2.spin(forward, lateralMotorPower - turnDifference1 * vkMIG,
                  voltageUnits::volt);
      rBase3.spin(forward, lateralMotorPower - turnDifference1 * vkMIG,
                  voltageUnits::volt);
     
   prevError = error;


 if(fabs(error)<settle_error){
        time_spent_settled+=10;
   }
   else { 
        time_spent_settled = 0;
   }

   time_spent_running+=10;


  if (time_spent_running>timeout && timeout != 0){
    settled = true;
  }
 else if (time_spent_settled>settle_time){
    settled = true;
  }
else
  settled = false;
*/

/*
  if (!AIVision2.objects[0].exists)
  {
    while (!AIVision2.objects[0].exists)
    {
    if (redring)
    AIVision2.takeSnapshot(AIVision2__REDBOX);
    else if (bluering)
    AIVision2.takeSnapshot(AIVision2__BLUEBOX);
    else if (greengoal)
    AIVision2.takeSnapshot(AIVision2__GREENBOX);

      lBase1.spin(forward, turnspeed, voltageUnits::volt);
      lBase2.spin(forward, turnspeed, voltageUnits::volt);
      lBase3.spin(forward, turnspeed, voltageUnits::volt);
      rBase1.spin(forward, -turnspeed, voltageUnits::volt);  //right
      rBase2.spin(forward, -turnspeed, voltageUnits::volt);
      rBase3.spin(forward, -turnspeed, voltageUnits::volt);
    }
  }
*/
    /*
    //printf("error %f\tturndifference %f\tfrontdistance %f\ttimespentsettled %f\ttimerunning %f\n", error, turnDifference1, Frontdistance.objectDistance(mm),time_spent_settled, time_spent_running);
    printf("centerX %d\tcenterY %d\terror %f\tturndifference %lf\tdistance %0.1f\n",AIVision2.objects[0].centerX, AIVision2.objects[0].centerY, error, turnDifference1, RTMG.objectDistance(mm));
    wait(10, msec);
    
  }
   lBase2.setPosition(0, degrees);
   rBase2.setPosition(0, degrees);
   lBase1.spin(fwd, 0, pct);
   lBase2.spin(fwd, 0, pct);
   lBase3.spin(fwd, 0, pct);
   rBase1.spin(fwd, 0, pct);
   rBase2.spin(fwd, 0, pct);
   rBase3.spin(fwd, 0, pct);

}*/