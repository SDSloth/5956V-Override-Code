#include "vex.h"
using namespace vex;

void BackClamp() {              //holds expansion in position
  if (backClaw.value() == 0) {

    backClaw.open();
  }
  else if(backClaw.value() == 1) {
    
    backClaw.close();
  }
}
