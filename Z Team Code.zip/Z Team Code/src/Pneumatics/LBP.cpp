#include "vex.h"
using namespace vex;

void LBP() {              //holds expansion in position
  if (lbp.value() == 0) {

    lbp.open();
  }
  else if(lbp.value() == 1) {
    
    lbp.close();
  }
}
