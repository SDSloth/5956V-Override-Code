#include "vex.h"
using namespace vex;

void LBP2() {              //holds expansion in position
  if (lbp2.value() == 0) {

    lbp2.open();
  }
  else if(lbp2.value() == 1) {
    
    lbp2.close();
  }
}
