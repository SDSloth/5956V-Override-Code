#include "vex.h"
using namespace vex;

void DoinkL() {              //holds expansion in position
  if (doinkL.value() == 0) {

    doinkL.open();
  }
  else if(doinkL.value() == 1) {
    
    doinkL.close();
  }
}
