#include "vex.h"
using namespace vex;

void DoinkR() {              //holds expansion in position
  if (doinkR.value() == 0) {

    doinkR.open();
  }
  else if(doinkR.value() == 1) {
    
    doinkR.close();
  }
}
