#include "vex_addrled.h"
#include "vex.h"
//#include "robot-config.h"
using namespace vex;

addressable_led addrled(vex::triport(PORT12).C, 10 );
addressable_led addrled1(vex::triport(PORT19).C, 56 );
addressable_led addrled2(vex::triport(PORT20).C, 56 );

int ledrainbowj() {    
    // set all led black
    // probably need some initial delay, TBD
// local storage for some pixel data
uint32_t data[addressable_led::MAX_LEDS];
    //this_thread::sleep_for(200);    
    addrled.clear();
    wait(50, msec);  
       
       memset(data, 0, sizeof(data));
        for( int i=0;i<addrled.max();i+=12 ) {
          vex::color c;
          // use low value to keep current down
          for(int j=0;j<12;j++)
            data[i+j] = c.hsv(  j*30, 1, 0.4);    // vex color will be converted to uint32_t
        }
        addrled.set( data, 0, addrled.max(), 0 );

    while(1) {        
    
        
        //this_thread::sleep_for(1000);    

        for( int i=0;i<addrled.max()-1;i++ ) {
          addrled.rotate(1);
          addrled.flush();
          wait(50, msec);
        }

        vex::task::sleep(10);
    }

    // turn all off
    //addrled.clear();
/*
    while(1) {
        // Allow other tasks to run
        
    }
    */
    return 0;
}


int ledpinkj() {    
    // set all led black
    // probably need some initial delay, TBD
// local storage for some pixel data
//uint32_t data[addressable_led::MAX_LEDS];
    //this_thread::sleep_for(200);    
    addrled.clear();
    addrled1.clear();
    addrled2.clear();
    wait(50, msec);   

    while(1) {        
        addrled.clear( color(150,0,120) );
        addrled1.clear( color(150,0,120) );
        addrled2.clear( color(150,0,120) );
        wait(50, msec);
        addrled.clear();
        addrled1.clear();
        addrled2.clear();
        wait(50, msec);
        vex::task::sleep(10);
    }
    return 0;
}

int ledpurplej() {    
    // set all led black
    // probably need some initial delay, TBD
// local storage for some pixel data
//uint32_t data[addressable_led::MAX_LEDS];
    //this_thread::sleep_for(200);    
    addrled.clear();
    addrled1.clear();
    addrled2.clear();
    wait(50, msec);   

    while(1) {        
        addrled.clear( color(150,0,150) );
        addrled1.clear( color(150,0,150) );
        addrled2.clear( color(150,0,150) );
        wait(50, msec);
        addrled.clear();
        addrled1.clear();
        addrled2.clear();
        wait(50, msec);
        vex::task::sleep(10);
    }
    return 0;
}

int bangarang()
{
  this_thread::sleep_for(100);    
    //addrled.clear();
    addrled.clear();
    addrled1.clear();
    addrled2.clear();
    this_thread::sleep_for(200); 
    while(1) { 

// set one led at a time
        for( int i=0; i<addrled.max(); i++) {
          uint32_t c = color(0,150,150);
          addrled.set( &c, i, 1, 0 );
          addrled1.set( &c, i, 1, 0 );
          addrled2.set( &c, i, 1, 0 );
          this_thread::sleep_for(50);

    
        }
        

        for( int i=addrled.max(); i>=0; i--) {
          uint32_t c = color(150,0,150);
          addrled.set( &c, i, 1, 0 );
          addrled1.set( &c, i, 1, 0 );
          addrled2.set( &c, i, 1, 0 );
          this_thread::sleep_for(50);

      
        }
   
    } 
    return 0;
}
