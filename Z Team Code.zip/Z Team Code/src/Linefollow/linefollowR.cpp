#include "vex.h"
using namespace vex;

int linefollowR()
{
while(1)
{
 if(linetrackerR.reflectivity(percent)>70)
 {
  while(linetrackerR.reflectivity(percent)>70 ) 
  {

  }

 while(linetrackerR.reflectivity(percent)<70)
  {

  }

g=1;
}
task::sleep(100);
}
return 0;
}