#include "vex.h"
using namespace vex;

int linefollowL()
{
while(1)
{
 if(linetrackerL.reflectivity(percent)>70)
 {
  while(linetrackerL.reflectivity(percent)>70 ) 
  {

  }

 while(linetrackerL.reflectivity(percent)<70)
  {

  }

g=1;
}
task::sleep(100);
  
}
  return 0;
}