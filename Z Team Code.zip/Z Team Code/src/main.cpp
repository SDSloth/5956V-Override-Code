#include "vex.h"
#include "vex_addrled.h"

using namespace vex;
competition Competition;

/*---------------------------------------------------------------------------*/
/*                             VEXcode Config                                */
/*                                                                           */
/*  Before you do anything else, start by configuring your motors and        */
/*  sensors using the V5 port icon in the top right of the screen. Doing     */
/*  so will update robot-config.cpp and robot-config.h automatically, so     */
/*  you don't have to. Ensure that your motors are reversed properly. For    */
/*  the drive, spinning all motors forward should drive the robot forward.   */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/*                             JAR-Template Config                           */
/*                                                                           */
/*  Where all the magic happens. Follow the instructions below to input      */
/*  all the physical constants and values for your robot. You should         */
/*  already have configured your robot manually with the sidebar configurer. */
/*---------------------------------------------------------------------------*/


Drive chassis(

//Specify your drive setup below. There are seven options:
//ZERO_TRACKER_NO_ODOM, ZERO_TRACKER_ODOM, TANK_ONE_ENCODER, TANK_ONE_ROTATION, TANK_TWO_ENCODER, TANK_TWO_ROTATION, HOLONOMIC_TWO_ENCODER, and HOLONOMIC_TWO_ROTATION
//For example, if you are not using odometry, put ZERO_TRACKER_NO_ODOM below:
ZERO_TRACKER_ODOM,
//TANK_TWO_ROTATION,
//TANK_ONE_ROTATION,
//TANK_ONE_SIDEWAYS_ROTATION,

//Add the names of your Drive motors into the motor groups below, separated by commas, i.e. motor_group(Motor1,Motor2,Motor3).
//You will input whatever motor names you chose when you configured your robot using the sidebar configurer, they don't have to be "Motor1" and "Motor2".

//Left Motors:
motor_group(lBase1, lBase2, lBase3),

//Right Motors:
motor_group(rBase1, rBase2, rBase3),

//Specify the PORT NUMBER of your inertial sensor, in PORT format (i.e. "PORT1", not simply "1"):
PORT14,

//Input your wheel diameter. (4" omnis are actually closer to 4.125"):
3.25,

//External ratio, must be in decimal, in the format of input teeth/output teeth.
//If your motor has an 84-tooth gear and your wheel has a 60-tooth gear, this value will be 1.4.
//If the motor drives the wheel directly, this value is 1:
0.75,

//Gyro scale, this is what your gyro reads when you spin the robot 360 degrees.
//For most cases 360 will do fine here, but this scale factor can be very helpful when precision is necessary.
360,

/*---------------------------------------------------------------------------*/
/*                                  PAUSE!                                   */
/*                                                                           */
/*  The rest of the drive constructor is for robots using POSITION TRACKING. */
/*  If you are not using position tracking, leave the rest of the values as  */
/*  they are.                                                                */
/*---------------------------------------------------------------------------*/

//If you are using ZERO_TRACKER_ODOM, you ONLY need to adjust the FORWARD TRACKER CENTER DISTANCE.

//FOR HOLONOMIC DRIVES ONLY: Input your drive motors by position. This is only necessary for holonomic drives, otherwise this section can be left alone.
//LF:      //RF:    
PORT22,     -PORT22,

//LB:      //RB: 
PORT22,     -PORT22,

//If you are using position tracking, this is the Forward Tracker port (the tracker which runs parallel to the direction of the chassis).
//If this is a rotation sensor, enter it in "PORT1" format, inputting the port below.
//If this is an encoder, enter the port as an integer. Triport A will be a "1", Triport B will be a "2", etc.
PORT22,

//Input the Forward Tracker diameter (reverse it to make the direction switch):
2.75,

//Input Forward Tracker center distance (a positive distance corresponds to a tracker on the right side of the robot, negative is left.)
//For a zero tracker tank drive with odom, put the positive distance from the center of the robot to the right side of the drive.
//This distance is in inches:
7,

//Input the Sideways Tracker Port, following the same steps as the Forward Tracker Port:
PORT22,

//Sideways tracker diameter (reverse to make the direction switch):
2.75,

//Sideways tracker center distance (positive distance is behind the center of the robot, negative is in front):
-2.5

);

int current_auton_selection = 0;
bool auto_started = false;

void pre_auton(void) {
  
  // Initializes robot configuration
  vexcodeInit();

  // Calibrates inertial sensor
  Inertial20.calibrate();
  while (Inertial20.isCalibrating()) {
    wait(20, msec);
  }
    

  default_constants();
  Brain.Screen.clearScreen();
  Inertial20.setHeading(0, deg);
  /*
  int bx = Brain.Screen.xPosition();
  int by = Brain.Screen.yPosition();
  int btnx = 250;
  int btnwidth = 230;
  int btnheight = 40;
  int skillsy = 120;
  int redy = 170;
  int bluey = 220;
*/
  while(!auto_started){
    
    Brain.Screen.printAt(5, 20, "5956Z");
    Brain.Screen.printAt(5, 40, "Battery Percentage:");
    Brain.Screen.printAt(5, 60, "%d", Brain.Battery.capacity());
    Brain.Screen.printAt(5, 80, "Chassis Heading Reading:");
    Brain.Screen.printAt(5, 100, "%f", chassis.get_absolute_heading());

/*
  Brain.Screen.drawRectangle(btnx, skillsy, btnwidth, btnheight, color::purple);   // Button 1
  Brain.Screen.drawRectangle(btnx, redy, btnwidth, btnheight, color::red);    // Button 2
  Brain.Screen.drawRectangle(btnx, bluey, btnwidth, btnheight, color::blue);  // Button 3

  Brain.Screen.setPenColor(color::white);
  Brain.Screen.printAt(300, 145, "Skills");
  Brain.Screen.printAt(300, 195, "SixBlockRed");
  Brain.Screen.printAt(300, 245, "SixBlockBlue");
  */
  Brain.Screen.printAt(5, 120, "Selected Auton:");

    switch(current_auton_selection){
      case 0:
        Brain.Screen.setPenColor(color::yellow);        
        Brain.Screen.printAt(5, 140, "Skills");
        break;
      case 1:
        Brain.Screen.setPenColor(color::blue);
        Brain.Screen.printAt(5, 140, "RightAuto");
        break;
      case 2:
        Brain.Screen.setPenColor(color::red);
        Brain.Screen.printAt(5, 140, "LeftAuto");
        break;
    //  case 3:
      //  Brain.Screen.setPenColor(color::green);
  //      Brain.Screen.printAt(5, 140, "LeftElims");
//        break;
        /*
      case 4:
        Brain.Screen.printAt(5, 140, "dont run");
        break;
      case 5:
        Brain.Screen.printAt(5, 140, "dont run");
        break;
      case 6:
        Brain.Screen.printAt(5, 140, "dont run");
        break;
      case 7:
        Brain.Screen.printAt(5, 140, "dont run");
        break;
      case 8:
        Brain.Screen.printAt(5, 140, "dont run");
        break;
        */
    }

    if(Brain.Screen.pressing()){
      Brain.Screen.clearScreen();
      while(Brain.Screen.pressing()) {}
      current_auton_selection ++;
    } else if (current_auton_selection == 3){
      current_auton_selection = 0;
    }

/*
    if(Brain.Screen.pressing()){
      Brain.Screen.clearScreen();
      while(bx < btnx && bx > btnx + btnwidth){
        if(by < skillsy && by > skillsy + btnwidth){
          current_auton_selection = 0;
          }
        else if(by < redy && by > redy + btnwidth){
          current_auton_selection = 1;
        }
        else if(by < bluey && by > bluey + btnwidth){
          current_auton_selection = 2;
        }
      }
      }
*/
   // Brain.Screen.printAt(100,160, "Intake Motor Temp:%d", Intake.temperature(vex::temperatureUnits::fahrenheit));
    //Brain.Screen.printAt(100,180, "Transition Motor Temp:%d", Transition.temperature(vex::temperatureUnits::fahrenheit));
    //Brain.Screen.printAt(100,200, "Outtake Motor Temp:%d", Outtake.temperature(vex::temperatureUnits::fahrenheit));
  const double COOL = 100.0;
  const double WARM = 140.0;

  // Intake
  double intakeTemp = Intake.temperature(vex::temperatureUnits::fahrenheit);
  if (intakeTemp < COOL)
    Brain.Screen.setPenColor(vex::color::green);
  else if (intakeTemp < WARM)
    Brain.Screen.setPenColor(vex::color::yellow);
  else
    Brain.Screen.setPenColor(vex::color::red);
  Brain.Screen.printAt(5,160, "Intake Temp: %.1f°F", intakeTemp);

  // Transition
  double transTemp = Transition.temperature(vex::temperatureUnits::fahrenheit);
  if (transTemp < COOL)
    Brain.Screen.setPenColor(vex::color::green);
  else if (transTemp < WARM)
    Brain.Screen.setPenColor(vex::color::yellow);
  else
    Brain.Screen.setPenColor(vex::color::red);
  Brain.Screen.printAt(5,180, "Transition Temp: %.1f°F", transTemp);

  // Outtake
  double outTemp = Outtake.temperature(vex::temperatureUnits::fahrenheit);
  if (outTemp < COOL)
    Brain.Screen.setPenColor(vex::color::green);
  else if (outTemp < WARM)
    Brain.Screen.setPenColor(vex::color::yellow);
  else
    Brain.Screen.setPenColor(vex::color::red);
  Brain.Screen.printAt(5,200, "Outtake Temp: %.1f°F", outTemp);

  // Reset color to white for other text
  Brain.Screen.setPenColor(vex::color::white);

    task::sleep(10);
  }
}


void autonomous(void) {
  // auto_started = true;
  
  
//task t8000(autoPath);
  //chassis.set_coordinates(0,0,0);
  default_constants();

  switch(current_auton_selection){  
    case 0:
      simpleSkills(); //This is the default auton, if you don't select from the brain.
      break;        //Change these to be your own auton functions in order to use the auton selector.
    case 1:         //Tap the screen to cycle through autons.
      newrightelims();
      break;
    case 2:
      newleftelims();
      break;
  //  case 3:
    //  LeftElims();
      //break;
      /*

    case 4:
      RedWithStake();
      break;
    case 5:
      BlueWithStake();
      break;
    case 6:
      RedElims();
      break;
    case 7:
      BlueElims();
      break;
    case 8:
      Skills();
      break;
   */
          
 }
      
   
          
 }
      

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/



void usercontrol(void) {
auto_started = true;



  // /*
  // take out inertial calibration

  Inertial20.calibrate();
  
  while (Inertial20.isCalibrating()) {
    wait(20, msec);
  }
   
  greengoalb=true;
  default_constants();
  // */
  
newleftelims();
//Setup();
//newskills();
//leftSAWP();
//newleftelims();
//rightSAWP();
//newrightelims();
//simpleSkills();

  /*
  breakdistance = -10;
  breakoutR = true;
  chassis.drive_distance(-50, 245, 10, 10, 10);
  Tongue.close();
  chassis.drive_distance(-20, 270, 10, 10, 10);
  breakoutR = false;
  chassis.drive_distance(-68, 270, 10, 10, 10);
  chassis.right_swing_to_angle(90);
  BackstraightVisionST(-1350, 160, 6, 0, 5, 0, 1200);
  */

/*
chassis.set_coordinates(0, 0, 0);
greengoalb=true;
Hood.close();
Tongue.open();
Intake.spin(forward, 100, pct);
breakHold();
wait(0.15,sec);
frontdistanceNew(7.9, 0, 8, 5, 1, 0, 1200);
wait(.7,sec); // 1.75
BackstraightVisionST(-2400, 160, 6, 0, 5, 0, 1200);
Outtake.spin(forward, 100, pct);
wait(0.15,sec);
Hood.open();
//Outtake.spin(forward, 100, pct);
wait(1.3,sec); // 2.75
breakCoast();
chassis.turn_to_angle(90);
*/



wait(300000000000000,sec);

 //drive_test(); 
//Setup();  
//AWPRed(); //States
//BigRed(); //Worlds
//BigBlue2(); //Worlds
//BigRed2(); //Worlds
//BigBlue3();
//RedNegativeWorlds();
//BluePostiveWorlds();
//BlueNegativeWorlds();
//BigBlue(); //States
//SoloAWPRed(); //States
//RedKindaSafe(); //States
//BlueSafe(); //States
//Skills3(); //Worlds
//RedElims(); //States
//BlueElims(); //States
//RedWithStake(); //States
//BlueWithStake(); //States
//RedNegative(); //States
//BluePostive(); //States
//RedPostive();

//SoloAWPRed();
//SoloAWPBlue();
//BigRed();
//BigRed2();
//BigBlue2();
//BigBlue3();
//RedPostive();
//RedNegativeWorlds();
//BlueNegativeWorlds();
//BluePostiveWorlds();



  task t100(rightWingToggle);
  task t101(leftWingToggle);
  task t102(wingToggle);
  task t103(tongueToggle);
  task t104(intakeBlock);
  task t105(hoodToggle);
  //task t106(parkToggle);

  while(1)
  {
   // Controller1.ButtonUp.pressed(LBP2);

  float throttle = deadband(controller(primary).Axis3.value(), 5);
  float turn = deadband(controller(primary).Axis1.value(), 5);
  
  lBase1.spin(fwd, to_volt(throttle+turn)*.5, volt);
  lBase2.spin(fwd, to_volt(throttle+turn)*.5, volt);
  lBase3.spin(fwd, to_volt(throttle+turn)*.5, volt);
  rBase1.spin(fwd, to_volt(throttle-turn)*.5, volt);
  rBase2.spin(fwd, to_volt(throttle-turn)*.5, volt);
  rBase3.spin(fwd, to_volt(throttle-turn)*.5, volt);
  }

}
//
// Main will set up the competition functions and callbacks.
//
int main() {
  // Set up callbacks for autonomous and driver control periods.

  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(20, msec);
  }
}






/*
  if (Controller1.ButtonX.pressing()) //both joysticks can increase the flywheel speed by 5 rpm  
    {
      if(!toggle1)
      {  
      toggle1 = true;                 
      states1 += 1;  
      }

    } 
  else if (Controller1.ButtonLeft.pressing()) 
    {
      if(!toggle1)
      {   
      toggle1 = true;
      states1 = 0;  
      }
    }

  else if(Controller1.ButtonRight.pressing()) {
    if(!toggle1) {
      toggle1 = true;
      states = 2;
    }
  }
   
  else 
    {
    toggle1 = false;
    }

  if (states1 == 1)
    {
    states =  -1; 
    task t6010(armPID);
    adesiredValue = 700;
    aspeed = 12;
    //printf("states %d\tfrontdistance %f\toptical %f\n",states1, Frontdistance.objectDistance(mm), Optical2.hue());
    }
    else if (states1 ==2)
    { 
    task t6011(armPID);
    adesiredValue = 180;
    //states1 = 1;
    //speed = 12;
    //printf("states %d\tfrontdistance %f\n",states1, Frontdistance.objectDistance(mm));
    }
    else if (states1 ==3)
    { 
    
    task::stop(armPID);  
    task t691(armNoPID);

    //speed = 12;
    //printf("states %d\tfrontdistance %f\n",states1, Frontdistance.objectDistance(mm));
    }
    else if (states1 ==4)
    { 
    
    task::stop(armNoPID);  
    lbp.close();
    states1 = 1;
    //states = 0;
    //speed = 12;
    //printf("states %d\tfrontdistance %f\n",states1, Frontdistance.objectDistance(mm));
    }

  */