#include "vex.h"
using namespace vex;


void backdistanceNew(int desiredValue, float desiredTurnValue, int speed, int speeds, float settle_error, float settle_time, float timeout) {
 T1.clear();
 settled = false;
 time_spent_running = 0;
 time_spent_settled = 0;
 error =  desiredValue - Backdistance.objectDistance(inches);
  while (!settled) {
    

  error =  desiredValue - Backdistance.objectDistance(inches);

  if (Backdistance.objectDistance(inches)<=0 || Backdistance.objectDistance(inches)>=195)
    {
      error = prevError-1.1;
    }
    
    if (fabs(error) < starti){
    totalError += error;
    }
     // Checks if the error has crossed 0, and if it has, it eliminates the integral term.
    if ((error>0 && prevError<0)||(error<0 && prevError>0)){ 
    totalError = 0; 
    }

    derivative = error - prevError;

    double lateralMotorPower = error * dkP + derivative * dkD + totalError * dkI;
    /////////////////////////////////////////////////////////////////////
    prevError = error;

    if (lateralMotorPower > speed) {
        lateralMotorPower = speed;
      }
   
      else if (lateralMotorPower < -speed) {
        lateralMotorPower = -speed;
      }
  
   if (lateralMotorPower>0 && lateralMotorPower < speeds && speeds > 0) 
      {
        lateralMotorPower = speeds;
      }
      else if (lateralMotorPower<0 && lateralMotorPower > -speeds && speeds > 0) 
      {
        lateralMotorPower = -speeds;
      }

   float turnDifference1 = desiredTurnValue -Inertial20.heading();
      if (fabs(turnDifference1) >=180)
      {
       turnDifference1 = -fabs(turnDifference1)/turnDifference1 * (360 - fabs(turnDifference1));
      }

    if (fabs(turnDifference1) < istarti){
    turnTotalError += turnDifference1;
    }
     // Checks if the error has crossed 0, and if it has, it eliminates the integral term.
    if ((turnDifference1>0 && turnPrevError<0)||(turnDifference1<0 && turnPrevError>0)){ 
    turnTotalError = 0; 
    }

    turnDerivative = turnDifference1 - turnPrevError;

    double turnMotorPower = turnDifference1 * iturnkP + turnDerivative * iturnkD + turnTotalError * iturnkI;
    /////////////////////////////////////////////////////////////////////
    turnPrevError = turnDifference1;

    if (turnMotorPower > speed) {
        turnMotorPower = speed;
      }
   
      else if (turnMotorPower < -speed) {
        turnMotorPower = -speed;
      }
  
  
      lBase1.spin(forward, lateralMotorPower + turnMotorPower,voltageUnits::volt);
      lBase2.spin(forward, lateralMotorPower + turnMotorPower,voltageUnits::volt);
      lBase3.spin(forward, lateralMotorPower + turnMotorPower,voltageUnits::volt);             
      rBase1.spin(forward, lateralMotorPower - turnMotorPower,voltageUnits::volt);
      rBase2.spin(forward, lateralMotorPower - turnMotorPower,voltageUnits::volt);
      rBase3.spin(forward, lateralMotorPower - turnMotorPower,voltageUnits::volt);
     
   

 if(fabs(error)<settle_error){
        time_spent_settled+=10;
   }
   else { 
        time_spent_settled = 0;
   }

   time_spent_running+=10;


  if (time_spent_running>timeout && timeout != 0){
    settled = true;
  }
 else if (time_spent_settled>settle_time){
    settled = true;
  }
else
  settled = false;

    
    printf("error %f\tturndifference %f\tfrontdistance %f\ttimespentsettled %f\ttimerunning %f\n", error, turnDifference1, Frontdistance.objectDistance(mm),time_spent_settled, time_spent_running);
    wait(10, msec);
    
  }
   lBase2.setPosition(0, degrees);
   rBase2.setPosition(0, degrees);
   lBase1.spin(fwd, 0, pct);
   lBase2.spin(fwd, 0, pct);
   lBase3.spin(fwd, 0, pct);
   rBase1.spin(fwd, 0, pct);
   rBase2.spin(fwd, 0, pct);
   rBase3.spin(fwd, 0, pct);

}




