#include "vex.h"
#include "JAR-Template/drive.h"

using namespace vex;

float drive_kp;
float drive_ki;
float drive_kd;

bool toggle = false; //toggle variable
bool toggle1 = false;
bool toggle2 = false;
bool latch = false;

int count;           //encoder count for non pid moves

int g=0;
int v=0;
int h=0;
float difference;
float previouspostition = 0;
int timediff;
int previoustime = 0;

int states = 0;
int states1 = 0;
int states2 = 0;

float idrift;

float GPSturnAngle;
float endingX;
float endingY;
float startingX; 
float startingY;
float GPSdriveDistance;

float X_position;
float Y_position;

float GX;
float GY;

float GXO;
float GYO;

double constant;
double increment = 0.1;

bool earlyexit = false;
bool distanceexit = false;
bool lineexit = false;
bool dLexit = false;
bool dRexit = false;
bool visionExit = false;
bool yexit = false;
bool goalexit = false;
bool breakout = false;
bool breakoutR = false;
bool multipleobjectsR = false;
bool multipleobjectsL = false;
bool multipleobjectsF = false;
bool waitforring = false;

int breakdistance = 0;

//$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

// PID variables - must modify to work with your robot - also need several
// values depending on how many cubes
double kP = 0.024; // 0.08, 0.075, 0.06 These are other kP that work well  0.07, 0.08
                  // depending on how many cubes
double kI = 0.005; // not using this, but you can experiment if you'd like
double kD = 0.2;  //.12, 0.2  These are other kD that work well depending on how
                  //many cubes
double kM = 0.2; //.1  This is another value that works well depending on how 0.18
double kMI = 0.4; //.4

double vkP = 0.3; // 0.3
double vkI = 0;
double vkD = 0;

int derror;         // SensorValue - DesiredValue : Position
int dprevError = 0;  // Position 20 miliseconds ago
int dderivative;     // error - prevError : Speed
int dtotalError = 0; // totalError = totalError + error


double dkP = 1; // 0.02
double dkI = 0; //.005
double dkD = 5; //0.03
double dkM = 0.2;
double dIkM = 0.4;

double vkMI = 0.1; //0.07
double vkMIG = 0.04; //0.03


double turnkP = 0.15; // 0.3
double turnkI = 0;
double turnkD = 0.0;

double iturnkP = 0.4; // 0.4
double iturnkI = 0.0; //0.01   
double iturnkD = 2; //1

double iturnkPf = 0.4; // 0.3
double iturnkIf = 0.01; //0.021   0.05
double iturnkDf = 1; //.9



double vturnkP = 0.07; // 0.4
double vturnkI = 0.003;//.002
double vturnkD = 0.8;//0.6

double vbturnkP = 0.04; // 0.4
double vbturnkI = 0;//.002
double vbturnkD = 0.6;//0.6


double akP = 0.1; // .008
double akI = 0.00; //.003
double akD = 0.00; //.0015

double ikP = 0.5; // .008
double ikI = 0.00; //.003
double ikD = 0.05; //.0015


int maxTurnIntegral = 300; // These cap the integrals
int maxIntegral = 300;
int integralBound =3; // If error is outside the bounds, then apply the integral. This is a
       // buffer with +-integralBound degrees

// Autonomous Settings
float desiredValue = 0;
float desiredTurnValue = 0;
float adesiredValue = 0;


float error;          // SensorValue - DesiredValue : Position
float prevError = 0;  // Position 20 miliseconds ago
float derivative;     // error - prevError : Speed
float totalError = 0; // totalError = totalError + error

float turnError;          // SensorValue - DesiredValue : Position
float turnPrevError = 0;  // Position 20 miliseconds ago
float turnDerivative;     // error - prevError : Speed
float turnTotalError = 0; // totalError = totalError + error

float aerror;          // SensorValue - DesiredValue : Position
float aprevError = 0;  // Position 20 miliseconds ago
float aderivative;     // error - prevError : Speed
float atotalError = 0; // totalError = totalError + error

int aspeed;
int L;

int colorEncoder = 260;

double turnMotorPower;
double lateralMotorPower;
double alateralMotorPower;

float starti = 15;
float istarti = 0;

float time_spent_settled = 0;
float time_spent_running = 0;
float settle_error = 0;
float settle_time = 0;
float timeout = 0;

bool settled = false;


// Variables modified for use
bool enableDrivePID = true;
bool resetDriveSensors = false;
int x = 0;
int speed;
int speeds;
float turnspeed;
float turnspeeds;
int turnspeed1;
float z;
float GPSInertial;


bool redring = false;
bool bluering = false;
bool greengoal = false;
bool redringb = false;
bool blueringb = false;
bool greengoalb = false;
bool redringi = false;
bool blueringi = false;
bool greengoali = false;
bool mobilegoal = false;
bool greenb = false;
bool redringc = false;
bool blueringc = false;
bool greengoalc = false;
bool ringpassed = false;
bool stack = false;

float xl;
float yf;
float xr;
float yb; 

float xd;
float yd;

float drive_error;
float heading_error;

int ee = 3;


// Pasted from a C++ resource
double signnum_c(double x) {
  if (x > 0.0)
    return 1.0;
  if (x < 0.0)
    return -1.0;
  return x;
}


void allMtrsStop(){          //stops all base motors
lBase1.stop(hold);
lBase2.stop(hold);
lBase3.stop(hold);
rBase1.stop(hold);
rBase2.stop(hold);
rBase3.stop(hold);
}
