#include "vex.h"
#include "vex_addrled.h"

int autoPath() {

while(1) {

    // Controlle1.Screen.clearScreen();

    xl= Leftdistance.objectDistance(inches) + 2;
    xr= Rightdistance.objectDistance(inches) + 2;
    yf= Frontdistance.objectDistance(inches) + 2;
    yb= Backdistance.objectDistance(inches) + 2;
    

    //$$$$$$$$$$RedPos and BlueNeg
    //xd = 144 - fabs(yb*sin(Inertial20.heading()));
    //yd = fabs(xl*sin(Inertial20.heading()));
/*
    //$$$$$$$$$$RedNeg abd BluePos
    xd = fabs(yb*sin(Inertial20.heading()));
    yd = fabs(xr*sin(Inertial20.heading()));
*/
//Inertial20.setHeading(55, deg); // 160 inertial, 1500 back distance
//chassis.set_coordinates(86, 12, 213);

    while(!Controller1.ButtonA.pressing()){
        wait(30,msec);

            xl= Leftdistance.objectDistance(inches) + 7;
            xr= Rightdistance.objectDistance(inches) + 7;
            yf= Frontdistance.objectDistance(inches) + 7;
            yb= Backdistance.objectDistance(inches) + 7;

            Controller1.Screen.setCursor(1,1);
            Controller1.Screen.print("xp%.1f, yp%.1f", chassis.get_X_position(), chassis.get_Y_position());
            //Controller1.Screen.print("gX%.1f, gY%.1f", GPS8.xPosition(inches) + 72, GPS8.yPosition(inches) + 72);
            //Controller1.Screen.print("quality%d", GPS8.quality());
            //Controller1.Screen.print("f%.1f, b%.1f", yf, yb);
            Controller1.Screen.setCursor(2,1);
            //Controller1.Screen.print("r%.1f, b%.1f", xr, yb);
            Controller1.Screen.print("gX%.1f, gY%.1f", GPS8.xPosition(inches) + 72, GPS8.yPosition(inches) + 72);
            Controller1.Screen.setCursor(3,1);
            
            Controller1.Screen.print("I%.1f", Inertial20.heading());
            //Controller1.Screen.print("gH%.1f, I%.1f, Q%.1d", GPS8.heading(deg), Inertial20.heading(), GPS8.quality());
            
            if (GPS8.quality()>=98 && GPS8.quality()<=100)
            {
                //Inertial20.setHeading(GPS8.heading(), deg);
                //read_GPS_coordinates();
                //chassis.set_coordinates(GX, GY, Inertial20.heading());
                       
            }
            
            
            wait(500, msec);
    }

    if (GPS8.quality()>=98 && GPS8.quality()<=100)
            {
                Inertial20.setHeading(GPS8.heading(), deg);
                read_GPS_coordinates();
                chassis.set_coordinates(GX, GY, Inertial20.heading());
                       
            }
    
    wait(0.5,sec);
/*
    while(!Controller1.ButtonA.pressing()) {
            // printf("le %f\tre %f\tInertial %f\tFD %f\tBD %f\n",lBase2.position(deg), rBase2.position(deg), Inertial20.heading(), Frontdistance.objectDistance(mm), Backdistance.objectDistance(mm));
            wait(30,msec);
            Controller1.Screen.setCursor(1,1);
            //Controller1.Screen.print("xp%.2f, yp%.2f", chassis.get_X_position(), chassis.get_Y_position());
            Controller1.Screen.print("quality%d", GPS8.quality());
            Controller1.Screen.setCursor(2,1);
            Controller1.Screen.print("gX%.2f, gY%.2f", GPS8.xPosition(inches) +72, GPS8.yPosition(inches)+72);
            Controller1.Screen.setCursor(3,1);
            Controller1.Screen.print("gH%.2f, I%.2f", GPS8.heading(deg), Inertial20.heading());

    }

    

    printf("Values: ------------------------------------\n");
    
    printf("xpos %f\typos %f\tInertial %f\tgpsX %f\tgps %f\n",X_position, Y_position, Inertial20.heading(), GPS8.xPosition(inches), GPS8.yPosition(inches));

    printf("Values: ------------------------------------\n");

    lBase2.setPosition(0, deg);
    rBase2.setPosition(0,deg);
    */
}

return (0);

}