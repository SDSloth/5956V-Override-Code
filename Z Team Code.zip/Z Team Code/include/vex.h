/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       vex.h                                                     */
/*    Author:       Vex Robotics                                              */
/*    Created:      1 Feb 2019                                                */
/*    Description:  Default header for V5 projects                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/
//

#pragma once
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <algorithm>

#include "v5.h"
#include "v5_vcs.h"

#include "robot-config.h"
#include "JAR-Template/odom.h"
#include "JAR-Template/drive.h"
#include "JAR-Template/util.h"
#include "JAR-Template/PID.h"
#include "autons.h"

extern float X_position;
extern float Y_position;

extern float drive_kp;
extern float drive_ki;
extern float drive_kd;

extern bool toggle; //toggle variable
extern bool toggle1;
extern bool toggle2;
extern bool latch;
          
extern int count;  
extern int g;
extern int v;
extern int h;
extern float difference;
extern float previouspostition;
extern int timediff;
extern int previoustime;

extern int states;
extern int states1;
extern int states2;


extern float idrift;

extern double constant;
extern double increment;

extern float GPSturnAngle;
extern float endingX;
extern float endingY;
extern float startingX; 
extern float startingY;
extern float GPSdriveDistance;

extern float GX;
extern float GY;

extern float GXO;
extern float GYO;

extern limit limitSwitch;

//$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

// PID variables - must modify to work with your robot - also need several
// values depending on how many cubes
extern double kP; // 0.08, 0.075, 0.06 These are other kP that work well  0.07, 0.08
                  // depending on how many cubes
extern double kI; // not using this, but you can experiment if you'd like
extern double kD;  //.12, 0.2  These are other kD that work well depending on how
                  //many cubes
extern double kM; //.1  This is another value that works well depending on how 0.18

extern double kMI;

extern double vkP; // 0.3
extern double vkI;
extern double vkD;

extern double dkP; // 0.3 .007
extern double dkI; //.0025
extern double dkD;
extern double dkM;
extern double dIkM;

extern int derror;
extern int dprevError;
extern int dderivative;
extern int dtotalError;


extern double turnkP; // 0.3
extern double turnkI;
extern double turnkD;

extern double iturnkP; // 0.3
extern double iturnkI; //0.021   0.14
extern double iturnkD; //.9, 1, .0035

extern double iturnkPf; // 0.3
extern double iturnkIf; //0.021   0.05
extern double iturnkDf; //.9


extern double vturnkP; // 0.3
extern double vturnkI;
extern double vturnkD;
extern double vbturnkP; // 0.3
extern double vbturnkI;
extern double vbturnkD;
extern double vkMI;
extern double vkMIG;

extern double akP; 
extern double akI; 
extern double akD; 

extern double ikP; 
extern double ikI; 
extern double ikD; 

extern float X_position;
extern float Y_position;

extern int maxTurnIntegral; // These cap the integrals
extern int maxIntegral;
extern int integralBound; // If error is outside the bounds, then apply the integral. This is a
       // buffer with +-integralBound degrees

// Autonomous Settings
extern float desiredValue;
extern float desiredTurnValue;


extern float error;          // SensorValue - DesiredValue : Position
extern float prevError;  // Position 20 miliseconds ago
extern float derivative;     // error - prevError : Speed
extern float totalError; // totalError = totalError + error

extern float turnError;          // SensorValue - DesiredValue : Position
extern float turnPrevError;  // Position 20 miliseconds ago
extern float turnDerivative;     // error - prevError : Speed
extern float turnTotalError; // totalError = totalError + error

extern double turnMotorPower;
extern double lateralMotorPower;

extern float starti;
extern float istarti;

extern bool settled;
extern float time_spent_settled;
extern float time_spent_running;
extern float settle_error;
extern float settle_time;
extern float timeout;

// Variables modified for use
extern bool enableDrivePID;
extern bool resetDriveSensors;
extern int x;
extern int speed;
extern int speeds;
extern float turnspeeds;
extern float turnspeed;
extern int turnspeed1;
extern float z;
extern float GPSInertial;


extern bool redring;
extern bool bluering;
extern bool greengoal;
extern bool redringb;
extern bool blueringb;
extern bool greengoalb;
extern bool redringi;
extern bool blueringi;
extern bool greengoali;
extern bool mobilegoal;
extern bool greenb;
extern bool redringc;
extern bool blueringc;
extern bool greengoalc;
extern bool multipleobjectsR;
extern bool multipleobjectsL;
extern bool multipleobjectsF;
extern bool waitforring;
extern bool ringpassed;
extern bool stack;

extern float xl;
extern float yf;
extern float xr;
extern float yb;
extern float xd;
extern float yd;

extern int ee;

double signnum_c(double x);
void allMtrsStop();


int intakeDisk();
void driveStraightInertialST(int desiredValue, float desiredTurnValue, int speed, int speeds, float settle_error, float settle_time, float timeout);
void PIDlateralST(int desiredValue, int speed, float settle_error, float settle_time, float timeout);
void distanceFrontInertialST(int desiredValue, float desiredTurnValue, int speed, float settle_error, float settle_time, float timeout);
void distanceBackInertialST(int desiredValue, float desiredTurnValue, int speed, float settle_error, float settle_time, float timeout);
void inertialPIDfuntionST(float desiredTurnValue, float turnspeed, float turnspeeds, float settle_error, float settle_time, float timeout);
void inertialSwingST(float desiredTurnValue, float turnspeed, float settle_error, float settle_time, float timeout, float R, float L);
void SwingRST(int desiredTurnValue, int turnspeed, float settle_error, float settle_time, float timeout);
void SwingLST(int desiredTurnValue, int turnspeed, float settle_error, float settle_time, float timeout);
void SwingReverseRST(int desiredTurnValue, int turnspeed, float settle_error, float settle_time, float timeout);
void SwingReverseLST(int desiredTurnValue, int turnspeed, float settle_error, float settle_time, float timeout);
void driveStraightInertialSTNR(int desiredValue, float desiredTurnValue, int speed, float settle_error, float settle_time, float timeout);
void driveStraightInertialNOPID(int desiredValue, float desiredTurnValue, int speed, float timeout);
void hasBlueCallback();
void hasRedCallback();
void hasGreenCallback();
void playVexcodeSound(const char *soundName);
void FrontturnVisionST(float desiredTurnValue, float turnspeed, float turnspeed1, float settle_error, float settle_time, float timeout);
void FrontstraightVisionST(int desiredValue, float desiredTurnValue, int speed, int speeds, float settle_error, float settle_time, float timeout);
void FrontdistanceVisionST(int desiredValue, float desiredTurnValue, int speed, float speeds, float settle_error, float settle_time, float timeout);
void FrontdistanceVisionWall(int desiredValue, float desiredTurnValue, int speed, float speeds, float settle_error, float settle_time, float timeout);
int BackturnVisionREDtask();
void BackturnVisionST(float desiredTurnValue, float turnspeed, float turnspeed1, float settle_error, float settle_time, float timeout);
void BackdistanceVisionST(int desiredValue, float desiredTurnValue, int speed, float speeds, float settle_error, float settle_time, float timeout);
int armPID(); 
void BackClamp();
int autoPath();
int Joystick_PIDTuningTask();
void constantchooser();
int autoclamp();
int intakering();
int intakeringLB();
int intakeringLB2();
void LBP();
void LBP2();
void DoinkL();
void DoinkR();
int intakering2();
int armNoPID();
int antijam();
int intakedecide(); 
int intakeLBcombo(); 

void read_distance_sensors();
void read_GPS_coordinatesOrigin();
void read_GPS_coordinates();
void SetToGPS();
void GPSAngleDistance(float endingX, float endingY);

int intakestop();
int intakestop2();
int colorsortAuto();

int colorsort();
void BackstraightVisionST(int desiredValue, float desiredTurnValue, int speed, int speeds, float settle_error, float settle_time, float timeout);
void FrontWidthVisionST(int desiredValue, float desiredTurnValue, int speed, int speeds, float settle_error, float settle_time, float timeout); 
void BackYVisionST(int desiredValue, float desiredTurnValue, int speed, int speeds, float settle_error, float settle_time, float timeout);
void FrontYVisionST(int desiredValue, float desiredTurnValue, int speed, int speeds, float settle_error, float settle_time, float timeout); 
//int turnVisionREDtask();
int FrontturnVisionREDtask();
void BackdistanceVisionST2(int desiredValue, float desiredTurnValue, int speed, float speeds, float settle_error, float settle_time, float timeout);
//int ringclawlift();
void visionexit();
void AWPRed();
void AWPBlue();
void BlueSafe();
int intakeRung();
int intakeVisionProceed();
int intakeringVision();
int intakereverse();
void repeating();
int intakelimit();
void AWB();
void AWBB();
void AWBI();
void scanF(int desiredValue, int turnspeed1);
void scanB(int desiredValue, int turnspeed1) ;
void frontdistanceNew(int desiredValue, float desiredTurnValue, int speed, int speeds, float settle_error, float settle_time, float timeout);
void backdistanceNew(int desiredValue, float desiredTurnValue, int speed, int speeds, float settle_error, float settle_time, float timeout);
void BackstraightVisionST(int desiredValue, float desiredTurnValue, int speed, int speeds, float settle_error, float settle_time, float timeout); 
void intakeVisionProceedFunction();
void armfunction(float adesiredValue, int aspeed);

int linefollowR();
int linefollowL();


void BigBlue();
void RedRush();
void RedSafe();
void RedKindaSafe();
void Setup();
void RedElims();
void BlueElims();
void RedWithStake();
void BlueWithStake();
void RedNegative();
void BluePostive();

int tongueToggle();
int rightWingToggle();
int leftWingToggle();
int wingToggle();
int intakeBlock();
int hoodToggle();
int parkToggle();
int oldIntakeBlock();
int oldWingToggle();

void breakHold();
void breakCoast();


void Skills1();
void Skills2();
void Skills3();
void RightQuals();
void RightElims();
void LeftElims();


void badsawp();
void newskills();
void leftSAWP();
void newleftelims();
void rightSAWP();
void newrightelims();
void simpleSkills();


int intakeringLBVision();
int intakeProceed();
int intakeProceed2();
int intakeTime();

extern bool earlyexit;
extern bool distanceexit;
extern bool lineexit;
extern bool dLexit;
extern bool dRexit;
extern bool visionExit;
extern bool yexit;
extern bool goalexit;
extern bool breakout;
extern bool breakoutR;

extern int breakdistance;


int ledpinkj();
int ledrainbowj();
int ledpurplej();
int bangarang();

extern float heading_error;
extern float drive_error;

extern float aerror;         
extern float aprevError;
extern float aderivative; 
extern float atotalError;

extern double alateralMotorPower;
extern float adesiredValue;

extern int aspeed;
extern int L;

int intakex();

void SoloAWPRed();
void SoloAWPBlue();
void BigRed();
void BigRed2();
void BigBlue2();
void BigBlue3();
void RedPostive();
void RedNegativeWorlds();
void BlueNegativeWorlds();
void BluePostiveWorlds();

void clearLoader(double time, double heading);
void scoreLongGoal(double time);



extern int colorEncoder;

#define waitUntil(condition)                                                   \
  do {                                                                         \
    wait(5, msec);                                                             \
  } while (!(condition))

#define repeat(iterations)                                                     \
  for (int iterator = 0; iterator < iterations; iterator++)