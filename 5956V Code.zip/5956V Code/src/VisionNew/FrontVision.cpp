#include "vex.h"
using namespace vex;

enum gameElementsPushBack 
{
  blueBlock,
  redBlock,
};

aivision::colordesc AIVision1__BLUEBOX(3, 92, 200, 239, 10, 0.36);
aivision::colordesc AIVision1__REDBOX(2, 244, 114, 157, 10, 0.37);
aivision::colordesc AIVision1__GREENBOX(1, 199, 146, 96, 15, 0.59);
aivision::colordesc AIVision1__Green(4, 145, 255, 151, 23, 0.2);


// AI Vision Code Definitions
vex::aivision AIVision1(PORT22, AIVision1__BLUEBOX, AIVision1__GREENBOX, AIVision1__REDBOX, aivision::ALL_AIOBJS);
/*
aivision::colordesc AIVision1__ora(1, 199, 146, 96, 15, 0.59);
aivision::colordesc AIVision1__redb(2, 244, 114, 157, 10, 0.37);
aivision::colordesc AIVision1__blueb(3, 92, 200, 239, 10, 0.36);
// AI Vision Code Descriptions
vex::aivision AIVision1(PORT9, AIVision1__ora, AIVision1__redb, AIVision1__blueb);
*/
// Robot configuration code.
// AI Classification Competition Element IDs - Override
enum gameElementsOverride {
  redBluePin,
  blueYellowPin,
  redYellowPin,
  yellowPin,
  cup
};

void AWB()
{
 
  AIVision1.startAwb();
   wait(20, msec);
}

void FrontstraightVisionST(int desiredValue, float desiredTurnValue, int speed, int speeds, float settle_error, float settle_time, float timeout) 
{
T1.clear();
settled = false;
ringpassed = false;
time_spent_running = 0;
time_spent_settled = 0;

lBase2.setPosition(0, degrees);
rBase2.setPosition(0, degrees);
g=0;

//AIVision1.takeSnapshot(AIVision1__BLUEBOX);

    if (redring)
    {
    AIVision1.takeSnapshot(aivision::ALL_AIOBJS);
    AIVision1.objects[0].id == blueBlock;
    }
    else if (bluering)
    AIVision1.takeSnapshot(AIVision1__BLUEBOX);
    else if (greengoal)
    AIVision1.takeSnapshot(AIVision1__GREENBOX);
   
/*
    if(intake.velocity(rpm)<=100 && intake.velocity(rpm)>=20)
    {
    g=1;    
    intake.spin(fwd, 100, pct);
    wait(0.15, sec); 
    g=0;
    intake.spin(reverse, 100, pct);
    }
*/

error = desiredValue - ((rBase2.position(degrees) + lBase2.position(degrees))/2);

//AIVision1.objects[0].id == redBlock;

if (AIVision1.objects[0].exists)
{
while (!settled) {
/*
  if(intake.velocity(rpm)<=100 && intake.velocity(rpm)>=20)
  {
  g=1;    
  intake.spin(fwd, 100, pct);
  wait(0.15, sec); 
  g=0;
  intake.spin(reverse, 100, pct);
  }
  */
//while(true){
    // Get the position of both motors
    float averagePosition = (rBase2.position(degrees) + lBase2.position(degrees))/2;
    //int rightMotorPosition = rBase2.position(degrees);
     error = desiredValue - averagePosition;
    
    if (fabs(error) < starti){
    totalError += error;
    }
     // Checks if the error has crossed 0, and if it has, it eliminates the integral term.
    if ((error>0 && prevError<0)||(error<0 && prevError>0)){ 
    totalError = 0; 
    }

    derivative = error - prevError;

    lateralMotorPower = error * kP + derivative * kD + totalError * kI;
    /////////////////////////////////////////////////////////////////////
    prevError = error;
    
      if (lateralMotorPower > speed) 
      {
        lateralMotorPower = speed;
      }
      else if (lateralMotorPower < - speed) 
      {
        lateralMotorPower = -speed;
      }

      if (lateralMotorPower>0 && lateralMotorPower < speeds && speeds > 0) 
      {
        lateralMotorPower = speeds;
      }
      else if (lateralMotorPower<0 && lateralMotorPower > -speeds && speeds > 0) 
      {
        lateralMotorPower = -speeds;
      }
      


    if (redring)
    {
    AIVision1.takeSnapshot(aivision::ALL_AIOBJS);
    AIVision1.objects[0].id == blueBlock;
    //AIVision1.takeSnapshot(AIVision1__REDBOX);
    }
    else if (bluering)
    AIVision1.takeSnapshot(AIVision1__BLUEBOX);
    else if (greengoal)
    AIVision1.takeSnapshot(AIVision1__GREENBOX);
   
    
    float turnDifference1;

    if (multipleobjectsR)
    {
    if (AIVision1.objectCount >=2)
    {
      if (AIVision1.objects[0].centerX > AIVision1.objects[1].centerX) 
      {
        turnDifference1 = AIVision1.objects[0].centerX - desiredTurnValue;
        printf("Large On Right\n");
        printf("X0 %d\tX1 %d\tY %d\tcount %d\terror %f\tturndifference %lf\n",AIVision1.objects[0].centerX, AIVision1.objects[1].centerX, AIVision1.objects[0].centerY, AIVision1.objectCount, error, turnDifference1);
      }

      else if (AIVision1.objects[0].centerX < AIVision1.objects[1].centerX) 
      {
        turnDifference1 = AIVision1.objects[1].centerX - desiredTurnValue;
        printf("Small On Right\n");
        printf("X0 %d\tX1 %d\tY %d\tcount %d\terror %f\tturndifference %lf\n",AIVision1.objects[0].centerX, AIVision1.objects[1].centerX, AIVision1.objects[0].centerY, AIVision1.objectCount, error, turnDifference1);
      }
    }
    else
    {
      turnDifference1 = AIVision1.objects[0].centerX - desiredTurnValue;
      multipleobjectsR = false;
      printf("One Large Object\n");
      printf("X0 %d\tX1 %d\tY %d\tcount %d\terror %f\tturndifference %lf\n",AIVision1.objects[0].centerX, AIVision1.objects[1].centerX, AIVision1.objects[0].centerY, AIVision1.objectCount, error, turnDifference1);
    }
    }

    else if (multipleobjectsL)
    {
    if (AIVision1.objectCount >=2)
    {
      if (AIVision1.objects[0].centerX < AIVision1.objects[1].centerX) 
      {
        turnDifference1 = AIVision1.objects[0].centerX - desiredTurnValue;
        printf("Large On Right\n");
        printf("X0 %d\tX1 %d\tY %d\tcount %d\terror %f\tturndifference %lf\n",AIVision1.objects[0].centerX, AIVision1.objects[1].centerX, AIVision1.objects[0].centerY, AIVision1.objectCount, error, turnDifference1);
      }

      else if (AIVision1.objects[0].centerX > AIVision1.objects[1].centerX) 
      {
        turnDifference1 = AIVision1.objects[1].centerX - desiredTurnValue;
        printf("Small On Right\n");
        printf("X0 %d\tX1 %d\tY %d\tcount %d\terror %f\tturndifference %lf\n",AIVision1.objects[0].centerX, AIVision1.objects[1].centerX, AIVision1.objects[0].centerY, AIVision1.objectCount, error, turnDifference1);
      }
    }
    else
    {
      turnDifference1 = AIVision1.objects[0].centerX - desiredTurnValue;
      multipleobjectsL = false;
      printf("One Large Object\n");
      printf("X0 %d\tX1 %d\tY %d\tcount %d\terror %f\tturndifference %lf\n",AIVision1.objects[0].centerX, AIVision1.objects[1].centerX, AIVision1.objects[0].centerY, AIVision1.objectCount, error, turnDifference1);
    }
    }
    
    else if (multipleobjectsF)
    {
    if (AIVision1.objectCount >=2)
    {
      if (AIVision1.objects[0].centerY < AIVision1.objects[1].centerY) 
      {
        turnDifference1 = AIVision1.objects[0].centerX - desiredTurnValue;
        printf("Large On Right\n");
        printf("X0 %d\tX1 %d\tY %d\tcount %d\terror %f\tturndifference %lf\n",AIVision1.objects[0].centerX, AIVision1.objects[1].centerX, AIVision1.objects[0].centerY, AIVision1.objectCount, error, turnDifference1);
      }

      else if (AIVision1.objects[0].centerY > AIVision1.objects[1].centerY) 
      {
        turnDifference1 = AIVision1.objects[1].centerX - desiredTurnValue;
        printf("Small On Right\n");
        printf("X0 %d\tX1 %d\tY %d\tcount %d\terror %f\tturndifference %lf\n",AIVision1.objects[0].centerX, AIVision1.objects[1].centerX, AIVision1.objects[0].centerY, AIVision1.objectCount, error, turnDifference1);
      }
    }
    else
    {
      turnDifference1 = AIVision1.objects[0].centerX - desiredTurnValue;
      multipleobjectsF = false;
      printf("One Large Object\n");
      printf("X0 %d\tX1 %d\tY %d\tcount %d\terror %f\tturndifference %lf\n",AIVision1.objects[0].centerX, AIVision1.objects[1].centerX, AIVision1.objects[0].centerY, AIVision1.objectCount, error, turnDifference1);
    }
    }

    else
    {
      turnDifference1 = AIVision1.objects[0].centerX - desiredTurnValue;
      printf("Only One Large Object\n");
      printf("X0 %d\tX1 %d\tY %d\tcount %d\terror %f\tturndifference %lf\n",AIVision1.objects[0].centerX, AIVision1.objects[1].centerX, AIVision1.objects[0].centerY, AIVision1.objectCount, error, turnDifference1);
    }
   
   

   if (fabs(turnDifference1) < istarti){
    turnTotalError += turnDifference1;
    }
     // Checks if the error has crossed 0, and if it has, it eliminates the integral term.
    if ((turnDifference1>0 && turnPrevError<0)||(turnDifference1<0 && turnPrevError>0)){ 
    turnTotalError = 0; 
    }

    turnDerivative = turnDifference1 - turnPrevError;

    double turnMotorPower = turnDifference1 * vturnkP + turnDerivative * vturnkD + turnTotalError * vturnkI;
    /////////////////////////////////////////////////////////////////////
    turnPrevError = turnDifference1;


if (turnMotorPower > speed) {
        turnMotorPower = speed;
      }
   
      else if (turnMotorPower < -speed) {
        turnMotorPower = -speed;
      }   

  
      lBase1.spin(forward, lateralMotorPower + turnMotorPower,voltageUnits::volt);
      lBase2.spin(forward, lateralMotorPower + turnMotorPower,voltageUnits::volt);
      lBase3.spin(forward, lateralMotorPower + turnMotorPower, voltageUnits::volt);              
      rBase1.spin(forward, lateralMotorPower - turnMotorPower, voltageUnits::volt);
      rBase2.spin(forward, lateralMotorPower - turnMotorPower, voltageUnits::volt);
      rBase3.spin(forward, lateralMotorPower - turnMotorPower, voltageUnits::volt);
        

  if(fabs(error)<settle_error){
        time_spent_settled+=10;
   }
   else { 
        time_spent_settled = 0;
   }

   time_spent_running+=10;


  if (time_spent_running>timeout && timeout != 0){
    settled = true;
  }
  else if (time_spent_settled>settle_time){
    settled = true;
  }
  else 
  settled = false;



if (yexit)
{
  if (AIVision1.objects[0].centerY>=200) //60
  break;
}


if(lineexit)
{
  if(linetrackerL.reflectivity(percent)>70)
  break;

  if(linetrackerR.reflectivity(percent)>70)
  break;
}

if(breakout)
{
  if(error<breakdistance)
  break;
}

if(intakedistance.objectDistance(inches)>0 && intakedistance.objectDistance(inches)<=3)
ringpassed = true;
/*
if (g==1)        
{
  while(g==1)
  {
    lBase1.stop(coast);
    lBase2.stop(coast);
    lBase3.stop(coast);
    rBase1.stop(coast);
    rBase2.stop(coast);
    rBase3.stop(coast);
  }
  
}   
  
*/
if (earlyexit)
{

  if (ring.objectDistance(inches)>0 && ring.objectDistance(inches)<= ee)
  {
    break;
  }
  
  /*
  if (ring.objectDistance(inches)>0 && ring.objectDistance(inches)<= 1) //60
  {
    if (redringc)
    AIVision1.takeSnapshot(AIVision1__REDBOX);
    else if (blueringc)
    AIVision1.takeSnapshot(AIVision1__BLUEBOX);
    else if (greengoalc)
    AIVision1.takeSnapshot(AIVision1__GREENBOX);
    if((AIVision1.objects[0].exists||AIVision1.objects[1].exists) && (AIVision1.objects[0].centerX >100||AIVision1.objects[1].centerX >100) && (AIVision1.objects[0].centerX <250||AIVision1.objects[1].centerX <250) && (AIVision1.objects[0].centerY >150||AIVision1.objects[1].centerY >150))
    {    
    g=1;
    T1.clear();
    while(g==1 && T1.value()<2)
    {
    //earlyexit = false;
   */
   /*
    lBase1.stop(hold);
    lBase2.stop(hold);
    lBase3.stop(hold);
    rBase1.stop(hold);
    rBase2.stop(hold);
    rBase3.stop(hold);
    */
    /*
  lBase1.stop(coast);
  lBase2.stop(coast);
  lBase3.stop(coast);
  rBase1.stop(coast);
  rBase2.stop(coast);
  rBase3.stop(coast);

    }
  
    */
    /*
    T2.clear();
    while(intakedistance.objectDistance(mm)>=20 && T2.value()<2)
    //while(!Controller1.ButtonL2.pressing() && !Controller1.ButtonL1.pressing())
    {
    
      intake.spin(reverse, 11, volt);
      task::sleep(5);
    }  
    wait(50, msec);   
    intake.stop(); 
    wait(350, msec); 
    intake.spin(reverse, 100, pct);
    //T2.clear();
  
    //g=0;
    //earlyexit = true;
    //break;
*/
/*
    }
    else
    {
      break;
    }
  
  } 
*/
}
  
//$$$$$$$$$$$$$$$$$endnew


  // printf("error %0.1f\tlatteralpower %0.1f\tturndifference %0.1f\tInertial %0.1f\ttimespentsettled %0.1f\ttimerunning %0.1f\n",error, lateralMotorPower, turnDifference1, Inertial20.heading(), time_spent_settled, time_spent_running);
   //wait(10, msec);
   //printf("X0 %d\tX1 %d\tY %d\tcount %d\terror %f\tturndifference %lf\n",AIVision1.objects[0].centerX, AIVision1.objects[1].centerX, AIVision1.objects[0].centerY, AIVision1.objectCount, error, turnDifference1);
    wait(5, msec);
}
  
  //printf("error %f\tturndifference %f\tInertial %f\n",error, turnDifference1, Inertial20.heading());
  
  lBase1.stop(coast);
  lBase2.stop(coast);
  lBase3.stop(coast);
  rBase1.stop(coast);
  rBase2.stop(coast);
  rBase3.stop(coast);
  
  if(waitforring)
{
  if(!ringpassed)
  {  
  T1.clear();
  while((intakedistance.objectDistance(inches)<=0 || intakedistance.objectDistance(inches)>=3)  && T1.value()<3)
  {
  lBase1.stop(hold);
  lBase2.stop(hold);
  lBase3.stop(hold);
  rBase1.stop(hold);
  rBase2.stop(hold);
  rBase3.stop(hold);
  }
  ringpassed = false;
  }
}
    
}
}



/*

int colorsortAuto()
{   
    g=0;
    Brain.Screen.clearScreen();
    AIVision1.installed();
    Brain.Screen.print(AIVision1.installed());
    //AIVision1.startAwb();
   
    if (redringc)
    AIVision1.takeSnapshot(AIVision1__REDBOX);
    else if (blueringc)
    AIVision1.takeSnapshot(AIVision1__BLUEBOX);
    else if (greengoalc)
    AIVision1.takeSnapshot(AIVision1__GREENBOX);
  
     //printf("centerX %d\tcenterY %d\tdistance%lf\n",AIVision3.objects[0].centerX, AIVision3.objects[0].centerY, intakedistance.objectDistance(mm));
        //while((intakedistance.objectDistance(mm)>10 || intakedistance.objectDistance(mm)<=0) && !Controller1.ButtonR2.pressing() && !Controller1.ButtonR1.pressing())
        while(1)
        //while(1)
        {    
          
        if (redringc)
        AIVision1.takeSnapshot(AIVision1__REDBOX);
        else if (blueringc)
        AIVision1.takeSnapshot(AIVision1__BLUEBOX);
        else if (greengoalc)
        AIVision1.takeSnapshot(AIVision1__GREENBOX);
    
        intake.spin(reverse, 11, volt);
      
      printf("centerX %i\tcenterY %d\tline %d\n",AIVision1.installed(), AIVision1.objects[0].centerY, linetrackerL.reflectivity(percent));
      //printf(AIVision1.installed());
            //if(intakedistance.objectDistance(mm)<10 && AIVision3.objects[0].exists)
            
    //if(AIVision3.objects[0].exists)
   if(AIVision1.objects[0].exists && AIVision1.objects[0].centerX >160 && AIVision1.objects[0].centerX <185 && AIVision1.objects[0].centerY >200)
        {    
        g=1;
        earlyexit = false;
        T2.clear();
        while(intakedistance.objectDistance(mm)>=20 && T2.value()<2)
        //while(!Controller1.ButtonL2.pressing() && !Controller1.ButtonL1.pressing())
        {
        
          intake.spin(reverse, 11, volt);
          task::sleep(10);
        }  
        wait(50, msec);   
        intake.stop(); 
        wait(350, msec); 
        T2.clear();
       
        
        // intake.spin(fwd, 11, volt);
        // wait(0.25, sec);
        // intake.stop(); 
        
        g=0;
        earlyexit = true;

        }
    wait(20, msec);
}
    return 1;
}
*/

void scanF(int desiredValue, int turnspeed1) 
{ 
v=0;
int i = 0;
int t = 0;
T1.clear();
int e = turnspeed1;
while(t<=1 && v==0 && T1.value()<3)
{
while (i<=1 && v==0 && T1.value()<3)
{
    lBase2.setPosition(0, degrees);
    while(fabs(lBase2.position(degrees))<desiredValue && v==0 && T1.value()<4)
    {
    if (redring)
    AIVision1.takeSnapshot(AIVision1__REDBOX);
    else if (bluering)
    AIVision1.takeSnapshot(AIVision1__BLUEBOX);
    else if (greengoal)
    AIVision1.takeSnapshot(AIVision1__GREENBOX);

    lBase1.spin(forward, turnspeed1, voltageUnits::volt);
    lBase2.spin(forward, turnspeed1, voltageUnits::volt);
    lBase3.spin(forward, turnspeed1, voltageUnits::volt);
    rBase1.spin(forward, -turnspeed1, voltageUnits::volt);  //right
    rBase2.spin(forward, -turnspeed1, voltageUnits::volt);
    rBase3.spin(forward, -turnspeed1, voltageUnits::volt);


    if(AIVision1.objects[0].exists && AIVision1.objects[0].width>70) 
    {   
        lBase1.stop(hold);
        lBase2.stop(hold);
        lBase3.stop(hold);
        rBase1.stop(hold);
        rBase2.stop(hold);
        rBase3.stop(hold);
        v=1;
    }
    }  
    i++;
    if (turnspeed1 >0)
    turnspeed1 = -turnspeed1 - 3;
    else if (turnspeed1 <0)
    turnspeed1 = -turnspeed1 + 3; 
  } 
    i=0;  
    turnspeed1 = -e;
    t++;
}
        lBase1.stop(hold);
        lBase2.stop(hold);
        lBase3.stop(hold);
        rBase1.stop(hold);
        rBase2.stop(hold);
        rBase3.stop(hold);
}




void FrontturnVisionST(float desiredTurnValue, float turnspeed, float turnspeed1, float settle_error, float settle_time, float timeout) {
  
  settled = false;
  time_spent_running = 0;
  time_spent_settled = 0;
  v=0;
 
  z = Inertial20.heading();
  
  if (redring)
  AIVision1.takeSnapshot(AIVision1__REDBOX);
  else if (bluering)
  AIVision1.takeSnapshot(AIVision1__BLUEBOX);
  else if (greengoal)
  AIVision1.takeSnapshot(AIVision1__GREENBOX);
  
   //AIVision1.takeSnapshot(aivision::ALL_AIOBJS);
  
  
    ///////////////////////////////////////////
    // Turning movement PID
    wait (10, msec);
  
 
  while (!AIVision1.objects[0].exists) {

    if (redring)
    AIVision1.takeSnapshot(AIVision1__REDBOX);
    else if (bluering)
    AIVision1.takeSnapshot(AIVision1__BLUEBOX);
    else if (greengoal)
    AIVision1.takeSnapshot(AIVision1__GREENBOX);

    lBase1.spin(forward, turnspeed1, voltageUnits::volt);
    lBase2.spin(forward, turnspeed1, voltageUnits::volt);
    lBase3.spin(forward, turnspeed1, voltageUnits::volt);
    rBase1.spin(forward, -turnspeed1, voltageUnits::volt);  //right
    rBase2.spin(forward, -turnspeed1, voltageUnits::volt);
    rBase3.spin(forward, -turnspeed1, voltageUnits::volt);
    wait(10, msec);
    ///////////////////////////////////////////
    // Turning movement PID
  }
  
  turnError =   AIVision1.objects[0].centerX - desiredTurnValue;

   
  while (!settled) {
    if (redring)
    AIVision1.takeSnapshot(AIVision1__REDBOX);
    else if (bluering)
    AIVision1.takeSnapshot(AIVision1__BLUEBOX);
    else if (greengoal)
    AIVision1.takeSnapshot(AIVision1__GREENBOX);

    turnError =   AIVision1.objects[0].centerX - desiredTurnValue;
    
    // Derivative
    turnDerivative = turnError - turnPrevError;

    // Integral
    if (fabs(error) < integralBound) {
      turnTotalError += turnError;
    } else {
      turnTotalError = 0;
    }
    // turnTotalError = turnTotalError + turnError;

    // This would cap the integral
    turnTotalError = fabs(turnTotalError) > maxIntegral
                         ? signnum_c(turnTotalError) * maxIntegral
                         : turnTotalError;

    double turnMotorPower =
        turnError * vturnkP + turnDerivative * vturnkD + turnTotalError * vturnkI;

    
      if (turnMotorPower > turnspeed) {
        turnMotorPower = turnspeed;
      }
   
      else if (turnMotorPower < -turnspeed) {
        turnMotorPower = -turnspeed;
      }
    

    /////////////////////////////////////////////////////////////////////

    
      lBase1.spin(forward, turnMotorPower, voltageUnits::volt);
      lBase2.spin(forward, turnMotorPower, voltageUnits::volt);
      lBase3.spin(forward, turnMotorPower, voltageUnits::volt);
      rBase1.spin(forward, -turnMotorPower, voltageUnits::volt);  //right
      rBase2.spin(forward, -turnMotorPower, voltageUnits::volt);
      rBase3.spin(forward, -turnMotorPower, voltageUnits::volt);
    


   turnPrevError = turnError;

   if(fabs(turnError)<settle_error){
        time_spent_settled+=10;
   }
   else { 
        time_spent_settled = 0;
   }

   time_spent_running+=10;


  if (time_spent_running>timeout && timeout != 0){
    settled = true;
  }
  else if (time_spent_settled>settle_time){
    settled = true;
  }
else
  settled = false;


    //printf("centerX %d\toriginX %d/tcenterY %d\t error%d\t motorpower%lf\n",FrontVision1.largestObject.centerX, FrontVision1.largestObject.originX, FrontVision1.largestObject.centerY, vturnError, vturnMotorPower);
   printf("centerX %d\toriginX %d\tcenterY %d\t error%f\t motorpower%lf\n",AIVision1.objects[0].centerX, AIVision1.objects[0].originX, AIVision1.objects[0].centerY, turnError, turnMotorPower);
 wait(10, msec);
    
  }
   
   lBase1.spin(fwd, 0, pct);
   lBase2.spin(fwd, 0, pct);
   lBase3.spin(fwd, 0, pct);
   rBase1.spin(fwd, 0, pct);
   rBase2.spin(fwd, 0, pct);
   rBase3.spin(fwd, 0, pct);
  }
  




void FrontYVisionST(int desiredValue, float desiredTurnValue, int speed, int speeds, float settle_error, float settle_time, float timeout) 
{
T1.clear();
settled = false;
time_spent_running = 0;
time_spent_settled = 0;

constant = 0;

//AIVision1.takeSnapshot(AIVision1__BLUEBOX);

    if (redring)
    AIVision1.takeSnapshot(AIVision1__REDBOX);
    else if (bluering)
    AIVision1.takeSnapshot(AIVision1__BLUEBOX);
    else if (greengoal)
    AIVision1.takeSnapshot(AIVision1__GREENBOX);

//error =  lBase2.position(degrees) - desiredValue;
error = desiredValue - AIVision1.objects[0].centerY;
if (AIVision1.objects[0].exists)
{
while (!settled && constant ==0) {

     error = desiredValue - AIVision1.objects[0].centerY;
   
    if (fabs(error) < starti){
    totalError += error;
    }
     // Checks if the error has crossed 0, and if it has, it eliminates the integral term.
    if ((error>0 && prevError<0)||(error<0 && prevError>0)){ 
    totalError = 0; 
    }

    derivative = error - prevError;

    lateralMotorPower = error * vkP + derivative * vkD + totalError * vkI;
    /////////////////////////////////////////////////////////////////////
     prevError = error;
    
      if (lateralMotorPower > speed) 
      {
        lateralMotorPower = speed;
      }
      else if (lateralMotorPower < - speed) 
      {
        lateralMotorPower = -speed;
      }

      if (lateralMotorPower>0 && lateralMotorPower < speeds && speeds > 0) 
      {
        lateralMotorPower = speeds;
      }
      else if (lateralMotorPower<0 && lateralMotorPower > -speeds && speeds > 0) 
      {
        lateralMotorPower = -speeds;
      }
      

    if (redring)
    AIVision1.takeSnapshot(AIVision1__REDBOX);
    else if (bluering)
    AIVision1.takeSnapshot(AIVision1__BLUEBOX);
    else if (greengoal)
    AIVision1.takeSnapshot(AIVision1__GREENBOX);
  
   float turnDifference1 = AIVision1.objects[0].centerX - desiredTurnValue;

     if (fabs(turnDifference1) < istarti){
    turnTotalError += turnDifference1;
    }
     // Checks if the error has crossed 0, and if it has, it eliminates the integral term.
    if ((turnDifference1>0 && turnPrevError<0)||(turnDifference1<0 && turnPrevError>0)){ 
    turnTotalError = 0; 
    }

    turnDerivative = turnDifference1 - turnPrevError;

    double turnMotorPower = turnDifference1 * vturnkP + turnDerivative * vturnkD + turnTotalError * vturnkI;
    /////////////////////////////////////////////////////////////////////
    turnPrevError = turnDifference1;  
       
       
     if (turnMotorPower > speed) {
        turnMotorPower = speed;
      }
   
      else if (turnMotorPower < -speed) {
        turnMotorPower = -speed;
      }   
 

  
      lBase1.spin(forward, lateralMotorPower + turnMotorPower,voltageUnits::volt);
      lBase2.spin(forward, lateralMotorPower + turnMotorPower,voltageUnits::volt);
      lBase3.spin(forward, lateralMotorPower + turnMotorPower, voltageUnits::volt);              
      rBase1.spin(forward, lateralMotorPower - turnMotorPower, voltageUnits::volt);
      rBase2.spin(forward, lateralMotorPower - turnMotorPower, voltageUnits::volt);
      rBase3.spin(forward, lateralMotorPower - turnMotorPower, voltageUnits::volt);
      

    if(fabs(error)<settle_error){
        time_spent_settled+=10;
   }
   else { 
        time_spent_settled = 0;
   }

   time_spent_running+=10;


  if (time_spent_running>timeout && timeout != 0){
    settled = true;
  }
  else if (time_spent_settled>settle_time){
    settled = true;
  }
  else 
  settled = false;

if (earlyexit)
{
    if (ring.objectDistance(inches)>0 && ring.objectDistance(inches)<=2) //60
    break;
}

if(lineexit)
{
  if(linetrackerL.reflectivity(percent)>70)
  break;

  if(linetrackerR.reflectivity(percent)>70)
  break;
}

//$$$$$$$$$$$$$startnew

if (g==1)        
{
  while(g==1)
  {
   lBase1.spin(fwd, 0, pct);
    lBase2.spin(fwd, 0, pct);
    lBase3.spin(fwd, 0, pct);
    
    rBase1.spin(fwd, 0, pct);
    rBase2.spin(fwd, 0, pct);
    rBase3.spin(fwd, 0, pct);
  }
  
}                  


   printf("X %d\tY %d\t W %d\tH %d\terror%f\t turndifference%lf\n",AIVision1.objects[0].centerX, AIVision1.objects[0].centerY, AIVision1.objects[0].width, AIVision1.objects[0].height, error, turnDifference1);
    wait(10, msec);

  }
  //printf("error %f\tturndifference %f\tInertial %f\n",error, turnDifference1, Inertial20.heading());
   lBase2.setPosition(0, degrees);
   rBase2.setPosition(0, degrees);
    lBase1.spin(fwd, 0, pct);
    lBase2.spin(fwd, 0, pct);
    lBase3.spin(fwd, 0, pct);
    
    rBase1.spin(fwd, 0, pct);
    rBase2.spin(fwd, 0, pct);
    rBase3.spin(fwd, 0, pct);
    
}
}



void visionexit() { 
    if (redring)
    AIVision1.takeSnapshot(AIVision1__REDBOX);
    else if (bluering)
    AIVision1.takeSnapshot(AIVision1__BLUEBOX);
    else if (greengoal)
    AIVision1.takeSnapshot(AIVision1__GREENBOX);
    
    if( AIVision1.objects[0].exists && AIVision1.objects[0].width>70)
        //while(!Controller1.ButtonL2.pressing() && !Controller1.ButtonL1.pressing())
        {
         /*
          lBase1.stop(hold);
          lBase2.stop(hold);
          lBase3.stop(hold);
          rBase1.stop(hold);
          rBase2.stop(hold);
          rBase3.stop(hold);
          */
          h=1;

        }  
            
  
  }


/*
int colorsort()
{     
while(1)
{

    g=0;
    if (Controller1.ButtonA.pressing()) 
    {  
        //while((intakedistance.objectDistance(mm)>10 || intakedistance.objectDistance(mm)<=0) && !Controller1.ButtonR2.pressing() && !Controller1.ButtonR1.pressing())
        while(!Controller1.ButtonR2.pressing() && !Controller1.ButtonR1.pressing() && g==0)
        //while(1)
        {    
          

          intake.spin(fwd, 12, volt);
          hook.spin(fwd, 12, volt);
          //printf("originY %d\tcenterY %d\tencoder%lf\n",AIVision3.objects[0].originY, AIVision3.objects[0].centerY, intake.position(degrees));
        
            //if(intakedistance.objectDistance(mm)<10 && AIVision3.objects[0].exists
        
        while(!limitSwitch.pressing() && !Controller1.ButtonR2.pressing() && !Controller1.ButtonR1.pressing() )
        //while(!Controller1.ButtonL2.pressing() && !Controller1.ButtonL1.pressing())
        {
        
          intake.spin(fwd, 12, volt);
          hook.spin(fwd, 12, volt);
          task::sleep(10);
        }  
        // wait(100, msec);   
        intake.stop(); 
        hook.stop(); 
        //wait(350, msec); 

        while(limitSwitch.pressing() && !Controller1.ButtonR2.pressing() && !Controller1.ButtonR1.pressing())
        //while(!Controller1.ButtonL2.pressing() && !Controller1.ButtonL1.pressing())
        {
        
          intake.spin(fwd, 5, volt);
          hook.spin(fwd, 5, volt);
          task::sleep(10);
        } 
        intake.spin(reverse, 12, volt);
        hook.spin(reverse, 12, volt);
        wait(0.25, sec);
        intake.stop(); 
        hook.stop();
        g=1;

        }
      }
    
    
     else if(Controller1.ButtonR1.pressing())
        {   
        intake.spin(reverse, 12, volt);
        hook.spin(reverse, 12, volt);
        }
    
    else if(Controller1.ButtonR2.pressing())
        {
        intake.spin(fwd, 12, volt);
        hook.spin(fwd, 12, volt);
        } 

    else
        {
        intake.stop();
        hook.stop();
        }  
        task::sleep(10);     
    }

 return 0;
}

*/

void FrontdistanceVisionST(int desiredValue, float desiredTurnValue, int speed, float speeds, float settle_error, float settle_time, float timeout)
{
T1.clear();
settled = false;
ringpassed = false;
time_spent_running = 0;
time_spent_settled = 0;

lBase2.setPosition(0, degrees);
rBase2.setPosition(0, degrees);
g=0;
//AIVision1.takeSnapshot(AIVision1__BLUEBOX);

    if (redring)
    AIVision1.takeSnapshot(AIVision1__REDBOX);
    else if (bluering)
    AIVision1.takeSnapshot(AIVision1__BLUEBOX);
    else if (greengoal)
    AIVision1.takeSnapshot(AIVision1__GREENBOX);
    
/*
    if(intake.velocity(rpm)<=100 && intake.velocity(rpm)>=20)
    {
    g=1;    
    intake.spin(fwd, 100, pct);
    wait(0.15, sec); 
    g=0;
    intake.spin(reverse, 100, pct);
    }

*/
    error =  ring.objectDistance(inches) - desiredValue;



if (AIVision1.objects[0].exists)
{
while (!settled) {
/*
  if(intake.velocity(rpm)<=100 && intake.velocity(rpm)>=20)
  {
  g=1;    
  intake.spin(fwd, 100, pct);
  wait(0.15, sec); 
  g=0;
  intake.spin(reverse, 100, pct);
  }
  */
  error =  ring.objectDistance(inches) - desiredValue;

  if (ring.objectDistance(inches)<=0 || ring.objectDistance(inches)>=195)
    {
      error = prevError+1.1;
    }
    
    if (fabs(error) < starti){
    totalError += error;
    }
     // Checks if the error has crossed 0, and if it has, it eliminates the integral term.
    if ((error>0 && prevError<0)||(error<0 && prevError>0)){ 
    totalError = 0; 
    }

    derivative = error - prevError;

    lateralMotorPower = error * dkP + derivative * dkD + totalError * dkI;
    /////////////////////////////////////////////////////////////////////
    prevError = error;
    
      if (lateralMotorPower > speed) 
      {
        lateralMotorPower = speed;
      }
      else if (lateralMotorPower < - speed) 
      {
        lateralMotorPower = -speed;
      }

      if (lateralMotorPower>0 && lateralMotorPower < speeds && speeds > 0) 
      {
        lateralMotorPower = speeds;
      }
      else if (lateralMotorPower<0 && lateralMotorPower > -speeds && speeds > 0) 
      {
        lateralMotorPower = -speeds;
      }
      


    if (redring)
    AIVision1.takeSnapshot(AIVision1__REDBOX);
    else if (bluering)
    AIVision1.takeSnapshot(AIVision1__BLUEBOX);
    else if (greengoal)
    AIVision1.takeSnapshot(AIVision1__GREENBOX);
    
    
    float turnDifference1;

    if (multipleobjectsR)
    {
    if (AIVision1.objectCount >=2)
    {
      if (AIVision1.objects[0].centerX > AIVision1.objects[1].centerX) 
      {
        turnDifference1 = AIVision1.objects[0].centerX - desiredTurnValue;
        printf("Large On Right\n");
        printf("X0 %d\tX1 %d\tY %d\tcount %d\terror %f\tturndifference %lf\n",AIVision1.objects[0].centerX, AIVision1.objects[1].centerX, AIVision1.objects[0].centerY, AIVision1.objectCount, error, turnDifference1);
      }

      else if (AIVision1.objects[0].centerX < AIVision1.objects[1].centerX) 
      {
        turnDifference1 = AIVision1.objects[1].centerX - desiredTurnValue;
        printf("Small On Right\n");
        printf("X0 %d\tX1 %d\tY %d\tcount %d\terror %f\tturndifference %lf\n",AIVision1.objects[0].centerX, AIVision1.objects[1].centerX, AIVision1.objects[0].centerY, AIVision1.objectCount, error, turnDifference1);
      }
    }
    else
    {
      turnDifference1 = AIVision1.objects[0].centerX - desiredTurnValue;
      multipleobjectsR = false;
      printf("One Large Object\n");
      printf("X0 %d\tX1 %d\tY %d\tcount %d\terror %f\tturndifference %lf\n",AIVision1.objects[0].centerX, AIVision1.objects[1].centerX, AIVision1.objects[0].centerY, AIVision1.objectCount, error, turnDifference1);
    }
    }

    else if (multipleobjectsL)
    {
    if (AIVision1.objectCount >=2)
    {
      if (AIVision1.objects[0].centerX < AIVision1.objects[1].centerX) 
      {
        turnDifference1 = AIVision1.objects[0].centerX - desiredTurnValue;
        printf("Large On Right\n");
        printf("X0 %d\tX1 %d\tY %d\tcount %d\terror %f\tturndifference %lf\n",AIVision1.objects[0].centerX, AIVision1.objects[1].centerX, AIVision1.objects[0].centerY, AIVision1.objectCount, error, turnDifference1);
      }

      else if (AIVision1.objects[0].centerX > AIVision1.objects[1].centerX) 
      {
        turnDifference1 = AIVision1.objects[1].centerX - desiredTurnValue;
        printf("Small On Right\n");
        printf("X0 %d\tX1 %d\tY %d\tcount %d\terror %f\tturndifference %lf\n",AIVision1.objects[0].centerX, AIVision1.objects[1].centerX, AIVision1.objects[0].centerY, AIVision1.objectCount, error, turnDifference1);
      }
    }
    else
    {
      turnDifference1 = AIVision1.objects[0].centerX - desiredTurnValue;
      multipleobjectsL = false;
      printf("One Large Object\n");
      printf("X0 %d\tX1 %d\tY %d\tcount %d\terror %f\tturndifference %lf\n",AIVision1.objects[0].centerX, AIVision1.objects[1].centerX, AIVision1.objects[0].centerY, AIVision1.objectCount, error, turnDifference1);
    }
    }

    else if (multipleobjectsF)
    {
    if (AIVision1.objectCount >=2)
    {
      if (AIVision1.objects[0].centerY < AIVision1.objects[1].centerY) 
      {
        turnDifference1 = AIVision1.objects[0].centerX - desiredTurnValue;
        printf("Large On Right\n");
        printf("X0 %d\tX1 %d\tY %d\tcount %d\terror %f\tturndifference %lf\n",AIVision1.objects[0].centerX, AIVision1.objects[1].centerX, AIVision1.objects[0].centerY, AIVision1.objectCount, error, turnDifference1);
      }

      else if (AIVision1.objects[0].centerY > AIVision1.objects[1].centerY) 
      {
        turnDifference1 = AIVision1.objects[1].centerX - desiredTurnValue;
        printf("Small On Right\n");
        printf("X0 %d\tX1 %d\tY %d\tcount %d\terror %f\tturndifference %lf\n",AIVision1.objects[0].centerX, AIVision1.objects[1].centerX, AIVision1.objects[0].centerY, AIVision1.objectCount, error, turnDifference1);
      }
    }
    else
    {
      turnDifference1 = AIVision1.objects[0].centerX - desiredTurnValue;
      multipleobjectsF = false;
      printf("One Large Object\n");
      printf("X0 %d\tX1 %d\tY %d\tcount %d\terror %f\tturndifference %lf\n",AIVision1.objects[0].centerX, AIVision1.objects[1].centerX, AIVision1.objects[0].centerY, AIVision1.objectCount, error, turnDifference1);
    }
    }

    else
    {
      turnDifference1 = AIVision1.objects[0].centerX - desiredTurnValue;
      printf("Only One Large Object\n");
      printf("X0 %d\tX1 %d\tY %d\tcount %d\terror %f\tturndifference %lf\n",AIVision1.objects[0].centerX, AIVision1.objects[1].centerX, AIVision1.objects[0].centerY, AIVision1.objectCount, error, turnDifference1);
    }
   
   

   if (fabs(turnDifference1) < istarti){
    turnTotalError += turnDifference1;
    }
     // Checks if the error has crossed 0, and if it has, it eliminates the integral term.
    if ((turnDifference1>0 && turnPrevError<0)||(turnDifference1<0 && turnPrevError>0)){ 
    turnTotalError = 0; 
    }

    turnDerivative = turnDifference1 - turnPrevError;

    double turnMotorPower = turnDifference1 * vturnkP + turnDerivative * vturnkD + turnTotalError * vturnkI;
    /////////////////////////////////////////////////////////////////////
    turnPrevError = turnDifference1;


if (turnMotorPower > speed) {
        turnMotorPower = speed;
      }
   
      else if (turnMotorPower < -speed) {
        turnMotorPower = -speed;
      }   

  
      lBase1.spin(forward, lateralMotorPower + turnMotorPower,voltageUnits::volt);
      lBase2.spin(forward, lateralMotorPower + turnMotorPower,voltageUnits::volt);
      lBase3.spin(forward, lateralMotorPower + turnMotorPower, voltageUnits::volt);              
      rBase1.spin(forward, lateralMotorPower - turnMotorPower, voltageUnits::volt);
      rBase2.spin(forward, lateralMotorPower - turnMotorPower, voltageUnits::volt);
      rBase3.spin(forward, lateralMotorPower - turnMotorPower, voltageUnits::volt);
        

  if(fabs(error)<settle_error){
        time_spent_settled+=10;
   }
   else { 
        time_spent_settled = 0;
   }

   time_spent_running+=10;


  if (time_spent_running>timeout && timeout != 0){
    settled = true;
  }
  else if (time_spent_settled>settle_time){
    settled = true;
  }
  else 
  settled = false;



if (yexit)
{
  if (AIVision1.objects[0].centerY>=200) //60
  break;
}


if(lineexit)
{
  if(linetrackerL.reflectivity(percent)>70)
  break;

  if(linetrackerR.reflectivity(percent)>70)
  break;
}

if(breakout)
{
  if(error<breakdistance)
  break;
}

if(intakedistance.objectDistance(inches)>0 && intakedistance.objectDistance(inches)<=3)
ringpassed = true;
/*

if (g==1)        
{
  while(g==1)
  {
    lBase1.stop(coast);
    lBase2.stop(coast);
    lBase3.stop(coast);
    rBase1.stop(coast);
    rBase2.stop(coast);
    rBase3.stop(coast);
  }
  
}   
*/  

if (earlyexit)
{
/*
  if (ring.objectDistance(mm)>0 && ring.objectDistance(mm)<= 50)
  {
    break;
  }
  */  
  /**/
  if (ring.objectDistance(inches)>0 && ring.objectDistance(inches)<= 1) //60
  {
    if (redringc)
    AIVision1.takeSnapshot(AIVision1__REDBOX);
    else if (blueringc)
    AIVision1.takeSnapshot(AIVision1__BLUEBOX);
    else if (greengoalc)
    AIVision1.takeSnapshot(AIVision1__GREENBOX);
    if((AIVision1.objects[0].exists||AIVision1.objects[1].exists) && (AIVision1.objects[0].centerX >100||AIVision1.objects[1].centerX >100) && (AIVision1.objects[0].centerX <250||AIVision1.objects[1].centerX <250) && (AIVision1.objects[0].centerY >150||AIVision1.objects[1].centerY >150))
    {    
    g=1;
    T1.clear();
    while(g==1 && T1.value()<2)
    {
    //earlyexit = false;
   
   /*
    lBase1.stop(hold);
    lBase2.stop(hold);
    lBase3.stop(hold);
    rBase1.stop(hold);
    rBase2.stop(hold);
    rBase3.stop(hold);
    */
  lBase1.stop(coast);
  lBase2.stop(coast);
  lBase3.stop(coast);
  rBase1.stop(coast);
  rBase2.stop(coast);
  rBase3.stop(coast);

    }
  
    
    /*
    T2.clear();
    while(intakedistance.objectDistance(mm)>=20 && T2.value()<2)
    //while(!Controller1.ButtonL2.pressing() && !Controller1.ButtonL1.pressing())
    {
    
      intake.spin(reverse, 11, volt);
      task::sleep(5);
    }  
    wait(50, msec);   
    intake.stop(); 
    wait(350, msec); 
    intake.spin(reverse, 100, pct);
    //T2.clear();
  
    //g=0;
    //earlyexit = true;
    //break;
*/
    }
    else
    {
      break;
    }
  
  } 

}
//$$$$$$$$$$$$$$$$$endnew


  // printf("error %0.1f\tlatteralpower %0.1f\tturndifference %0.1f\tInertial %0.1f\ttimespentsettled %0.1f\ttimerunning %0.1f\n",error, lateralMotorPower, turnDifference1, Inertial20.heading(), time_spent_settled, time_spent_running);
   //wait(10, msec);
   //printf("X0 %d\tX1 %d\tY %d\tcount %d\terror %f\tturndifference %lf\n",AIVision1.objects[0].centerX, AIVision1.objects[1].centerX, AIVision1.objects[0].centerY, AIVision1.objectCount, error, turnDifference1);
    wait(5, msec);
}
  
  //printf("error %f\tturndifference %f\tInertial %f\n",error, turnDifference1, Inertial20.heading());
  
  lBase1.stop(coast);
  lBase2.stop(coast);
  lBase3.stop(coast);
  rBase1.stop(coast);
  rBase2.stop(coast);
  rBase3.stop(coast);
  
if(waitforring)
{
  if(!ringpassed)
  {  
  T1.clear();
  while((intakedistance.objectDistance(inches)<=0 || intakedistance.objectDistance(inches)>=3)  && T1.value()<3)
  {
  lBase1.stop(hold);
  lBase2.stop(hold);
  lBase3.stop(hold);
  rBase1.stop(hold);
  rBase2.stop(hold);
  rBase3.stop(hold);
  }
  ringpassed = false;
  }
}
    
}
}



void FrontdistanceVisionWall(int desiredValue, float desiredTurnValue, int speed, float speeds, float settle_error, float settle_time, float timeout)
{
T1.clear();
settled = false;
time_spent_running = 0;
time_spent_settled = 0;

lBase2.setPosition(0, degrees);
rBase2.setPosition(0, degrees);
g=0;
//AIVision1.takeSnapshot(AIVision1__BLUEBOX);

    if (redring)
    AIVision1.takeSnapshot(AIVision1__REDBOX);
    else if (bluering)
    AIVision1.takeSnapshot(AIVision1__BLUEBOX);
    else if (greengoal)
    AIVision1.takeSnapshot(AIVision1__GREENBOX);
/*
    if(intake.velocity(rpm)<=100 && intake.velocity(rpm)>=20)
    {
    g=1;    
    intake.spin(fwd, 100, pct);
    wait(0.15, sec); 
    g=0;
    intake.spin(reverse, 100, pct);
    }

*/
    error =  Frontdistance.objectDistance(inches) - desiredValue;



if (AIVision1.objects[0].exists)
{
while (!settled) {
/*
  if(intake.velocity(rpm)<=100 && intake.velocity(rpm)>=20)
  {
  g=1;    
  intake.spin(fwd, 100, pct);
  wait(0.15, sec); 
  g=0;
  intake.spin(reverse, 100, pct);
  }
  */
  error =  Frontdistance.objectDistance(inches) - desiredValue;

  if (Frontdistance.objectDistance(inches)<=0 || Frontdistance.objectDistance(inches)>=195)
    {
      error = prevError+1.1;
    }
    
    if (fabs(error) < starti){
    totalError += error;
    }
     // Checks if the error has crossed 0, and if it has, it eliminates the integral term.
    if ((error>0 && prevError<0)||(error<0 && prevError>0)){ 
    totalError = 0; 
    }

    derivative = error - prevError;

    lateralMotorPower = error * dkP + derivative * dkD + totalError * dkI;
    /////////////////////////////////////////////////////////////////////
    prevError = error;
    
      if (lateralMotorPower > speed) 
      {
        lateralMotorPower = speed;
      }
      else if (lateralMotorPower < - speed) 
      {
        lateralMotorPower = -speed;
      }

      if (lateralMotorPower>0 && lateralMotorPower < speeds && speeds > 0) 
      {
        lateralMotorPower = speeds;
      }
      else if (lateralMotorPower<0 && lateralMotorPower > -speeds && speeds > 0) 
      {
        lateralMotorPower = -speeds;
      }
      


    if (redring)
    AIVision1.takeSnapshot(AIVision1__REDBOX);
    else if (bluering)
    AIVision1.takeSnapshot(AIVision1__BLUEBOX);
    else if (greengoal)
    AIVision1.takeSnapshot(AIVision1__GREENBOX);
    
    float turnDifference1;

    if (multipleobjectsR)
    {
    if (AIVision1.objectCount >=2)
    {
      if (AIVision1.objects[0].centerX > AIVision1.objects[1].centerX) 
      {
        turnDifference1 = AIVision1.objects[0].centerX - desiredTurnValue;
        printf("Large On Right\n");
        printf("X0 %d\tX1 %d\tY %d\tcount %d\terror %f\tturndifference %lf\n",AIVision1.objects[0].centerX, AIVision1.objects[1].centerX, AIVision1.objects[0].centerY, AIVision1.objectCount, error, turnDifference1);
      }

      else if (AIVision1.objects[0].centerX < AIVision1.objects[1].centerX) 
      {
        turnDifference1 = AIVision1.objects[1].centerX - desiredTurnValue;
        printf("Small On Right\n");
        printf("X0 %d\tX1 %d\tY %d\tcount %d\terror %f\tturndifference %lf\n",AIVision1.objects[0].centerX, AIVision1.objects[1].centerX, AIVision1.objects[0].centerY, AIVision1.objectCount, error, turnDifference1);
      }
    }
    else
    {
      turnDifference1 = AIVision1.objects[0].centerX - desiredTurnValue;
      multipleobjectsR = false;
      printf("One Large Object\n");
      printf("X0 %d\tX1 %d\tY %d\tcount %d\terror %f\tturndifference %lf\n",AIVision1.objects[0].centerX, AIVision1.objects[1].centerX, AIVision1.objects[0].centerY, AIVision1.objectCount, error, turnDifference1);
    }
    }

    else if (multipleobjectsL)
    {
    if (AIVision1.objectCount >=2)
    {
      if (AIVision1.objects[0].centerX < AIVision1.objects[1].centerX) 
      {
        turnDifference1 = AIVision1.objects[0].centerX - desiredTurnValue;
        printf("Large On Right\n");
        printf("X0 %d\tX1 %d\tY %d\tcount %d\terror %f\tturndifference %lf\n",AIVision1.objects[0].centerX, AIVision1.objects[1].centerX, AIVision1.objects[0].centerY, AIVision1.objectCount, error, turnDifference1);
      }

      else if (AIVision1.objects[0].centerX > AIVision1.objects[1].centerX) 
      {
        turnDifference1 = AIVision1.objects[1].centerX - desiredTurnValue;
        printf("Small On Right\n");
        printf("X0 %d\tX1 %d\tY %d\tcount %d\terror %f\tturndifference %lf\n",AIVision1.objects[0].centerX, AIVision1.objects[1].centerX, AIVision1.objects[0].centerY, AIVision1.objectCount, error, turnDifference1);
      }
    }
    else
    {
      turnDifference1 = AIVision1.objects[0].centerX - desiredTurnValue;
      multipleobjectsL = false;
      printf("One Large Object\n");
      printf("X0 %d\tX1 %d\tY %d\tcount %d\terror %f\tturndifference %lf\n",AIVision1.objects[0].centerX, AIVision1.objects[1].centerX, AIVision1.objects[0].centerY, AIVision1.objectCount, error, turnDifference1);
    }
    }

    else if (multipleobjectsF)
    {
    if (AIVision1.objectCount >=2)
    {
      if (AIVision1.objects[0].centerY < AIVision1.objects[1].centerY) 
      {
        turnDifference1 = AIVision1.objects[0].centerX - desiredTurnValue;
        printf("Large On Right\n");
        printf("X0 %d\tX1 %d\tY %d\tcount %d\terror %f\tturndifference %lf\n",AIVision1.objects[0].centerX, AIVision1.objects[1].centerX, AIVision1.objects[0].centerY, AIVision1.objectCount, error, turnDifference1);
      }

      else if (AIVision1.objects[0].centerY > AIVision1.objects[1].centerY) 
      {
        turnDifference1 = AIVision1.objects[1].centerX - desiredTurnValue;
        printf("Small On Right\n");
        printf("X0 %d\tX1 %d\tY %d\tcount %d\terror %f\tturndifference %lf\n",AIVision1.objects[0].centerX, AIVision1.objects[1].centerX, AIVision1.objects[0].centerY, AIVision1.objectCount, error, turnDifference1);
      }
    }
    else
    {
      turnDifference1 = AIVision1.objects[0].centerX - desiredTurnValue;
      multipleobjectsF = false;
      printf("One Large Object\n");
      printf("X0 %d\tX1 %d\tY %d\tcount %d\terror %f\tturndifference %lf\n",AIVision1.objects[0].centerX, AIVision1.objects[1].centerX, AIVision1.objects[0].centerY, AIVision1.objectCount, error, turnDifference1);
    }
    }

    else
    {
      turnDifference1 = AIVision1.objects[0].centerX - desiredTurnValue;
      printf("Only One Large Object\n");
      printf("X0 %d\tX1 %d\tY %d\tcount %d\terror %f\tturndifference %lf\n",AIVision1.objects[0].centerX, AIVision1.objects[1].centerX, AIVision1.objects[0].centerY, AIVision1.objectCount, error, turnDifference1);
    }
   
   

   if (fabs(turnDifference1) < istarti){
    turnTotalError += turnDifference1;
    }
     // Checks if the error has crossed 0, and if it has, it eliminates the integral term.
    if ((turnDifference1>0 && turnPrevError<0)||(turnDifference1<0 && turnPrevError>0)){ 
    turnTotalError = 0; 
    }

    turnDerivative = turnDifference1 - turnPrevError;

    double turnMotorPower = turnDifference1 * vturnkP + turnDerivative * vturnkD + turnTotalError * vturnkI;
    /////////////////////////////////////////////////////////////////////
    turnPrevError = turnDifference1;


if (turnMotorPower > speed) {
        turnMotorPower = speed;
      }
   
      else if (turnMotorPower < -speed) {
        turnMotorPower = -speed;
      }   

  
      lBase1.spin(forward, lateralMotorPower + turnMotorPower,voltageUnits::volt);
      lBase2.spin(forward, lateralMotorPower + turnMotorPower,voltageUnits::volt);
      lBase3.spin(forward, lateralMotorPower + turnMotorPower, voltageUnits::volt);              
      rBase1.spin(forward, lateralMotorPower - turnMotorPower, voltageUnits::volt);
      rBase2.spin(forward, lateralMotorPower - turnMotorPower, voltageUnits::volt);
      rBase3.spin(forward, lateralMotorPower - turnMotorPower, voltageUnits::volt);
        

  if(fabs(error)<settle_error){
        time_spent_settled+=10;
   }
   else { 
        time_spent_settled = 0;
   }

   time_spent_running+=10;


  if (time_spent_running>timeout && timeout != 0){
    settled = true;
  }
  else if (time_spent_settled>settle_time){
    settled = true;
  }
  else 
  settled = false;



if (yexit)
{
  if (AIVision1.objects[0].centerY>=200) //60
  break;
}


if(lineexit)
{
  if(linetrackerL.reflectivity(percent)>70)
  break;

  if(linetrackerR.reflectivity(percent)>70)
  break;
}

if(breakout)
{
  if(error<breakdistance)
  break;
}


/*
if (g==1)        
{
  while(g==1)
  {
    lBase1.stop(coast);
    lBase2.stop(coast);
    lBase3.stop(coast);
    rBase1.stop(coast);
    rBase2.stop(coast);
    rBase3.stop(coast);
  }
  
}   
  */

if (earlyexit)
{
/*
  if (ring.objectDistance(mm)>0 && ring.objectDistance(mm)<= 50)
  {
    break;
  }
  */  
  /**/
  if (ring.objectDistance(inches)>0 && ring.objectDistance(inches)<= 1) //60
  {
    if (redringc)
    AIVision1.takeSnapshot(AIVision1__REDBOX);
    else if (blueringc)
    AIVision1.takeSnapshot(AIVision1__BLUEBOX);
    else if (greengoalc)
    AIVision1.takeSnapshot(AIVision1__GREENBOX);
    if((AIVision1.objects[0].exists||AIVision1.objects[1].exists) && (AIVision1.objects[0].centerX >100||AIVision1.objects[1].centerX >100) && (AIVision1.objects[0].centerX <250||AIVision1.objects[1].centerX <250) && (AIVision1.objects[0].centerY >150||AIVision1.objects[1].centerY >150))
    {    
    g=1;
    T1.clear();
    while(g==1 && T1.value()<2)
    {
    //earlyexit = false;
   
   /*
    lBase1.stop(hold);
    lBase2.stop(hold);
    lBase3.stop(hold);
    rBase1.stop(hold);
    rBase2.stop(hold);
    rBase3.stop(hold);
    */
  lBase1.stop(coast);
  lBase2.stop(coast);
  lBase3.stop(coast);
  rBase1.stop(coast);
  rBase2.stop(coast);
  rBase3.stop(coast);

    }
  
    
    /*
    T2.clear();
    while(intakedistance.objectDistance(mm)>=20 && T2.value()<2)
    //while(!Controller1.ButtonL2.pressing() && !Controller1.ButtonL1.pressing())
    {
    
      intake.spin(reverse, 11, volt);
      task::sleep(5);
    }  
    wait(50, msec);   
    intake.stop(); 
    wait(350, msec); 
    intake.spin(reverse, 100, pct);
    //T2.clear();
  
    //g=0;
    //earlyexit = true;
    //break;
*/
    }
    else
    {
      break;
    }
  
  } 

}
//$$$$$$$$$$$$$$$$$endnew


  // printf("error %0.1f\tlatteralpower %0.1f\tturndifference %0.1f\tInertial %0.1f\ttimespentsettled %0.1f\ttimerunning %0.1f\n",error, lateralMotorPower, turnDifference1, Inertial20.heading(), time_spent_settled, time_spent_running);
   //wait(10, msec);
   //printf("X0 %d\tX1 %d\tY %d\tcount %d\terror %f\tturndifference %lf\n",AIVision1.objects[0].centerX, AIVision1.objects[1].centerX, AIVision1.objects[0].centerY, AIVision1.objectCount, error, turnDifference1);
    wait(5, msec);
}
  
  //printf("error %f\tturndifference %f\tInertial %f\n",error, turnDifference1, Inertial20.heading());
  
  lBase1.stop(coast);
  lBase2.stop(coast);
  lBase3.stop(coast);
  rBase1.stop(coast);
  rBase2.stop(coast);
  rBase3.stop(coast);
  
  if(waitforring)
  {
  T1.clear();
  while((intakedistance.objectDistance(inches)<=0 || intakedistance.objectDistance(inches)>=3)  && T1.value()<3)
  {
  lBase1.stop(hold);
  lBase2.stop(hold);
  lBase3.stop(hold);
  rBase1.stop(hold);
  rBase2.stop(hold);
  rBase3.stop(hold);
  }
}
    
}
}












void hasBlueCallback() {
  Brain.Screen.clearLine(1);
  Brain.Screen.setCursor(1, 1);
  AIVision1.takeSnapshot(AIVision1__BLUEBOX);
  if (AIVision1.objectCount > 0) {
    Brain.Screen.print("Blue Object Found");
  } else {
    Brain.Screen.print("No Blue Object");
  }
}

// Will check to see if there is a red object in view of the ai vision
// sensor and display the result on line 3 on the V5 Brain's screen
void hasRedCallback() {
  Brain.Screen.clearLine(3);
  Brain.Screen.setCursor(3, 1);
  AIVision1.takeSnapshot(AIVision1__REDBOX);
  if (AIVision1.objectCount > 0) {
    Brain.Screen.print("Red Object Found");
  } else {
    Brain.Screen.print("No Red Object");
  }
}

// Will check to see if there is a green object in view of the ai vision
// sensor and display the result on line 5 on the V5 Brain's screen
void hasGreenCallback() {
  Brain.Screen.clearLine(5);
  Brain.Screen.setCursor(5, 1);
  AIVision1.takeSnapshot(AIVision1__GREENBOX);
  if (AIVision1.objectCount > 0) {
    Brain.Screen.print("Green Object Found");
  } else {
    Brain.Screen.print("No Green Object");
  }
}