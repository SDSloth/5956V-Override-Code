using namespace vex;

extern brain Brain;

// VEXcode devices
extern motor FL;
extern motor FR;
extern motor RL;
extern motor RR;
extern inertial Inertial20;



extern distance Frontdistance;
extern distance Backdistance;
extern distance Leftdistance;
extern distance Rightdistance;
extern distance RTMG;
extern distance ring;
extern distance Goaldistance;
extern distance intakedistance;
extern optical Optical1;
extern optical Optical2;
extern optical Optical3;
extern optical Optical4;


extern controller Controller1;
extern controller Controller2;

extern motor FL;
extern motor FR;
extern motor RL;
extern motor RR;

extern motor flywheel;
extern motor cata;
extern motor cata2;
extern motor intake;
extern motor hook;
extern motor intake2;
extern motor ringliftL;
extern motor ringliftR;
extern motor intaketop;
extern motor intakebot;

extern motor rBase1;
extern motor rBase2;
extern motor rBase3;

extern motor lBase1;
extern motor lBase2;
extern motor lBase3;

extern triport Expander7;


//extern pneumatics PTOrightPnmtc;
//extern pneumatics PTOleftPnmtc;
extern pneumatics WL;
extern pneumatics WR;
extern pneumatics lbp;
extern pneumatics lbp2;
extern pneumatics doinkR;
extern pneumatics doinkL;
extern pneumatics backClaw;


extern pneumatics IL;
extern pneumatics IR;
extern pneumatics H;
extern pneumatics N;
extern pneumatics Ratchet;

extern pneumatics PTO;
extern pneumatics Arm;
extern pneumatics Claw;

extern motor Intake;
extern motor Transition;
extern motor Outtake;
extern pneumatics Wing;
extern pneumatics Tongue;
extern pneumatics RightWing;
extern pneumatics LeftWing;
extern pneumatics DoublePark;
extern pneumatics Hood;

extern pneumatics kicker;
extern pneumatics block;
extern pneumatics rapid;
extern pneumatics expand;
//extern pneumatics clamp;
extern pneumatics deflect;


extern limit limitSwitch;
extern line linetrackerL;
extern line linetrackerR;
extern line linetrackerLB;
extern line linetrackerRB;

extern rotation rotations;
extern rotation rotation1;
extern rotation rotationARM;

extern timer T1;
extern timer T2;
extern timer T3;

//extern analog_in poten;
//extern sonar frontSonar;
//extern sonar backSonar;

//extern triport Expander3;
//extern led LED3A;
using signature = vision::signature;

extern signature YELLOWDisk;
//extern signature Vision6__YELLOWDISK;
/*
extern signature Vision6__YELLOWDISK;
extern signature Vision6__SIG_2;
extern signature Vision6__SIG_3;
extern signature Vision6__SIG_4;
extern signature Vision6__SIG_5;
extern signature Vision6__SIG_6;
extern signature Vision6__SIG_7;
extern vision Vision6;
*/
extern vision FrontVision;
extern vision FrontVision1;

extern gps GPS8;



//extern smartdrive Drivetrain;


/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void  vexcodeInit( void );