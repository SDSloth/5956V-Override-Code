using namespace vex;

extern brain Brain;

extern motor FR;
extern motor FL;
extern motor RR;
extern motor RL;

void vexcodeInit(void);
